"""
Daily pipeline: load NSE data -> generate reports -> email the report bundle.

Run this once a day (after NSE publishes the day's files, typically evening IST):

    python daily_run.py                 # load + report + email the bundle
    python daily_run.py --dry-run       # do everything EXCEPT sending the email
    python daily_run.py --no-email      # only load data + generate reports

What it does, idempotently (safe to re-run; already-loaded dates are skipped):
  1. Backfill cm_index_data   (NSE daily-snapshot indices)   -> backfill_cm_index
  2. Backfill securities_bhavdata                            -> backfill_securities
  3. Load fo_udiff_bhavdata for any missing trading day      -> here (guarded)
  4. Generate all_data_csv_report for pending dates          -> backfill_reports
  5. Start the Flask API (server.py :9009) if needed, then run
     scripts_for_exes/all_reports.py to build the multi-sheet Excel and email
     it to the recipient list configured there.

The data tables the report needs (securities_bhavdata, cm_index_data,
fo_udiff_bhavdata) are filled by steps 1-3; step 4 then succeeds.
"""
import os
import shutil
import socket
import subprocess
import sys
import time
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import text

from db import get_db, engine

HERE = os.path.dirname(os.path.abspath(__file__))
API_HOST, API_PORT = "127.0.0.1", 9009

# Abort if free disk is below this. A full disk corrupts InnoDB writes mid-insert
# (we hit partial/duplicate F&O rows and MySQL "table is full" temp errors).
MIN_FREE_GB = 3.0


def check_disk():
    free_gb = shutil.disk_usage(HERE).free / (1024 ** 3)
    print(f"[disk] free: {free_gb:.1f} GB")
    if free_gb < MIN_FREE_GB:
        raise SystemExit(
            f"ABORTING: only {free_gb:.1f} GB free (< {MIN_FREE_GB} GB). "
            f"Free disk space before running (e.g. drop stale DBs, clear Downloads) "
            f"to avoid corrupting the database mid-write.")


# --------------------------------------------------------------------------- #
# fo_udiff_bhavdata loader (idempotent: skips dates already present)
# --------------------------------------------------------------------------- #
def _holidays():
    q = """
        SELECT DATE_FORMAT(tradingDate, '%Y-%m-%d') AS trading_date
        FROM `holidays`
        WHERE tradingDate > DATE_SUB(CURDATE(), INTERVAL 3 YEAR);
    """
    return pd.read_sql(text(q), engine, parse_dates=['trading_date'])['trading_date']


def update_last_updated_date():
    """Set last_updated_date to the latest fo trade_date. The original loader
    wrote to a non-existent `trade_date` column, so this table was never kept
    current; report6/7 default to it when no ?date is passed."""
    with next(get_db()) as s:
        mx = s.execute(text("SELECT MAX(trade_date) FROM fo_udiff_bhavdata")).scalar()
        if mx is not None:
            s.execute(text("DELETE FROM last_updated_date"))
            s.execute(text("INSERT INTO last_updated_date (last_updated_date) VALUES (:d)"),
                      {"d": mx})
            s.commit()
            print(f"[last_updated_date] set to {mx}")


def load_fo(lookback_days=20):
    """Load fo_udiff_bhavdata for any missing trading day in the lookback window."""
    from main_old import NSE

    end = datetime.now()
    start = end - timedelta(days=lookback_days)
    dates = pd.date_range(start=start, end=end, freq='B')
    dates = dates[~dates.isin(_holidays())]

    with next(get_db()) as s:
        have = {r[0].strftime('%Y-%m-%d')
                for r in s.execute(text(
                    "SELECT DISTINCT trade_date FROM fo_udiff_bhavdata "
                    "WHERE trade_date >= :d"), {"d": start.strftime('%Y-%m-%d')}).all()}

    todo = [d for d in dates if d.strftime('%Y-%m-%d') not in have]
    print(f"[fo] missing trading days to load: {len(todo)}")
    for d in todo:
        ds = d.strftime('%Y-%m-%d')
        try:
            x = NSE()
            f = x.equity_fo_bhavcopy_final(d)
            x.add_fo_udiff_bhavcopy_to_db(f, verify_in_db=False)
            print(f"[fo] OK {ds}")
        except Exception as e:
            print(f"[fo] SKIP/FAIL {ds}: {e}")


# --------------------------------------------------------------------------- #
# API server management
# --------------------------------------------------------------------------- #
def _port_up(host, port, timeout=2):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def ensure_api_server():
    """Start server.py if the API port is not already listening. Returns the
    Popen handle if we started it (so the caller can stop it), else None."""
    if _port_up(API_HOST, API_PORT):
        print(f"[api] server already up on {API_PORT}")
        return None
    print(f"[api] starting server.py on {API_PORT} ...")
    # debug=True would spawn a reloader child; disable via FLASK_DEBUG=0 is not
    # honoured by app.run(debug=True), so we just start it and poll the port.
    proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")],
                            cwd=HERE)
    for _ in range(40):  # up to ~40s
        if _port_up(API_HOST, API_PORT):
            print("[api] server is up")
            return proc
        time.sleep(1)
    raise RuntimeError("API server did not come up on :9009")


def email_bundle(dry_run=False):
    started = ensure_api_server()
    try:
        env = dict(os.environ)
        if dry_run:
            env["REPORTS_DRY_RUN"] = "1"
        script = os.path.join(HERE, "scripts_for_exes", "all_reports.py")
        print(f"[email] running {script} (dry_run={dry_run})")
        subprocess.run([sys.executable, script], cwd=HERE, env=env, check=False)
    finally:
        if started is not None:
            print("[api] stopping server we started")
            started.terminate()


# --------------------------------------------------------------------------- #
def main(send_email=True, dry_run=False):
    import backfill_cm_index
    import backfill_securities
    import backfill_reports

    print("\n========== 0/5 disk pre-flight ==========")
    check_disk()

    print("\n========== 1/5 cm_index_data ==========")
    backfill_cm_index.backfill()

    print("\n========== 2/5 securities_bhavdata ==========")
    backfill_securities.backfill()

    print("\n========== 3/5 fo_udiff_bhavdata ==========")
    load_fo()
    update_last_updated_date()

    print("\n========== 4/5 all_data_csv_report ==========")
    backfill_reports.run()

    if send_email:
        print("\n========== 5/5 email report bundle ==========")
        email_bundle(dry_run=dry_run)
    else:
        print("\n[5/5] --no-email: skipping email step")

    print("\nDaily run complete.")


if __name__ == "__main__":
    args = set(sys.argv[1:])
    main(send_email="--no-email" not in args, dry_run="--dry-run" in args)


