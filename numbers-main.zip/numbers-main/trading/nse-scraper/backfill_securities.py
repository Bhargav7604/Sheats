"""
One-time backfill for `securities_bhavdata`.

Why this exists
---------------
`load_hystorical_data.py` only ever loads *yesterday*, and it silently
swallows download failures (`try/except RuntimeError: print(e)`). NSE
occasionally serves an HTML page instead of the securities CSV
(bot-detection, or the file not yet published when the loader runs), so
any day the securities download fails is lost forever and never retried.

That is why `securities_bhavdata` lagged behind `fo_udiff_bhavdata` /
`cm_index_data`. This script fills the gap: it finds every trading day
that is missing from `securities_bhavdata` and re-downloads it, retrying
on the intermittent HTML/timeout failures, and it does NOT hide errors.

Usage
-----
    python backfill_securities.py                 # max(date)+1 .. today
    python backfill_securities.py 2026-05-26 2026-06-19   # explicit range

Safe to re-run: dates already present in the table are skipped.
"""
import sys
import time
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import text

from db import get_db, engine
from main_old import NSE

# Per-date download retries (on top of NSE.__download's own retry loop).
DATE_RETRIES = 3
RETRY_SLEEP = 5  # seconds between per-date retries

# main_old.NSE.add_securities_bhavdata_to_db is a broken stub that parses the
# file and never inserts it. We download with main_old.NSE (that part works)
# but insert here using the proven column mapping from main.py.
_SEC_RENAME = {
    ' DATE1': 'date',
    'SYMBOL': 'symbol',
    ' SERIES': 'series',
    ' PREV_CLOSE': 'prev_close',
    ' OPEN_PRICE': 'open_price',
    ' HIGH_PRICE': 'high_price',
    ' LOW_PRICE': 'low_price',
    ' LAST_PRICE': 'last_price',
    ' CLOSE_PRICE': 'close_price',
    ' AVG_PRICE': 'avg_price',
    ' TTL_TRD_QNTY': 'total_trade_quantity',
    ' TURNOVER_LACS': 'turnover_lacs',
    ' NO_OF_TRADES': 'number_of_trades',
    ' DELIV_QTY': 'delivery_quantity',
    ' DELIV_PER': 'delivery_percentage',
}


class DateMismatch(Exception):
    """The downloaded file's DATE1 does not match the requested date."""


def _insert_securities_file(file, expected_date):
    """Parse a sec_bhavdata_full CSV and append it to securities_bhavdata.

    NSE returns the previous trading day's file when the requested date is a
    non-trading day (e.g. a holiday missing from the holidays table). Inserting
    that blindly creates duplicate rows under the wrong date, so we verify the
    file's DATE1 matches `expected_date` first.
    """
    csv_data = pd.read_csv(file, parse_dates=[" DATE1"])

    file_dates = pd.to_datetime(csv_data[" DATE1"]).dt.strftime('%Y-%m-%d').dropna().unique()
    want = expected_date.strftime('%Y-%m-%d')
    if list(file_dates) != [want]:
        file.unlink()
        raise DateMismatch(
            f"file DATE1={list(file_dates)} != requested {want} "
            f"(likely a non-trading day); skipping.")

    csv_data.replace(' ', np.nan, inplace=True)
    csv_data.replace(' -', np.nan, inplace=True)
    csv_data.rename(columns=_SEC_RENAME, inplace=True)
    csv_data = csv_data[list(_SEC_RENAME.values())]  # drop any unexpected cols
    csv_data.to_sql('securities_bhavdata', engine, if_exists='append', index=False)
    file.unlink()
    return len(csv_data)


def _holidays():
    query = """
        SELECT DATE_FORMAT(tradingDate, '%Y-%m-%d') AS trading_date
        FROM `holidays`
        WHERE tradingDate > DATE_SUB(CURDATE(), INTERVAL 3 YEAR);
    """
    df = pd.read_sql(text(query), engine, parse_dates=['trading_date'])
    return df['trading_date']


def _existing_dates():
    """Set of dates (yyyy-mm-dd str) already present in securities_bhavdata."""
    with next(get_db()) as s:
        rows = s.execute(text("SELECT DISTINCT `date` FROM securities_bhavdata")).all()
    return {r[0].strftime('%Y-%m-%d') for r in rows}


# Default auto-mode lookback. We scan this many calendar days back from today
# and fill ANY missing trading day in that window (already-present dates are
# skipped). Using a fixed lookback rather than max(date)+1 means interior gaps
# are caught, not just dates after the latest one.
AUTO_LOOKBACK_DAYS = 120


def _target_dates(start=None, end=None):
    if start is None:
        start = (datetime.now() - timedelta(days=AUTO_LOOKBACK_DAYS)).strftime('%Y-%m-%d')
    if end is None:
        end = datetime.now().strftime('%Y-%m-%d')

    dates = pd.date_range(start=start, end=end, freq='B')  # business days
    holidays = _holidays()
    dates = dates[~dates.isin(holidays)]
    return list(dates)


def backfill(start=None, end=None):
    target = _target_dates(start, end)
    have = _existing_dates()

    todo = [d for d in target if d.strftime('%Y-%m-%d') not in have]
    print(f"Trading days in range: {len(target)} | already present: "
          f"{len(target) - len(todo)} | to download: {len(todo)}")

    ok, failed, skipped = [], [], []
    for d in todo:
        ds = d.strftime('%Y-%m-%d')
        success = False
        for attempt in range(1, DATE_RETRIES + 1):
            try:
                x = NSE()
                file = x.securities_bhavdata(d)
                rows = _insert_securities_file(file, d)
                print(f"OK   {ds}  ({rows} rows)")
                success = True
                break
            except DateMismatch as e:
                # Non-trading day not in the holidays table. Not retryable and
                # not a real failure - just skip it (avoids duplicate inserts).
                print(f"SKIP {ds}: {e}")
                skipped.append(ds)
                success = None  # neither ok nor failed
                break
            except Exception as e:
                # RuntimeError -> "unavailable / not yet updated" (HTML page),
                # FileNotFoundError -> repeated timeouts, etc. Retry, then give up.
                print(f"WARN {ds} attempt {attempt}/{DATE_RETRIES}: {e}")
                time.sleep(RETRY_SLEEP)
        if success is True:
            ok.append(ds)
        elif success is False:
            failed.append(ds)

    print("\n================ BACKFILL SUMMARY ================")
    print(f"Loaded  : {len(ok)}")
    print(f"Skipped : {len(skipped)} (non-trading days not in holidays table)")
    print(f"Failed  : {len(failed)}")
    if skipped:
        print("Skipped dates:", ", ".join(skipped))
    if failed:
        print("Failed dates (re-run later; file may not be published yet):")
        for ds in failed:
            print(f"  {ds}")


if __name__ == "__main__":
    start = sys.argv[1] if len(sys.argv) > 1 else None
    end = sys.argv[2] if len(sys.argv) > 2 else None
    backfill(start, end)
