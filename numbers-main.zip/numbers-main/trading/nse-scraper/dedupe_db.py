"""
Find and remove duplicate rows from the main tables, using each table's
natural key. Keeps the lowest id per key, deletes the rest.

    python dedupe_db.py            # scan only (read-only, reports counts)
    python dedupe_db.py --apply    # actually delete duplicates

Notes:
- Runs with sql_log_bin=0 so the cleanup does not bloat the binary log
  (important while disk is nearly full).
- Deleting rows frees space INSIDE the InnoDB tablespace (reused by future
  inserts); it does NOT return space to the OS disk without OPTIMIZE TABLE.
"""
import sys

from sqlalchemy import text
from db import get_db

# table -> natural key columns (a row is a duplicate if these all match)
CHECKS = {
    'securities_bhavdata':  ['date', 'symbol', 'series'],
    'cm_index_data':        ['index_name', 'index_date'],
    'all_data_csv_report':  ['date', 'symbol'],
    'cm_udiff_bhavdata':    ['trade_date', 'fin_instrm_id'],
    'fo_udiff_bhavdata':    ['trade_date', 'fin_instrm_id'],
}


def scan(s, table, keycols):
    cols = ', '.join('`%s`' % c for c in keycols)
    tot = s.execute(text('SELECT COUNT(*) FROM %s' % table)).scalar()
    dis = s.execute(text(
        'SELECT COUNT(*) FROM (SELECT 1 FROM %s GROUP BY %s) x' % (table, cols)
    )).scalar()
    return tot, dis, tot - dis


def delete_dupes(s, table, keycols):
    """Delete all but the minimum id per key group."""
    cols = ', '.join('`%s`' % c for c in keycols)
    sql = (
        'DELETE FROM {t} WHERE id NOT IN ('
        '  SELECT mid FROM ('
        '    SELECT MIN(id) AS mid FROM {t} GROUP BY {cols}'
        '  ) keep'
        ')'
    ).format(t=table, cols=cols)
    res = s.execute(text(sql))
    return res.rowcount


def main(apply):
    with next(get_db()) as s:
        if apply:
            s.execute(text('SET sql_log_bin=0'))
        print('%-32s %12s %12s %10s' % ('table', 'rows', 'distinct', 'dupes'))
        for table, keycols in CHECKS.items():
            try:
                tot, dis, dup = scan(s, table, keycols)
            except Exception as e:
                msg = str(e).split('\n')[0]
                print('%-32s  SCAN FAILED: %s' % (table, msg[:80]))
                try:
                    s.rollback()
                except Exception:
                    pass
                continue
            print('%-32s %12d %12d %10d' % (table, tot, dis, dup))
            if apply and dup > 0:
                try:
                    deleted = delete_dupes(s, table, keycols)
                    s.commit()
                    _, _, dup2 = scan(s, table, keycols)
                    print('   -> deleted %d ; now dupes=%d %s'
                          % (deleted, dup2, 'OK' if dup2 == 0 else 'CHECK'))
                except Exception as e:
                    s.rollback()
                    print('   -> DELETE FAILED (rolled back): %s'
                          % str(e).split('\n')[0][:80])


if __name__ == '__main__':
    main(apply='--apply' in sys.argv[1:])
