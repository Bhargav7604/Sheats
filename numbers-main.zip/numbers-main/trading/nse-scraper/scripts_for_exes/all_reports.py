
from datetime import datetime
from pathlib import Path
import sys
import requests
import csv
import os
import pandas as pd
import smtplib
from email.message import EmailMessage
import shutil

# Single source of truth for SMTP credentials: pull from config.py (one place
# to update an expired Gmail App Password) instead of hardcoding it here.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import settings

# Define the custom directory path
directory_path = Path(r"C:\Page_Projects\trading\nse-scraper\Output")

# Check if the directory exists
if not directory_path.exists():
    # Create the directory if it doesn't exist
    directory_path.mkdir(parents=True)
    print(f"Directory '{directory_path}' created.")

# API URL
API_URL = "http://127.0.0.1:9009"

def clear_directory():
    """
    Clears all files in the directory.
    """
    for file_name in os.listdir(directory_path):
        file_path = os.path.join(directory_path, file_name)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
                print(f"Deleted {file_name}")
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
                print(f"Deleted directory {file_name}")
        except Exception as e:
            print(f"Failed to delete {file_name}. Reason: {e}")

def fetch_and_save_report(report_name, file_prefix):
    """
    Fetches data from the API and saves it as a CSV file.
    """
    report_url = f"{API_URL}/{report_name}"
    resp = requests.get(report_url)

    if not resp.ok:
        print(f"Failed to fetch data from {report_url}")
        return

    response = resp.json()
    data = response.get("data", [])
    data_date = response.get("date")

    # ✅ CRITICAL FIX — HANDLE EMPTY DATA
    if not data:
        print(f"No data returned for {report_name}. Skipping CSV creation.")
        return

    data_date = datetime.strptime(data_date, "%Y-%m-%d")

    if report_name in ["get-all-data-csv-report", "get-report3"]:
        file_name = f"{file_prefix}.csv"
    else:
        file_name = f"{file_prefix}-{data_date.strftime('%d%b%Y').upper()}.csv"

    file_path = directory_path / file_name

    with open(file_path, "w", newline="") as f:
        f_csv = csv.writer(f)
        keys = list(data[0].keys())
        f_csv.writerow(keys)
        for row in data:
            f_csv.writerow([row.get(key, "") for key in keys])

    print(f"Saved {file_name} to {file_path}")

def fetch_and_save_report7():
    """
    Fetches data from the /get-report7 API and saves it as a CSV file.
    """
    report_url = f"{API_URL}/get-report7"
    resp = requests.get(report_url)
    
    if resp.ok:
        response = resp.json()
        data = response.get('data')
        data_date = response.get('date')
        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"5.daily_high_low_range_report.csv"
        file_path = directory_path / file_name  # Save in the custom directory
        
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                'TICKER',
                'NSE CODE',
                'GOOGLE CODE',
                'LAST PRICE',
                'ATM STRIKE',
                'ATM CE VALUE',
                'ATM PE VALUE',
                'UPPER BAND CONS',
                'LOWER BAND CONS',
                'COMBINED PREMIUM',
                '% PREMIUM'
            ])
            
            for x in data:
                combined_premium = round((x.get("ATM CE VALUE") or 0) + (x.get("ATM PE VALUE") or 0), 2)
                last_price = x.get("LAST PRICE", 0)
                percent_premium = f"{round((combined_premium / last_price) * 100, 2)}%" if last_price else "0.00%"
                
                f_csv.writerow([
                    x['TICKER'],
                    x['NSE CODE'],
                    x['GOOGLE CODE'],
                    last_price,
                    x.get("ATM STRIKE", 0),
                    x.get("ATM CE VALUE", 0),
                    x.get("ATM PE VALUE", 0),
                    x.get("UPPER BAND CONS", 0),
                    x.get("LOWER BAND CONS", 0),
                    combined_premium,
                    percent_premium
                ])
        print(f"Saved {file_name} to {file_path}")
    else:
        print(f"Failed to fetch data from {report_url}")

def fetch_and_save_report6():
    """
    Fetches data from the /get-report6 API and saves it as a CSV file.
    """
    report_url = f"{API_URL}/get-report6"
    resp = requests.get(report_url)
    
    if resp.ok:
        response = resp.json()
        data = response.get('data')
        if not data:
            print("No data returned for get-report6")
            return
        data_date = response.get('date')
        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"4.monthly_high_low_range_report.csv"
        file_path = directory_path / file_name  # Save in the custom directory
        
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                'TICKER',
                'NSE CODE',
                'GOOGLE CODE',
                'LAST PRICE',
                'ATM STRIKE',
                'ATM CE VALUE',
                'ATM PE VALUE',
                'UPPER BAND CONS',
                'LOWER BAND CONS',
                'COMBINED PREMIUM',
                '% PREMIUM'
            ])
            
            for x in data:
                atm_ce_value = x.get("ATM CE VALUE", 0) or 0
                atm_pe_value = x.get("ATM PE VALUE", 0) or 0
                last_price = x.get("LAST PRICE", 0) or 0
                combined_premium = round(float(atm_ce_value) + float(atm_pe_value), 2)
                percent_premium = f"{round((combined_premium / last_price) * 100, 2)}%" if last_price else "0.00%"
                
                f_csv.writerow([
                    x.get('TICKER', ''),
                    x.get('NSE CODE', ''),
                    x.get('GOOGLE CODE', ''),
                    last_price,
                    x.get("ATM STRIKE", 0),
                    atm_ce_value,
                    atm_pe_value,
                    x.get("UPPER BAND CONS", 0),
                    x.get("LOWER BAND CONS", 0),
                    combined_premium,
                    percent_premium
                ])
        print(f"Saved {file_name} to {file_path}")
    else:
        print(f"Failed to fetch data from {report_url}")

def synthetic_generator_data_report():
    """
    Fetches data from the /get-report2 API and saves it as a CSV file.
    """
    report_url = f"{API_URL}/get-report2"
    resp = requests.get(report_url)
    
    if resp.ok:
        response = resp.json()
        data = response.get('data', [])
        data_date = response.get('date')
        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"2.stock_generator-report.csv"
        file_path = directory_path / file_name  # Save in the custom directory
        
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                "Symbol", "Lot Size", "Future OI", "Change (Future OI)", "# of lots change (Future OI)",
                "% Change in Future_OI", "PE OI", "Change (PE OI)", "# of lots change (PE OI)",
                "% Change (PE OI)", "CE OI", "Change (CE OI)", "# of lots change (CE OI)",
                "% Change (CE OI)", "VWAP", "CLOSE PRICE", "Change CE / PE Ratio (OI)",
                "Delivery %", "% Change in Price", "% Change in Price From Low",
                "% Change in Price From High", "Decision (Based on Options",
                "Decision (Based on Futures", "Decision (Based on Price"
            ])

            for x in data:
                f_csv.writerow([
                    x.get('Symbol', ''),
                    x.get('Lot Size', ''),
                    x.get("Future OI", ''),
                    x.get("Change (Future OI)", ''),
                    x.get("# of lots change (Future OI)", ''),
                    x.get("% Change in Future_OI", ''),
                    x.get("PE OI", ''),
                    x.get("Change (PE OI)", ''),
                    x.get("# of lots change (PE OI)", ''),
                    x.get("% Change (PE OI)", ''),
                    x.get("CE OI", ''),
                    x.get("Change (CE OI)", ''),
                    x.get("# of lots change (CE OI)", ''),
                    x.get("% Change (CE OI)", ''),
                    x.get("VWAP", ''),
                    x.get("CLOSE PRICE", ''),
                    x.get("Change CE / PE Ratio (OI)", ''),
                    x.get("Delivery %", ''),
                    x.get("% Change in Price", ''),
                    x.get("% Change in Price From Low", ''),
                    x.get("% Change in Price From High", ''),
                    x.get("Decision (Based on Options", ''),
                    x.get("Decision (Based on Futures", ''),
                    x.get("Decision (Based on Price", '')
                ])
        print(f"Saved {file_name} to {file_path}")
    else:
        print(f"Failed to fetch data from {report_url}")  


def combine_reports_and_send_email():
    """
    Combines all CSV reports into a single Excel file and sends it via email.
    Deletes all files in the directory after the email is sent successfully.
    """
    folder_path = directory_path  # Make sure directory_path is defined
    today = datetime.now().strftime("%Y-%m-%d")
    output_excel_file = f"all_reports_data {today}.xlsx"

    # Get all CSV files
    csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]
    
    if not csv_files:
        print("No CSV files found in the directory. Email not sent.")
        return  # Exit the function if no CSVs found

    try:
        with pd.ExcelWriter(output_excel_file, engine='openpyxl') as writer:
            for file_name in csv_files:
                file_path = os.path.join(folder_path, file_name)
                
                try:
                    df = pd.read_csv(file_path)
                    sheet_name = os.path.splitext(file_name)[0][:30]

                    print(f"{file_name} rows: {len(df)}")

                    df.to_excel(writer, sheet_name=sheet_name, index=False)

                    print(f"Added {file_name} to sheet: {sheet_name}")
                except Exception as e:
                    print(f"Error processing {file_name}: {e}")
                    continue

        print(f"All files have been combined into {output_excel_file}")

        # Only proceed with email if Excel file was created
        if os.path.exists(output_excel_file):
            sender_email = settings.SMTP_USER
            bcc_recipients = ["mohammedimran0266@gmail.com", "jagadeeshkomati@gmail.com"]
            subject = f"Automated Final Report - {today}"
            body = "Latest all reports data."

            msg = EmailMessage()
            msg["From"] = sender_email
            msg["Subject"] = subject
            msg.set_content(body)

            with open(output_excel_file, "rb") as file:
                msg.add_attachment(
                    file.read(),
                    maintype="application",
                    subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    filename=output_excel_file
                )

            smtp_server = settings.SMTP_HOST or "smtp.gmail.com"
            smtp_port = settings.SMTP_PORT or 587
            email_password = settings.SMTP_PASSWORD

            # Dry-run guard: build the Excel but do not send (for testing).
            if os.environ.get("REPORTS_DRY_RUN"):
                print(f"[DRY RUN] Excel built ({output_excel_file}); email NOT sent. "
                      f"Would BCC: {bcc_recipients}")
                return

            try:
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                    server.starttls()
                    server.login(sender_email, email_password)
                    server.sendmail(sender_email, bcc_recipients, msg.as_string())
                print(f"Email sent successfully to BCC recipients: {bcc_recipients}")
                clear_directory()
            except Exception as e:
                print(f"Failed to send email: {e}")
                with open("error_log.txt", "a") as f:
                    f.write(f"{datetime.now()} - Email failed: {e}\n")
        else:
            print("Excel file was not created, email not sent")

    except Exception as e:
        print(f"Error creating Excel file: {e}")
        with open("error_log.txt", "a") as f:
            f.write(f"{datetime.now()} - Excel creation failed: {e}\n")


    # Send email
    # sender_email = "bhargavmoparthi@gmail.com"
    # receiver_email = ["asirinaidu1990@gmail.com", "mohammedimran0266@gmail.com","bhargavmoparthi@gmail.com"]
    
    # sender_email = "kpdasari@gmail.com"
    # sender_email = "engineering@quantlabalgo.com"
    # receiver_email = ["kpdasari@gmail.com","rsriwastava@gmail.com"]
    # subject = f"Automated Final Report - {today}"
    # body = "Latest all reports data."

    # msg = EmailMessage()
    # msg["From"] = sender_email
    # msg["To"] = receiver_email
    # msg["Subject"] = subject
    # msg.set_content(body)

    # with open(output_excel_file, "rb") as file:
    #     msg.add_attachment(file.read(), maintype="application",
    #                        subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    #                        filename=output_excel_file)

    # smtp_server = "smtp.gmail.com"
    # smtp_port = 587
    # # email_password = "pxvm ggis dtlq rfhk"
    # # email_password = "wmhe pquz curh rugz"
    # email_password = "qkpa vffn ryli chvk"  

    # try:
    #     with smtplib.SMTP(smtp_server, smtp_port) as server:
    #         server.starttls()
    #         server.login(sender_email, email_password)
    #         server.send_message(msg)
    #     print(f"Email sent successfully to {receiver_email}")

    #     # Delete all files in the directory after successful email send
    #     clear_directory()

    # except Exception as e:
    #     print(f"Failed to send email: {e}")
    #     with open("error_log.txt", "a") as f:
    #         f.write(f"{datetime.now()} - Email failed: {e}\n")

if __name__ == "__main__":
    # Clear the directory before starting
    clear_directory()

    # Fetch and save reports
    fetch_and_save_report("get-all-data-csv-report", "1.all data csv report")
    fetch_and_save_report("get-report3", "3.initial Series Stock OI report")
    fetch_and_save_report7()
    fetch_and_save_report6()
    synthetic_generator_data_report()

    # Combine reports and send emai
    combine_reports_and_send_email()


###########################################################################################################################################


# from datetime import datetime, timedelta
# from pathlib import Path
# import requests
# import csv
# import os
# import pandas as pd
# import smtplib
# from email.message import EmailMessage
# import shutil

# # Define the custom directory path
# directory_path = Path(r"C:\Page_Projects\trading\nse-scraper\Output")

# # Check if the directory exists
# if not directory_path.exists():
#     # Create the directory if it doesn't exist
#     directory_path.mkdir(parents=True)
#     print(f"Directory '{directory_path}' created.")

# # API URL
# API_URL = "http://127.0.0.1:9009"

# def clear_directory():
#     """
#     Clears all files in the directory.
#     """
#     for file_name in os.listdir(directory_path):
#         file_path = os.path.join(directory_path, file_name)
#         try:
#             if os.path.isfile(file_path) or os.path.islink(file_path):
#                 os.unlink(file_path)
#                 print(f"Deleted {file_name}")
#             elif os.path.isdir(file_path):
#                 shutil.rmtree(file_path)
#                 print(f"Deleted directory {file_name}")
#         except Exception as e:
#             print(f"Failed to delete {file_name}. Reason: {e}")

# def fetch_and_save_report(report_name, file_prefix):
#     """
#     Fetches data from the API and saves it as a CSV file.
#     """
#     report_url = f"{API_URL}/{report_name}"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
        
#         # Check if the report is either 'get-all-data-csv-report' or 'get-report3'
#         if report_name in ["get-all-data-csv-report", "get-report3"]:
#             file_name = f"{file_prefix}.csv"  # Exclude the date from the file name
#         else:
#             file_name = f"{file_prefix}-{data_date.strftime('%d%b%Y').upper()}.csv"
        
#         file_path = directory_path / file_name  # Save in the custom directory
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             keys = list(data[0].keys())
#             f_csv.writerow(keys)
#             for x in data:
#                 f_csv.writerow([x[key] for key in keys])
#         print(f"Saved {file_name} to {file_path}")
#     else:
#         print(f"Failed to fetch data from {report_url}")

# def fetch_and_save_report7():
#     """
#     Fetches data from the /get-report7 API and saves it as a CSV file.
#     """
#     report_url = f"{API_URL}/get-report7"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"5.daily_high_low_range_report.csv"
#         file_path = directory_path / file_name  # Save in the custom directory
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 'TICKER',
#                 'NSE CODE',
#                 'GOOGLE CODE',
#                 'LAST PRICE',
#                 'ATM STRIKE',
#                 'ATM CE VALUE',
#                 'ATM PE VALUE',
#                 'UPPER BAND CONS',
#                 'LOWER BAND CONS',
#                 'COMBINED PREMIUM',
#                 '% PREMIUM'
#             ])
            
#             for x in data:
#                 combined_premium = round((x.get("ATM CE VALUE") or 0) + (x.get("ATM PE VALUE") or 0), 2)
#                 last_price = x.get("LAST PRICE", 0)
#                 percent_premium = f"{round((combined_premium / last_price) * 100, 2)}%" if last_price else "0.00%"
                
#                 f_csv.writerow([
#                     x['TICKER'],
#                     x['NSE CODE'],
#                     x['GOOGLE CODE'],
#                     last_price,
#                     x.get("ATM STRIKE", 0),
#                     x.get("ATM CE VALUE", 0),
#                     x.get("ATM PE VALUE", 0),
#                     x.get("UPPER BAND CONS", 0),
#                     x.get("LOWER BAND CONS", 0),
#                     combined_premium,
#                     percent_premium
#                 ])
#         print(f"Saved {file_name} to {file_path}")
#     else:
#         print(f"Failed to fetch data from {report_url}")

# def fetch_and_save_report6():
#     """
#     Fetches data from the /get-report6 API and saves it as a CSV file.
#     """
#     report_url = f"{API_URL}/get-report6"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"4.monthly_high_low_range_report.csv"
#         file_path = directory_path / file_name  # Save in the custom directory
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 'TICKER',
#                 'NSE CODE',
#                 'GOOGLE CODE',
#                 'LAST PRICE',
#                 'ATM STRIKE',
#                 'ATM CE VALUE',
#                 'ATM PE VALUE',
#                 'UPPER BAND CONS',
#                 'LOWER BAND CONS',
#                 'COMBINED PREMIUM',
#                 '% PREMIUM'
#             ])
            
#             for x in data:
#                 atm_ce_value = x.get("ATM CE VALUE", 0) or 0
#                 atm_pe_value = x.get("ATM PE VALUE", 0) or 0
#                 last_price = x.get("LAST PRICE", 0) or 0
#                 combined_premium = round(float(atm_ce_value) + float(atm_pe_value), 2)
#                 percent_premium = f"{round((combined_premium / last_price) * 100, 2)}%" if last_price else "0.00%"
                
#                 f_csv.writerow([
#                     x.get('TICKER', ''),
#                     x.get('NSE CODE', ''),
#                     x.get('GOOGLE CODE', ''),
#                     last_price,
#                     x.get("ATM STRIKE", 0),
#                     atm_ce_value,
#                     atm_pe_value,
#                     x.get("UPPER BAND CONS", 0),
#                     x.get("LOWER BAND CONS", 0),
#                     combined_premium,
#                     percent_premium
#                 ])
#         print(f"Saved {file_name} to {file_path}")
#     else:
#         print(f"Failed to fetch data from {report_url}")

# def synthetic_generator_data_report():
#     """
#     Fetches data from the /get-report2 API and saves it as a CSV file.
#     """
#     report_url = f"{API_URL}/get-report2"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data', [])
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"2.stock_generator-report.csv"
#         file_path = directory_path / file_name  # Save in the custom directory
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 "Symbol", "Lot Size", "Future OI", "Change (Future OI)", "# of lots change (Future OI)",
#                 "% Change in Future_OI", "PE OI", "Change (PE OI)", "# of lots change (PE OI)",
#                 "% Change (PE OI)", "CE OI", "Change (CE OI)", "# of lots change (CE OI)",
#                 "% Change (CE OI)", "VWAP", "CLOSE PRICE", "Change CE / PE Ratio (OI)",
#                 "Delivery %", "% Change in Price", "% Change in Price From Low",
#                 "% Change in Price From High", "Decision (Based on Options",
#                 "Decision (Based on Futures", "Decision (Based on Price"
#             ])

#             for x in data:
#                 f_csv.writerow([
#                     x.get('Symbol', ''),
#                     x.get('Lot Size', ''),
#                     x.get("Future OI", ''),
#                     x.get("Change (Future OI)", ''),
#                     x.get("# of lots change (Future OI)", ''),
#                     x.get("% Change in Future_OI", ''),
#                     x.get("PE OI", ''),
#                     x.get("Change (PE OI)", ''),
#                     x.get("# of lots change (PE OI)", ''),
#                     x.get("% Change (PE OI)", ''),
#                     x.get("CE OI", ''),
#                     x.get("Change (CE OI)", ''),
#                     x.get("# of lots change (CE OI)", ''),
#                     x.get("% Change (CE OI)", ''),
#                     x.get("VWAP", ''),
#                     x.get("CLOSE PRICE", ''),
#                     x.get("Change CE / PE Ratio (OI)", ''),
#                     x.get("Delivery %", ''),
#                     x.get("% Change in Price", ''),
#                     x.get("% Change in Price From Low", ''),
#                     x.get("% Change in Price From High", ''),
#                     x.get("Decision (Based on Options", ''),
#                     x.get("Decision (Based on Futures", ''),
#                     x.get("Decision (Based on Price", '')
#                 ])
#         print(f"Saved {file_name} to {file_path}")
#     else:
#         print(f"Failed to fetch data from {report_url}")  

# def combine_reports_and_send_email():
#     """
#     Combines all CSV reports into a single Excel file and sends it via email.
#     Deletes all files in the directory after the email is sent successfully.
#     """
#     folder_path = directory_path  # Use the custom directory
#     yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
#     output_excel_file = f"all_reports_data {yesterday}.xlsx"

#     # Track processed files to avoid duplicates
#     processed_files = set()

#     with pd.ExcelWriter(output_excel_file, engine='openpyxl') as writer:
#         for file_name in os.listdir(folder_path):
#             file_path = os.path.join(folder_path, file_name)

#             # Skip non-CSV files and already processed files
#             if not file_name.endswith(".csv") or file_name in processed_files:
#                 continue

#             # Add the file to the processed set
#             processed_files.add(file_name)

#             # Read the CSV file
#             df = pd.read_csv(file_path)

#             # Create a sheet name (limit to 30 characters for Excel compatibility)
#             sheet_name = os.path.splitext(file_name)[0][:30]
#             df.to_excel(writer, sheet_name=sheet_name, index=False)
#             print(f"Added {file_name} to sheet: {sheet_name}")

#     print(f"All files have been combined into {output_excel_file}")

#     # Send email
#     # sender_email = "bhargavmoparthi@gmail.com"
#     # receiver_email = ["asirinaidu1990@gmail.com", "mohammedimran0266@gmail.com","bhargavmoparthi@gmail.com"]
    
#     sender_email = "kpdasari@gmail.com"
#     receiver_email = ["kpdasari@gmail.com","rsriwastava@gmail.com"]
#     subject = f"Automated Final Report - {yesterday}"
#     body = f"Latest all reports data for {yesterday}."

#     msg = EmailMessage()
#     msg["From"] = sender_email
#     msg["To"] = receiver_email
#     msg["Subject"] = subject
#     msg.set_content(body)

#     with open(output_excel_file, "rb") as file:
#         msg.add_attachment(file.read(), maintype="application",
#                            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
#                            filename=output_excel_file)

#     smtp_server = "smtp.gmail.com"
#     smtp_port = 587
#     email_password = "pxvm ggis dtlq rfhk"
#     # email_password = "wmhe pquz curh rugz"

#     try:
#         with smtplib.SMTP(smtp_server, smtp_port) as server:
#             server.starttls()
#             server.login(sender_email, email_password)
#             server.send_message(msg)
#         print(f"Email sent successfully to {receiver_email}")

#         # Delete all files in the directory after successful email send
#         clear_directory()

#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         with open("error_log.txt", "a") as f:
#             f.write(f"{datetime.now()} - Email failed: {e}\n")

# if __name__ == "__main__":
#     # Clear the directory before starting
#     clear_directory()

#     # Fetch and save reports
#     fetch_and_save_report("get-all-data-csv-report", "1.all data csv report")
#     fetch_and_save_report("get-report3", "3.initial Series Stock OI report")
#     fetch_and_save_report7()
#     fetch_and_save_report6()
#     synthetic_generator_data_report()

#     # Combine reports and send email
#     combine_reports_and_send_email()