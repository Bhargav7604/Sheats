# from datetime import datetime
# from pathlib import Path
# import requests
# import csv

# # Define the directory path
# directory_path = Path('./Output')

# # Check if the directory exists
# if not directory_path.exists():
#     # Create the directory if it doesn't exist
#     directory_path.mkdir(parents=True)

# # API_URL = "https://intranet.cytrion.com/trading-api"
# API_URL = "http://127.0.0.1:9009"

# if __name__ == "__main__":
#     report_url = f"{API_URL}/get-report7"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"monthly_high_low_range_report-{data_date.strftime('%d%b%Y').upper()}.csv"

#         file_path = directory_path / file_name
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 'NSE CODE',
#                 'LAST PRICE',
#                 'ATM STRIKE',
#                 'ATM CE VALUE',
#                 'ATM PE VALUE',
#                 'UPPER BAND CONS',
#                 'LOWER BAND CONS',
#                 'PRICE NOW',
#                 'DIFF FROM UPPER BAND',
#                 'DIFF FROM LOWER BAND',
#                 'PRICE CHG%',
#                 'MOVE FROM CALL TRAP',
#                 'MOVE FROM PUT TRAP',
#                 'YEST CLOSE',
#                 'LONG?',
#                 'DAY HIGH',
#                 'DAY LOW',
#                 'SPACE1',
#                 'SPACE2',
#                 'SHORT?',
#                 'WAIT PERIOD DOWN',
#                 'RETURN SO FAR',
#                 'CHANGE FOR MONTH',
#                 '%CHANGE OF MONTH',
#                 'MEDIAN',
#                 'MEDIAN%']
#             )
            
#             for x in data:
#                 # Ensure no None values
#                 atm_ce_value = x.get("ATM CE VALUE", 0) or 0
#                 atm_pe_value = x.get("ATM PE VALUE", 0) or 0
#                 last_price = x.get("LAST PRICE", 0) or 0

                
#                 f_csv.writerow([
#                     x.get('NSE CODE', ''),
#                     last_price,
#                     x.get("ATM STRIKE", 0),
#                     atm_ce_value,
#                     atm_pe_value,
#                     x.get("UPPER BAND CONS", 0),
#                     x.get("LOWER BAND CONS", 0),
#                 ])


# from datetime import datetime
# from pathlib import Path
# import requests
# import csv

# # Define the directory path
# directory_path = Path('./Output')

# # Check if the directory exists
# if not directory_path.exists():
#     # Create the directory if it doesn't exist
#     directory_path.mkdir(parents=True)

# API_URL = "http://127.0.0.1:9009"

# if __name__ == "__main__":
#     report_url = f"{API_URL}/get-report6"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"trap_report-{data_date.strftime('%d%b%Y').upper()}.csv"

#         file_path = directory_path / file_name
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 'NSE CODE',
#                 'LAST PRICE',
#                 'ATM STRIKE',
#                 'ATM CE VALUE',
#                 'ATM PE VALUE',
#                 'UPPER BAND CONS',
#                 'LOWER BAND CONS',
#                 'PRICE NOW',
#                 'DIFF FROM UPPER BAND',
#                 'DIFF FROM LOWER BAND',
#                 'PRICE CHG%',
#                 'MOVE FROM CALL TRAP',
#                 'MOVE FROM PUT TRAP',
#                 'YEST CLOSE',
#                 'LONG?',
#                 'DAY HIGH',
#                 'DAY LOW',
#                 'SPACE1',
#                 'SPACE2',
#                 'SHORT?',
#                 'WAIT PERIOD DOWN',
#                 'RETURN SO FAR',
#                 'CHANGE FOR MONTH',
#                 '%CHANGE OF MONTH',
#                 'MEDIAN',
#                 'MEDIAN%'
#             ])
            
#             for x in data:
#                 f_csv.writerow([
#                     x.get('NSE CODE', ''),
#                     x.get('LAST PRICE', ''),
#                     x.get('ATM STRIKE', ''),
#                     x.get('ATM CE VALUE', ''),
#                     x.get('ATM PE VALUE', ''),
#                     x.get('UPPER BAND CONS', ''),
#                     x.get('LOWER BAND CONS', ''),
#                     x.get('PRICE NOW', ''),
#                     x.get('DIFF FROM UPPER BAND', ''),
#                     x.get('DIFF FROM LOWER BAND', ''),
#                     x.get('PRICE CHG%', ''),
#                     x.get('MOVE FROM CALL TRAP', ''),
#                     x.get('MOVE FROM PUT TRAP', ''),
#                     x.get('YEST CLOSE', ''),
#                     x.get('LONG?', ''),
#                     x.get('DAY HIGH', ''),
#                     x.get('DAY LOW', ''),
#                     x.get('SPACE1', ''),
#                     x.get('SPACE2', ''),
#                     x.get('SHORT?', ''),
#                     x.get('WAIT PERIOD DOWN', ''),
#                     x.get('RETURN SO FAR', ''),
#                     x.get('CHANGE FOR MONTH', ''),
#                     x.get('%CHANGE OF MONTH', ''),
#                     x.get('MEDIAN', ''),
#                     x.get('MEDIAN%', '')
#                 ])
    
#     print(f"CSV file saved to: {file_path}")



# from datetime import datetime
# from pathlib import Path
# import requests
# import csv

# # Define the directory path
# directory_path = Path('./Output')

# # Check if the directory exists
# if not directory_path.exists():
#     directory_path.mkdir(parents=True)

# API_URL = "http://127.0.0.1:9009"

# if __name__ == "__main__":
#     report_url = f"{API_URL}/get-report6"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"trap_report-{data_date.strftime('%d%b%Y').upper()}.csv"

#         file_path = directory_path / file_name
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 'NSE CODE', 'LAST PRICE', 'ATM STRIKE', 'ATM CE VALUE', 'ATM PE VALUE',
#                 'UPPER BAND CONS', 'LOWER BAND CONS', 'PRICE NOW', 'DIFF FROM UPPER BAND',
#                 'DIFF FROM LOWER BAND', 'PRICE CHG%', 'MOVE FROM CALL TRAP', 'MOVE FROM PUT TRAP',
#                 'YEST CLOSE', 'LONG?', 'DAY HIGH', 'DAY LOW', 'SPACE1', 'SPACE2', 'SHORT?',
#                 'WAIT PERIOD UP', 'WAIT PERIOD DOWN', 'RETURN SO FAR', 'CHANGE FOR MONTH',
#                 '%CHANGE OF MONTH', 'MEDIAN', 'MEDIAN%'
#             ])
            
#             for x in data:
#                 price_now = float(x.get('PRICE NOW', 0) or 0)
#                 upper_band = float(x.get('UPPER BAND CONS', 0) or 0)
#                 lower_band = float(x.get('LOWER BAND CONS', 0) or 0)
#                 atm_ce_value = float(x.get('ATM CE VALUE', 0) or 0)
#                 atm_pe_value = float(x.get('ATM PE VALUE', 0) or 0)
#                 atm_strike = float(x.get('ATM STRIKE', 0) or 0)
#                 yest_close = float(x.get('YEST CLOSE', 0) or 1)  # Avoid division by zero
#                 first_day_price = float(x.get('First Day PRICE', 0) or 1)
#                 col_h = float(x.get('Col H', 0) or 1)
#                 col_i = float(x.get('COL I', 0) or 0)
#                 col_j = float(x.get('COL J', 0) or 0)
#                 col_aa = float(x.get('Col AA', 0) or 0)

#                 # Apply formulas
#                 diff_from_upper_band = upper_band - price_now
#                 diff_from_lower_band = price_now - lower_band
#                 price_chg_perc = (price_now / yest_close) * 100 if yest_close else 0
#                 move_from_call_trap = col_i / col_h if col_h else 0
#                 move_from_put_trap = col_j / col_h if col_h else 0
#                 long_signal = "Go-Ahead" if price_now > atm_ce_value else ""
#                 short_signal = "Go-Ahead" if price_now < atm_pe_value else ""
#                 wait_period_up = atm_ce_value + atm_strike
#                 wait_period_down = atm_pe_value - atm_strike
#                 return_so_far = price_now - yest_close
#                 change_for_month = price_now - first_day_price
#                 change_of_month_perc = (change_for_month / first_day_price) * 100 if first_day_price else 0
#                 median_perc = col_aa / col_h if col_h else 0

#                 # Write data to CSV
#                 f_csv.writerow([
#                     x.get('NSE CODE', ''),
#                     x.get('LAST PRICE', ''),
#                     atm_strike,
#                     atm_ce_value,
#                     atm_pe_value,
#                     upper_band,
#                     lower_band,
#                     price_now,
#                     diff_from_upper_band,
#                     diff_from_lower_band,
#                     price_chg_perc,
#                     move_from_call_trap,
#                     move_from_put_trap,
#                     yest_close,
#                     long_signal,
#                     x.get('DAY HIGH', ''),
#                     x.get('DAY LOW', ''),
#                     x.get('SPACE1', ''),
#                     x.get('SPACE2', ''),
#                     short_signal,
#                     wait_period_up,
#                     wait_period_down,
#                     return_so_far,
#                     change_for_month,
#                     change_of_month_perc,
#                     x.get('MEDIAN', ''),
#                     median_perc
#                 ])
    
#     print(f"CSV file saved to: {file_path}")


# from datetime import datetime
# from pathlib import Path
# import requests
# import csv

# # Define the directory path
# directory_path = Path('./Output')

# # Check if the directory exists
# if not directory_path.exists():
#     directory_path.mkdir(parents=True)

# API_URL = "http://127.0.0.1:9009"

# if __name__ == "__main__":
#     report_url = f"{API_URL}/get-report6"
#     resp = requests.get(report_url)
    
#     if resp.ok:
#         response = resp.json()
#         data = response.get('data')
#         data_date = response.get('date')
#         data_date = datetime.strptime(data_date, '%Y-%m-%d')
#         file_name = f"trap_report-{data_date.strftime('%d%b%Y').upper()}.csv"

#         file_path = directory_path / file_name
        
#         with open(file_path, "w", newline='') as f:
#             f_csv = csv.writer(f)
#             f_csv.writerow([
#                 'NSE CODE', 'LAST PRICE', 'ATM STRIKE', 'ATM CE VALUE', 'ATM PE VALUE',
#                 'UPPER BAND CONS', 'LOWER BAND CONS', 'PRICE NOW', 'DIFF FROM UPPER BAND',
#                 'DIFF FROM LOWER BAND', 'PRICE CHG%', 'MOVE FROM CALL TRAP', 'MOVE FROM PUT TRAP',
#                 'YEST CLOSE', 'LONG?', 'DAY HIGH', 'DAY LOW', 'SPACE1', 'SPACE2', 'SHORT?',
#                 'WAIT PERIOD UP', 'WAIT PERIOD DOWN', 'RETURN SO FAR', 'CHANGE FOR MONTH',
#                 '%CHANGE OF MONTH', 'MEDIAN', 'MEDIAN%'
#             ])
            
#             for x in data:
#                 price_now = float(x.get('PRICE NOW', 0) or 0)
#                 upper_band_cons = float(x.get('UPPER BAND CONS', 0) or 0)
#                 lower_band_cons = float(x.get('LOWER BAND CONS', 0) or 0)
#                 atm_ce_value = float(x.get('ATM CE VALUE', 0) or 0)
#                 atm_pe_value = float(x.get('ATM PE VALUE', 0) or 0)
#                 atm_strike = float(x.get('ATM STRIKE', 0) or 0)
#                 yest_close = float(x.get('YEST CLOSE', 0) or 1)  # Avoid division by zero
#                 first_day_price = float(x.get('FIRST DAY PRICE', 0) or 1)
#                 total_trapped_premium = float(x.get('TOTAL TRAPPED PREMIUM', 0) or 1)
#                 call_trap_premium = float(x.get('CALL TRAP PREMIUM', 0) or 0)
#                 put_trap_premium = float(x.get('PUT TRAP PREMIUM', 0) or 0)
#                 median_value = float(x.get('MEDIAN VALUE', 0) or 0)

#                 # Apply formulas
#                 diff_from_upper_band = upper_band_cons - price_now
#                 diff_from_lower_band = price_now - lower_band_cons
#                 price_change_percent = (price_now / yest_close) * 100 if yest_close else 0
#                 move_from_call_trap = call_trap_premium / total_trapped_premium if total_trapped_premium else 0
#                 move_from_put_trap = put_trap_premium / total_trapped_premium if total_trapped_premium else 0
#                 long_signal = "Go-Ahead" if price_now > atm_ce_value else ""
#                 short_signal = "Go-Ahead" if price_now < atm_pe_value else ""
#                 wait_period_up = atm_ce_value + atm_strike
#                 wait_period_down = atm_pe_value - atm_strike
#                 return_so_far = price_now - yest_close
#                 change_for_month = price_now - first_day_price
#                 change_of_month_percent = (change_for_month / first_day_price) * 100 if first_day_price else 0
#                 median_percent = median_value / total_trapped_premium if total_trapped_premium else 0

#                 # Write data to CSV
#                 f_csv.writerow([
#                     x.get('NSE CODE', ''),
#                     x.get('LAST PRICE', ''),
#                     atm_strike,
#                     atm_ce_value,
#                     atm_pe_value,
#                     upper_band_cons,
#                     lower_band_cons,
#                     price_now,
#                     diff_from_upper_band,
#                     diff_from_lower_band,
#                     price_change_percent,
#                     move_from_call_trap,
#                     move_from_put_trap,
#                     yest_close,
#                     long_signal,
#                     x.get('DAY HIGH', ''),
#                     x.get('DAY LOW', ''),
#                     x.get('SPACE1', ''),
#                     x.get('SPACE2', ''),
#                     short_signal,
#                     wait_period_up,
#                     wait_period_down,
#                     return_so_far,
#                     change_for_month,
#                     change_of_month_percent,
#                     x.get('MEDIAN', ''),
#                     median_percent
#                 ])
    
#     print(f"CSV file saved to: {file_path}")



from datetime import datetime
from pathlib import Path
import requests
import csv

# Define the directory path
directory_path = Path('./Output')

# Check if the directory exists
if not directory_path.exists():
    directory_path.mkdir(parents=True)

API_URL = "http://127.0.0.1:9009"

if __name__ == "__main__":
    report_url = f"{API_URL}/get-report6"
    resp = requests.get(report_url) 
    
    if resp.ok:
        response = resp.json()
        data = response.get('data')
        data_date = response.get('date')
        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"trap_report-{data_date.strftime('%d%b%Y').upper()}.csv"

        file_path = directory_path / file_name
        
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                'NSE CODE', 'LAST PRICE', 'ATM STRIKE', 'ATM CE VALUE', 'ATM PE VALUE',
                'UPPER BAND CONS', 'LOWER BAND CONS', 'PRICE NOW', 'DIFF FROM UPPER BAND',
                'DIFF FROM LOWER BAND', 'PRICE CHG%', 'MOVE FROM CALL TRAP', 'MOVE FROM PUT TRAP',
                'YEST CLOSE', 'LONG?', 'DAY HIGH', 'DAY LOW', 'SPACE1', 'SPACE2', 'SHORT?',
                'WAIT PERIOD UP', 'WAIT PERIOD DOWN', 'RETURN SO FAR', 'CHANGE FOR MONTH',
                '%CHANGE OF MONTH', 'MEDIAN', 'MEDIAN%'
            ])
            
            for x in data:
                price_now = float(x.get('PRICE NOW', 0) or 0)  # Get from Dhan Stream
                upper_band_cons = float(x.get('UPPER BAND CONS', 0) or 0)
                lower_band_cons = float(x.get('LOWER BAND CONS', 0) or 0)
                atm_ce_value = float(x.get('ATM CE VALUE', 0) or 0)
                atm_pe_value = float(x.get('ATM PE VALUE', 0) or 0)
                atm_strike = float(x.get('ATM STRIKE', 0) or 0)
                yest_close = float(x.get('YEST CLOSE', 0) or 1)  # Get from Dhan Stream
                first_day_price = float(x.get('FIRST DAY PRICE', 0) or 1)
                # print(dir(data))
                

                # Apply formulas
                diff_from_upper_band = price_now - upper_band_cons
                diff_from_lower_band = lower_band_cons - price_now
                price_change_percent = " Get from Dhan Stream "
                move_from_call_trap = diff_from_upper_band - price_now
                move_from_put_trap = diff_from_lower_band - price_now
                long = "Go-Ahead" if yest_close > upper_band_cons else "FALSE"
                short = "Go-Ahead" if yest_close < lower_band_cons else "FALSE"
                space1 = round(upper_band_cons * 0.015, 2)  # UPPER BAND CONS × 1.5%
                space2 = round(lower_band_cons * 0.015, 2)  # LOWER BAND CONS × 1.5%    
                wait_period_up = round(space1 + upper_band_cons, 2)
                wait_period_down = round(lower_band_cons - space2, 2)
                return_so_far = price_now - first_day_price
                change_for_month = price_now - first_day_price
                change_of_month_percent = f"{(change_for_month / first_day_price) * 100:.2f}%"
                median = round(upper_band_cons - lower_band_cons, 2)
                median_percent = f"{(upper_band_cons - lower_band_cons) * 100:.2f}%"
                day_high = " Get from Dhan Stream "
                day_low = " Get from Dhan Stream "

                # Write data to CSV
                f_csv.writerow([
                    x.get('NSE CODE', ''),
                    x.get('LAST PRICE', ''),
                    atm_strike,
                    atm_ce_value,
                    atm_pe_value,
                    upper_band_cons,
                    lower_band_cons,
                    price_now,
                    diff_from_upper_band,   
                    diff_from_lower_band,
                    price_change_percent,
                    move_from_call_trap,
                    move_from_put_trap,
                    yest_close, 
                    long,
                    # x.get('DAY HIGH', ''),
                    # x.get('DAY LOW', ''),
                    day_high,
                    day_low,
                    space1,
                    space2,
                    short,
                    wait_period_up,
                    wait_period_down,
                    return_so_far,
                    change_for_month,
                    change_of_month_percent,
                    # x.get('MEDIAN', ''),
                    median,
                    median_percent
                ])
    print(f"CSV file saved to: {file_path}")