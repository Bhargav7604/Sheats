from datetime import datetime
from pathlib import Path
import requests
import csv

def synthetic_generator_data_report(data_date=None, upload_to_remote_server=False):
    """
    Fetches data from the trading API and generates a CSV report.
    """
    try:
        # Define directory path
        directory_path = Path('./Output').resolve()
        if not directory_path.exists():
            directory_path.mkdir(parents=True)
            print(f"Directory '{directory_path}' created.")

        # Define API details
        API_URL = "http://127.0.0.1:9009"
        report_url = f"{API_URL}/get-report2"
        print(f"Fetching data from API: {report_url}")

        # Make API request
        resp = requests.get(report_url)
        if resp.status_code != 200:
            print(f"Error: Failed to fetch data. HTTP Status Code: {resp.status_code}")
            return

        response = resp.json()
        print("API Response received.")

        # Extract data and date from response
        data = response.get('data', [])
        data_date = response.get('date')
        if not data or not data_date:
            print("Error: No data or date in the API response.")
            return

        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"recommendations-{data_date.strftime('%d%b%Y').upper()}.csv"
        file_path = directory_path / file_name
        print(f"Data will be saved to: {file_path}")

        # Write data to CSV
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                "Symbol", "Lot Size", "Future OI", "Change (Future OI)", "# of lots change (Future OI)",
                "% Change in Future_OI", "PE OI", "Change (PE OI)", "# of lots change (PE OI)",
                "% Change (PE OI)", "CE OI", "Change (CE OI)", "# of lots change (CE OI)",
                "% Change (CE OI)", "VWAP", "CLOSE PRICE", "Change CE / PE Ratio (OI)",
                "Delivery %", "% Change in Price", "% Change in Price From Low",
                "% Change in Price From High", "Decision (Based on Options",
                "Decision (Based on Futures", "Decision (Based on Price"
            ])

            for x in data:
                f_csv.writerow([
                    x.get('Symbol', ''),
                    x.get('Lot Size', ''),
                    x.get("Future OI", ''),
                    x.get("Change (Future OI)", ''),
                    x.get("# of lots change (Future OI)", ''),
                    x.get("% Change in Future_OI", ''),
                    x.get("PE OI", ''),
                    x.get("Change (PE OI)", ''),
                    x.get("# of lots change (PE OI)", ''),
                    x.get("% Change (PE OI)", ''),
                    x.get("CE OI", ''),
                    x.get("Change (CE OI)", ''),
                    x.get("# of lots change (CE OI)", ''),
                    x.get("% Change (CE OI)", ''),
                    x.get("VWAP", ''),
                    x.get("CLOSE PRICE", ''),
                    x.get("Change CE / PE Ratio (OI)", ''),
                    x.get("Delivery %", ''),
                    x.get("% Change in Price", ''),
                    x.get("% Change in Price From Low", ''),
                    x.get("% Change in Price From High", ''),
                    x.get("Decision (Based on Options", ''),
                    x.get("Decision (Based on Futures", ''),
                    x.get("Decision (Based on Price", '')
                ])
        print(f"Data successfully written to {file_path}")
    
    except Exception as e:
        print(f"An error occurred: {e}")

# Call the function for testing
if __name__ == "__main__":
    synthetic_generator_data_report()



from datetime import datetime
from pathlib import Path
import requests
import csv
import mysql.connector

def get_last_updated_date_from_db():
    """
    Fetches the last_updated_date from the updated_testdb database.
    """
    try:
        # MySQL connection details
        db_config = {
            'host': 'localhost',  # Replace with your MySQL host
            'user': 'root',  # Replace with your MySQL username
            'password': 'root',  # Replace with your MySQL password
            'database': 'updated_testdb'  # Replace with your database name
        }
        
        # Connect to the MySQL database
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        # Query to fetch the last_updated_date from your table
        cursor.execute("SELECT last_updated_date FROM your_table_name ORDER BY last_updated_date DESC LIMIT 1;")
        result = cursor.fetchone()
        
        if result:
            # Convert result to a datetime object
            last_updated_date = result[0]
            return last_updated_date
        else:
            print("No last_updated_date found in the database.")
            return None
        
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

