from datetime import datetime
from pathlib import Path
import requests
import csv
import random

# Define the directory path
directory_path = Path('./Output')

# Check if the directory exists
if not directory_path.exists():
    directory_path.mkdir(parents=True)

API_URL = "http://127.0.0.1:9009"

def generate_dhan_stream_data():
    """Generate mock stock market values for simulation."""
    price_now = round(random.uniform(100, 500), 2)  # Simulated live price
    yest_close = round(price_now * random.uniform(0.98, 1.02), 2)  # Close to PRICE NOW
    day_high = round(price_now * random.uniform(1.01, 1.05), 2)  # Slightly higher
    day_low = round(price_now * random.uniform(0.95, 0.99), 2)  # Slightly lower
    price_change_percent = f"{((price_now - yest_close) / yest_close) * 100:.2f}%"  # % change
    
    return price_now, yest_close, day_high, day_low, price_change_percent

if __name__ == "__main__":
    report_url = f"{API_URL}/get-report6"
    resp = requests.get(report_url)
    
    if resp.ok:
        response = resp.json()
        data = response.get('data')
        data_date = response.get('date')
        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"trap_report-{data_date.strftime('%d%b%Y').upper()}.csv"

        file_path = directory_path / file_name
        
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                'NSE CODE', 'LAST PRICE', 'ATM STRIKE', 'ATM CE VALUE', 'ATM PE VALUE',
                'UPPER BAND CONS', 'LOWER BAND CONS', 'PRICE NOW', 'DIFF FROM UPPER BAND',
                'DIFF FROM LOWER BAND', 'PRICE CHG%', 'MOVE FROM CALL TRAP', 'MOVE FROM PUT TRAP',
                'YEST CLOSE', 'LONG?', 'DAY HIGH', 'DAY LOW', 'SPACE1', 'SPACE2', 'SHORT?',
                'WAIT PERIOD UP', 'WAIT PERIOD DOWN', 'RETURN SO FAR', 'CHANGE FOR MONTH',
                '%CHANGE OF MONTH', 'MEDIAN', 'MEDIAN%'
            ])
            
            for x in data:
                # Generate random Dhan Stream data
                price_now, yest_close, day_high, day_low, price_change_percent = generate_dhan_stream_data()

                # Extract API data
                upper_band_cons = float(x.get('UPPER BAND CONS', 0) or 0)
                lower_band_cons = float(x.get('LOWER BAND CONS', 0) or 0)
                atm_ce_value = float(x.get('ATM CE VALUE', 0) or 0)
                atm_pe_value = float(x.get('ATM PE VALUE', 0) or 0)
                atm_strike = float(x.get('ATM STRIKE', 0) or 0)
                first_day_price = float(x.get('FIRST DAY PRICE', 0) or 1)

                # Apply formulas
                diff_from_upper_band = price_now - upper_band_cons
                diff_from_lower_band = lower_band_cons - price_now
                move_from_call_trap = diff_from_upper_band - price_now
                move_from_put_trap = diff_from_lower_band - price_now
                long = "Go-Ahead" if yest_close > upper_band_cons else "FALSE"
                short = "Go-Ahead" if yest_close < lower_band_cons else "FALSE"
                space1 = round(upper_band_cons * 0.015, 2)
                space2 = round(lower_band_cons * 0.015, 2)    
                wait_period_up = round(space1 + upper_band_cons, 2)
                wait_period_down = round(lower_band_cons - space2, 2)
                return_so_far = price_now - first_day_price
                change_for_month = price_now - first_day_price
                change_of_month_percent = f"{(change_for_month / first_day_price) * 100:.2f}%"
                median = round(upper_band_cons - lower_band_cons, 2)
                median_percent = f"{(upper_band_cons - lower_band_cons) * 100:.2f}%"

                # Write data to CSV
                f_csv.writerow([
                    x.get('NSE CODE', ''),
                    x.get('LAST PRICE', ''),
                    atm_strike,
                    atm_ce_value,
                    atm_pe_value,
                    upper_band_cons,
                    lower_band_cons,
                    price_now,
                    diff_from_upper_band,   
                    diff_from_lower_band,
                    price_change_percent,
                    move_from_call_trap,
                    move_from_put_trap,
                    yest_close,
                    long,
                    day_high,
                    day_low,
                    space1,
                    space2,
                    short,
                    wait_period_up,
                    wait_period_down,
                    return_so_far,
                    change_for_month,
                    change_of_month_percent,
                    median,
                    median_percent
                ])
    print(f"CSV file saved to: {file_path}")