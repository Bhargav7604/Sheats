# import os
# import time
# import random
# import requests
# import pandas as pd
# import mysql.connector
# from datetime import datetime, timedelta
# from sqlalchemy import text
# from db import get_db
# from main_old import NSE
# from models.last_updated_date import LastUpdatedDate
# from mysql.connector import Error

# # ========================= MySQL Connection ========================= #
# def create_connection():
#     try:
#         connection = mysql.connector.connect(
#             host='localhost',  
#             database='updated_testdb',  
#             user='root',  
#             password='root'  
#         )
#         if connection.is_connected():
#             print("Connected to MySQL")
#         return connection
#     except Error as e:
#         print(f"MySQL Connection Error: {e}")
#         return None

# # ========================= Insert Data into MySQL ========================= #
# def insert_data_to_db(df, connection):
#     try:
#         cursor = connection.cursor()
#         insert_query = """
#         INSERT INTO cm_index_data (index_name, index_date, open_index_value, high_index_value, 
#                                    low_index_value, closing_index_value, points_change, 
#                                    percentage_change, volume, turnover_in_crores, p_e, p_b, div_yield)
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
#         """
#         for row in df.itertuples(index=False):
#             row = [None if pd.isna(value) else value for value in row]
#             cursor.execute(insert_query, row)

#         connection.commit()
#         print(f"{cursor.rowcount} rows inserted into MySQL.")
#     except Error as e:
#         print(f"MySQL Insert Error: {e}")
#     finally:
#         cursor.close()

# # ========================= Download NSE Index Data ========================= #
# def download_nse_csv():
#     today_date = datetime.today().strftime('%d-%b-%Y')

#     api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={today_date}&type=indices&mode=single"

#     headers = {
#         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
#         "Referer": "https://www.nseindia.com",
#         "Accept-Language": "en-US,en;q=0.9",
#         "Connection": "keep-alive",
#     }

#     session = requests.Session()
#     session.headers.update(headers)
#     homepage_url = "https://www.nseindia.com"
#     session.get(homepage_url)

#     response = session.get(api_url)

#     if response.status_code != 200:
#         print(f"Failed to fetch API data. Status Code: {response.status_code}")
#         print("Response Text:", response.text[:500])
#         return None

#     file_name = f"ind_close_all-{today_date}.csv"
#     save_path = os.path.join(os.getcwd(), file_name)

#     with open(save_path, "wb") as file:
#         file.write(response.content)

#     print(f"cm_index_data Report downloaded successfully: {save_path}")
#     return save_path

# # ========================= Process & Insert CSV into MySQL ========================= #
# def insert_csv_to_db(csv_file_path):
#     try:
#         df = pd.read_csv(csv_file_path)
#         df.columns = df.columns.str.strip()

#         df.rename(columns={
#             'Index Name': 'index_name',
#             'Index Date': 'index_date',
#             'Open Index Value': 'open_index_value',
#             'High Index Value': 'high_index_value',
#             'Low Index Value': 'low_index_value',
#             'Closing Index Value': 'closing_index_value',
#             'Points Change': 'points_change',
#             'Change(%)': 'percentage_change',
#             'Volume': 'volume',
#             'Turnover (Rs. Cr.)': 'turnover_in_crores',
#             'P/E': 'p_e',
#             'P/B': 'p_b',
#             'Div Yield': 'div_yield'
#         }, inplace=True)

#         df['index_date'] = pd.to_datetime(df['index_date'], format='%d-%m-%Y').dt.strftime('%Y-%m-%d')

#         numeric_columns = ['open_index_value', 'high_index_value', 'low_index_value', 
#                            'closing_index_value', 'points_change', 'percentage_change', 
#                            'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield']
        
#         for col in numeric_columns:
#             df[col] = pd.to_numeric(df[col], errors='coerce')

#         df = df.where(pd.notnull(df), None)

#         connection = create_connection()
#         if connection:
#             insert_data_to_db(df, connection)
#             connection.close()

#             # Delete the CSV file after successful insertion
#             os.remove(csv_file_path)
#             print(f"CSV file deleted: {csv_file_path}")

#     except Exception as e:
#         print(f"NSE file, indices_close_all file is unavailable or not yet updated: {e}")

# # ========================= Add Historical Data ========================= #

# def add_historical_data_of_a_date(data_date: datetime):
#     x = NSE()
#     try:
#         data = x.equity_cm_bhavcopy_final(data_date)
#         print("Equity CM Bhavcopy:", data)
#         x.add_equity_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.equity_fo_bhavcopy_final(data_date)
#         print("Equity FO Bhavcopy:", data)
#         x.add_fo_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.securities_bhavdata(data_date)
#         print("Securities Bhavdata:", data)
#         x.add_securities_bhavdata_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)

# # ========================= Main Execution ========================= #
# def main():
#     # Step 1: Download and Insert NSE Index Data
#     downloaded_csv = download_nse_csv()
#     if downloaded_csv:
#         insert_csv_to_db(downloaded_csv)

#     # Step 2: Process Historical Data (Business Days Only)
#     dates = pd.date_range(start=datetime.now().strftime('%Y-%m-%d'), end=datetime.now().strftime('%Y-%m-%d'), freq='B')

#     count = 0
#     for date in dates:
#         add_historical_data_of_a_date(date)

#         if count % 4 == 0:
#             time.sleep(random.randint(1, 2))

#         count += 1

#     # Step 3: Update Last Trade Date in Database
#     with next(get_db()) as db_session:
#         latest_trade_date = db_session.execute(text('SELECT MAX(trade_date) FROM fo_udiff_bhavdata')).scalar()
#         last_updated = db_session.query(LastUpdatedDate).first()
#         if last_updated:
#             last_updated.trade_date = latest_trade_date
#             db_session.commit()
#             print(f"Last Trade Date Updated: {latest_trade_date}")

# # ========================= Run Script ========================= #
# if __name__ == "__main__":
#     main()



import os
import time
import random
import requests
import pandas as pd
import mysql.connector
from datetime import datetime, timedelta
from sqlalchemy import text
from db import get_db
from main_old import NSE
from models.last_updated_date import LastUpdatedDate
from mysql.connector import Error

# ========================= Get Yesterday's Business Day ========================= #
def get_yesterday():
    yesterday = datetime.today() - timedelta(days=1)
    while yesterday.weekday() in [5, 6]:  # Skip Saturday (5) and Sunday (6)
        yesterday -= timedelta(days=1)
    return yesterday.strftime('%d-%b-%Y'), yesterday.strftime('%Y-%m-%d')

# ========================= MySQL Connection ========================= #
def create_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='updated_testdb',
            user='root',
            password='root',
            connect_timeout=30
        )
        if connection.is_connected():
            print("Connected to MySQL database")
        return connection
    except Error as e:
        print(f"MySQL Connection Error: {e}")
        return None

# ========================= Clean DataFrame ========================= #
def clean_dataframe(df):
    # Replace string 'nan' with actual NaN
    df = df.replace('nan', pd.NA)
    
    # Convert numeric columns
    numeric_cols = ['open_index_value', 'high_index_value', 'low_index_value',
                   'closing_index_value', 'points_change', 'percentage_change',
                   'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield']
    
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    return df

# ========================= Verify Database Schema ========================= #
def verify_db_schema(connection):
    try:
        cursor = connection.cursor()
        cursor.execute("DESCRIBE cm_index_data")
        columns = [col[0] for col in cursor.fetchall()]
        required_columns = [
            'index_name', 'index_date', 'open_index_value', 'high_index_value',
            'low_index_value', 'closing_index_value', 'points_change',
            'percentage_change', 'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield'
        ]
        
        missing = set(required_columns) - set(columns)
        if missing:
            print(f"Missing columns in database: {missing}")
            return False
        return True
    except Error as e:
        print(f"Schema verification failed: {e}")
        return False
    finally:
        cursor.close()

# ========================= Insert Data into MySQL ========================= #
def insert_data_to_db(df, connection):
    try:
        cursor = connection.cursor()
        insert_query = """
        INSERT INTO cm_index_data (index_name, index_date, open_index_value, high_index_value, 
                                 low_index_value, closing_index_value, points_change, 
                                 percentage_change, volume, turnover_in_crores, p_e, p_b, div_yield)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        # Convert DataFrame to list of tuples with proper NULL handling
        data = []
        for row in df.itertuples(index=False):
            processed_row = []
            for value in row:
                if pd.isna(value) or str(value).lower() == 'nan':
                    processed_row.append(None)
                else:
                    processed_row.append(value)
            data.append(tuple(processed_row))

        # Execute batch insert
        cursor.executemany(insert_query, data)
        connection.commit()
        print(f"{cursor.rowcount} rows inserted into MySQL database.")
    except Error as e:
        print(f"MySQL Insert Error: {e}")
        if 'data' in locals() and data:
            print("Sample problematic row:", data[0])
    finally:
        if cursor:
            cursor.close()

# ========================= NSE Session with Cookie Handling ========================= #
def create_nse_session():
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": "https://www.nseindia.com",
        "Connection": "keep-alive",
    })
    
    # First request to set cookies
    try:
        session.get("https://www.nseindia.com", timeout=10)
        time.sleep(1)
        session.get("https://www.nseindia.com/market-data/live-market-indices", timeout=10)
        return session
    except Exception as e:
        print(f"Failed to initialize NSE session: {e}")
        return None

# ========================= Download NSE Index Data with Retry ========================= #
def download_nse_csv(max_retries=3):
    yesterday_str, _ = get_yesterday()
    api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={yesterday_str}&type=indices&mode=single"

    for attempt in range(1, max_retries + 1):
        session = create_nse_session()
        if not session:
            continue
            
        try:
            print(f"Attempt {attempt}/{max_retries} to download data")
            response = session.get(api_url, timeout=15)
            
            if response.status_code == 200:
                file_name = f"ind_close_all-{yesterday_str}.csv"
                save_path = os.path.join(os.getcwd(), file_name)
                
                with open(save_path, "wb") as file:
                    file.write(response.content)
                
                print(f"cm_index_data Report downloaded successfully: {save_path}")
                return save_path
            else:
                print(f"API Error {response.status_code}: {response.text[:200]}")
                
        except Exception as e:
            print(f"Download attempt {attempt} failed: {e}")
        finally:
            session.close()
            
        if attempt < max_retries:
            wait_time = random.uniform(2, 5)
            print(f"Waiting {wait_time:.1f} seconds before retry...")
            time.sleep(wait_time)
    
    print("Failed to download data after maximum retries")
    return None

# ========================= Process & Insert CSV into MySQL ========================= #
def insert_csv_to_db(csv_file_path):
    try:
        # Read and clean CSV
        df = pd.read_csv(csv_file_path)
        df.columns = df.columns.str.strip()
        
        # Column renaming
        column_map = {
            'Index Name': 'index_name',
            'Index Date': 'index_date',
            'Open Index Value': 'open_index_value',
            'High Index Value': 'high_index_value',
            'Low Index Value': 'low_index_value',
            'Closing Index Value': 'closing_index_value',
            'Points Change': 'points_change',
            'Change(%)': 'percentage_change',
            'Volume': 'volume',
            'Turnover (Rs. Cr.)': 'turnover_in_crores',
            'P/E': 'p_e',
            'P/B': 'p_b',
            'Div Yield': 'div_yield'
        }
        df.rename(columns=column_map, inplace=True)
        
        # Date conversion
        df['index_date'] = pd.to_datetime(df['index_date'], format='%d-%m-%Y').dt.strftime('%Y-%m-%d')
        
        # Data cleaning
        df = clean_dataframe(df)
        
        # Connect to DB
        connection = create_connection()
        if not connection:
            return
            
        # Verify schema and insert
        if verify_db_schema(connection):
            insert_data_to_db(df, connection)
        
        # Clean up
        connection.close()
        os.remove(csv_file_path)
        print(f"CSV file deleted: {csv_file_path}")

    except Exception as e:
        print(f"Error processing CSV file: {e}")
        if 'connection' in locals() and connection.is_connected():
            connection.close()

 
# ========================= Add Historical Data for Yesterday ========================= #
def _already_loaded(table, date_col, data_date):
    """True if the table already has rows for data_date. The inserts append
    without dedup, so we must skip dates already present to avoid duplicates."""
    ds = data_date.strftime('%Y-%m-%d')
    with next(get_db()) as s:
        n = s.execute(
            text(f"SELECT COUNT(*) FROM {table} WHERE `{date_col}` = :d"),
            {"d": ds}).scalar()
    return (n or 0) > 0


def add_historical_data_of_a_date(data_date: datetime):
    x = NSE()
    if _already_loaded('cm_udiff_bhavdata', 'trade_date', data_date):
        print(f"CM bhavcopy already loaded for {data_date:%Y-%m-%d}; skipping")
    else:
        try:
            data = x.equity_cm_bhavcopy_final(data_date)
            print("Equity CM Bhavcopy:", data)
            x.add_equity_udiff_bhavcopy_to_db(data, verify_in_db=False)
        except RuntimeError as e:
            print(e)
    if _already_loaded('fo_udiff_bhavdata', 'trade_date', data_date):
        print(f"FO bhavcopy already loaded for {data_date:%Y-%m-%d}; skipping")
    else:
        try:
            data = x.equity_fo_bhavcopy_final(data_date)
            print("Equity FO Bhavcopy:", data)
            x.add_fo_udiff_bhavcopy_to_db(data, verify_in_db=False)
        except RuntimeError as e:
            print(e)
    if _already_loaded('securities_bhavdata', 'date', data_date):
        print(f"Securities already loaded for {data_date:%Y-%m-%d}; skipping")
    else:
        try:
            data = x.securities_bhavdata(data_date)
            print("Securities Bhavdata:", data)
            x.add_securities_bhavdata_to_db(data, verify_in_db=False)
        except RuntimeError as e:
            print(e)
 
# ========================= Main Execution ========================= #
def main():
    _, yesterday_sql = get_yesterday()
    yday = datetime.strptime(yesterday_sql, '%Y-%m-%d')

    # Step 1: NSE Index Data for Yesterday (skip if already loaded -> no dupes)
    if _already_loaded('cm_index_data', 'index_date', yday):
        print(f"cm_index_data already loaded for {yesterday_sql}; skipping")
    else:
        downloaded_csv = download_nse_csv()
        if downloaded_csv:
            insert_csv_to_db(downloaded_csv)

    # Step 2: Process Historical Data for Yesterday (idempotent per table)
    add_historical_data_of_a_date(yday)

    # Step 3: Update last_updated_date. The table has a single `last_updated_date`
    # column (the old code wrote to a non-existent `trade_date` column, so this
    # never actually updated). Replace the single row with the latest trade date.
    with next(get_db()) as db_session:
        latest_trade_date = db_session.execute(
            text('SELECT MAX(trade_date) FROM fo_udiff_bhavdata')).scalar()
        if latest_trade_date is not None:
            db_session.execute(text('DELETE FROM last_updated_date'))
            db_session.execute(
                text('INSERT INTO last_updated_date (last_updated_date) VALUES (:d)'),
                {"d": latest_trade_date})
            db_session.commit()
            print(f"Last Trade Date Updated: {latest_trade_date}")
 
# ========================= Run Script ========================= #
if __name__ == "__main__":
    main()


# import os
# import time
# import random
# import requests
# import pandas as pd
# import mysql.connector
# from datetime import datetime, timedelta
# from sqlalchemy import text
# from db import get_db
# from main_old import NSE
# from models.last_updated_date import LastUpdatedDate
# from mysql.connector import Error

# # ========================= Get Today's Business Day ========================= #
# def get_today():
#     today = datetime.today()
#     while today.weekday() in [5, 6]:  # Skip Saturday (5) and Sunday (6)
#         today -= timedelta(days=1)
#     return today.strftime('%d-%b-%Y'), today.strftime('%Y-%m-%d')

# # ========================= MySQL Connection ========================= #
# def create_connection():
#     try:
#         connection = mysql.connector.connect(
#             host='localhost',
#             database='updated_testdb',
#             user='root',
#             password='root',
#             connect_timeout=30
#         )
#         if connection.is_connected():
#             print("Connected to MySQL database")
#         return connection
#     except Error as e:
#         print(f"MySQL Connection Error: {e}")
#         return None

# # ========================= Clean DataFrame ========================= #
# def clean_dataframe(df):
#     # Replace string 'nan' with actual NaN
#     df = df.replace('nan', pd.NA)
    
#     # Convert numeric columns
#     numeric_cols = ['open_index_value', 'high_index_value', 'low_index_value',
#                    'closing_index_value', 'points_change', 'percentage_change',
#                    'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield']
    
#     for col in numeric_cols:
#         if col in df.columns:
#             df[col] = pd.to_numeric(df[col], errors='coerce')
    
#     return df

# # ========================= Verify Database Schema ========================= #
# def verify_db_schema(connection):
#     try:
#         cursor = connection.cursor()
#         cursor.execute("DESCRIBE cm_index_data")
#         columns = [col[0] for col in cursor.fetchall()]
#         required_columns = [
#             'index_name', 'index_date', 'open_index_value', 'high_index_value',
#             'low_index_value', 'closing_index_value', 'points_change',
#             'percentage_change', 'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield'
#         ]
        
#         missing = set(required_columns) - set(columns)
#         if missing:
#             print(f"Missing columns in database: {missing}")
#             return False
#         return True
#     except Error as e:
#         print(f"Schema verification failed: {e}")
#         return False
#     finally:
#         cursor.close()

# # ========================= Insert Data into MySQL ========================= #
# def insert_data_to_db(df, connection):
#     try:
#         cursor = connection.cursor()
#         insert_query = """
#         INSERT INTO cm_index_data (index_name, index_date, open_index_value, high_index_value, 
#                                  low_index_value, closing_index_value, points_change, 
#                                  percentage_change, volume, turnover_in_crores, p_e, p_b, div_yield)
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
#         """
        
#         # Convert DataFrame to list of tuples with proper NULL handling
#         data = []
#         for row in df.itertuples(index=False):
#             processed_row = []
#             for value in row:
#                 if pd.isna(value) or str(value).lower() == 'nan':
#                     processed_row.append(None)
#                 else:
#                     processed_row.append(value)
#             data.append(tuple(processed_row))

#         # Execute batch insert
#         cursor.executemany(insert_query, data)
#         connection.commit()
#         print(f"{cursor.rowcount} rows inserted into MySQL database.")
#     except Error as e:
#         print(f"MySQL Insert Error: {e}")
#         if 'data' in locals() and data:
#             print("Sample problematic row:", data[0])
#     finally:
#         if cursor:
#             cursor.close()

# # ========================= NSE Session with Cookie Handling ========================= #
# def create_nse_session():
#     session = requests.Session()
#     session.headers.update({
#         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
#         "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
#         "Accept-Language": "en-US,en;q=0.5",
#         "Referer": "https://www.nseindia.com",
#         "Connection": "keep-alive",
#     })
    
#     # First request to set cookies
#     try:
#         session.get("https://www.nseindia.com", timeout=10)
#         time.sleep(1)
#         session.get("https://www.nseindia.com/market-data/live-market-indices", timeout=10)
#         return session
#     except Exception as e:
#         print(f"Failed to initialize NSE session: {e}")
#         return None

# # ========================= Download NSE Index Data with Retry ========================= #
# def download_nse_csv(max_retries=3):
#     today_str, _ = get_today()
#     api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={today_str}&type=indices&mode=single"

#     for attempt in range(1, max_retries + 1):
#         session = create_nse_session()
#         if not session:
#             continue
            
#         try:
#             print(f"Attempt {attempt}/{max_retries} to download data")
#             response = session.get(api_url, timeout=15)
            
#             if response.status_code == 200:
#                 file_name = f"ind_close_all-{today_str}.csv"
#                 save_path = os.path.join(os.getcwd(), file_name)
                
#                 with open(save_path, "wb") as file:
#                     file.write(response.content)
                
#                 print(f"cm_index_data Report downloaded successfully: {save_path}")
#                 return save_path
#             else:
#                 print(f"API Error {response.status_code}: {response.text[:200]}")
                
#         except Exception as e:
#             print(f"Download attempt {attempt} failed: {e}")
#         finally:
#             session.close()
            
#         if attempt < max_retries:
#             wait_time = random.uniform(2, 5)
#             print(f"Waiting {wait_time:.1f} seconds before retry...")
#             time.sleep(wait_time)
    
#     print("Failed to download data after maximum retries")
#     return None

# # ========================= Process & Insert CSV into MySQL ========================= #
# def insert_csv_to_db(csv_file_path):
#     try:
#         # Read and clean CSV
#         df = pd.read_csv(csv_file_path)
#         df.columns = df.columns.str.strip()
        
#         # Column renaming
#         column_map = {
#             'Index Name': 'index_name',
#             'Index Date': 'index_date',
#             'Open Index Value': 'open_index_value',
#             'High Index Value': 'high_index_value',
#             'Low Index Value': 'low_index_value',
#             'Closing Index Value': 'closing_index_value',
#             'Points Change': 'points_change',
#             'Change(%)': 'percentage_change',
#             'Volume': 'volume',
#             'Turnover (Rs. Cr.)': 'turnover_in_crores',
#             'P/E': 'p_e',
#             'P/B': 'p_b',
#             'Div Yield': 'div_yield'
#         }
#         df.rename(columns=column_map, inplace=True)
        
#         # Date conversion
#         df['index_date'] = pd.to_datetime(df['index_date'], format='%d-%m-%Y').dt.strftime('%Y-%m-%d')
        
#         # Data cleaning
#         df = clean_dataframe(df)
        
#         # Connect to DB
#         connection = create_connection()
#         if not connection:
#             return
            
#         # Verify schema and insert
#         if verify_db_schema(connection):
#             insert_data_to_db(df, connection)
        
#         # Clean up
#         connection.close()
#         os.remove(csv_file_path)
#         print(f"CSV file deleted: {csv_file_path}")

#     except Exception as e:
#         print(f"Error processing CSV file: {e}")
#         if 'connection' in locals() and connection.is_connected():
#             connection.close()

# # ========================= Add Historical Data for Today ========================= #
# def add_historical_data_of_a_date(data_date: datetime):
#     x = NSE()
#     try:
#         data = x.equity_cm_bhavcopy_final(data_date)
#         print("Equity CM Bhavcopy:", data)
#         x.add_equity_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.equity_fo_bhavcopy_final(data_date)
#         print("Equity FO Bhavcopy:", data)
#         x.add_fo_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.securities_bhavdata(data_date)
#         print("Securities Bhavdata:", data)
#         x.add_securities_bhavdata_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)

# # ========================= Main Execution ========================= #
# def main():
#     # Step 1: Download and Insert NSE Index Data for Today
#     downloaded_csv = download_nse_csv()
#     if downloaded_csv:
#         insert_csv_to_db(downloaded_csv)
    
#     # Step 2: Process Historical Data for Today (Business Days Only)
#     _, today_sql = get_today()
#     add_historical_data_of_a_date(datetime.strptime(today_sql, '%Y-%m-%d'))
    
#     # Step 3: Update Last Trade Date in Database
#     with next(get_db()) as db_session:
#         latest_trade_date = db_session.execute(text('SELECT MAX(trade_date) FROM fo_udiff_bhavdata')).scalar()
#         last_updated = db_session.query(LastUpdatedDate).first()
#         if last_updated:
#             last_updated.trade_date = latest_trade_date
#             db_session.commit()
#             print(f"Last Trade Date Updated: {latest_trade_date}")

# # ========================= Run Script ========================= #
# if __name__ == "__main__":
#     main()


# import random
# from pathlib import Path

# import pandas as pd
# from datetime import datetime

# from sqlalchemy import text
# from db import get_db
# from main_old import NSE
# import time

# from models.last_updated_date import LastUpdatedDate


# def add_hystorical_data_of_a_date(data_date: datetime):
#     x = NSE()
#     try:
#         data = x.equity_cm_bhavcopy_final(data_date)
#         print("equity_cm_bhavcopy_final:", data)
#         x.add_equity_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.equity_fo_bhavcopy_final(data_date)
#         print("equity_cm_bhavcopy_final:", data)
#         x.add_fo_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.securities_bhavdata(data_date)
#         print("securities_bhavdata:", data)
#         x.add_securities_bhavdata_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.equity_block(data_date)
#         print("equity_block:", data)
#         x.add_equity_block_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)
#     try:
#         data = x.equity_bulk(data_date)
#         print("equity_bulk:", data)
#         x.add_equity_bulk_to_db(data, verify_in_db=False)
#     except RuntimeError as e:
#         print(e)


# if __name__ == "__main__":
#     dates = pd.date_range(start="2022-12-09",
#                           end=datetime.now().strftime('%Y-%m-%d'), freq='B')
#     count = 0
#     for date in dates:
#         add_hystorical_data_of_a_date(date)
#         if count % 4 == 0:
#             time.sleep(random.randint(0, 1))
#         count += 1

#     with next(get_db()) as db_session:
#         latest_trade_date = db_session.execute(
#             text('select max(trade_date) from fo_udiff_bhavdata')).scalar()
#         last_updated = db_session.query(LastUpdatedDate).first()
#         if last_updated:
#             last_updated.last_updated_date = latest_trade_date
#             db_session.add(last_updated)
#         else:
#             db_session.add(LastUpdatedDate(
#                 last_updated_date=latest_trade_date))
#         db_session.commit()