# # import requests
# # import os
# # from datetime import datetime, timedelta

# # # Get yesterday's date in NSE format (e.g., "11-Feb-2025")
# # yesterday_date = (datetime.today() - timedelta(days=1)).strftime('%d-%b-%Y')

# # # NSE API URL for cm_index data (CSV file URL)
# # api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={yesterday_date}&type=indices&mode=single"

# # # Headers to simulate a real browser
# # headers = {
# #     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
# #     "Referer": "https://www.nseindia.com",
# #     "Accept-Language": "en-US,en;q=0.9",
# #     "Connection": "keep-alive",
# # }

# # # Step 1: Create a session and fetch NSE homepage to set cookies
# # session = requests.Session()
# # session.headers.update(headers)

# # homepage_url = "https://www.nseindia.com"
# # session.get(homepage_url)  # This sets necessary cookies

# # # Step 2: Now, request the API data (which returns CSV)
# # response = session.get(api_url)

# # # Debugging: Check response status and content
# # if response.status_code != 200:
# #     print(f"Failed to fetch API data. Status Code: {response.status_code}")
# #     print("Response Text:", response.text[:500])  # Print first 500 chars of response
# #     exit()

# # # Step 3: Save the CSV file directly
# # file_name = f"cm_index_{yesterday_date}.csv"
# # save_path = os.path.join(os.getcwd(), file_name)

# # # Write CSV content to file
# # with open(save_path, "wb") as file:
# #     file.write(response.content)

# # print(f"cm_index Report downloaded successfully: {save_path}")


# import requests
# import os
# import time
# from datetime import datetime, timedelta

# def get_yesterday_date():
#     """Get yesterday's date, skipping weekends"""
#     date = datetime.today() - timedelta(days=1)
#     while date.weekday() >= 5:  # 5=Saturday, 6=Sunday
#         date -= timedelta(days=1)
#     return date.strftime('%d-%b-%Y')

# def create_nse_session():
#     """Create a session with proper cookies"""
#     session = requests.Session()
#     session.headers.update({
#         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
#         "Accept-Language": "en-US,en;q=0.9",
#         "Referer": "https://www.nseindia.com"
#     })
    
#     # First get request to set cookies
#     for _ in range(3):  # Retry up to 3 times
#         try:
#             session.get("https://www.nseindia.com", timeout=10)
#             session.get("https://www.nseindia.com/market-data/live-market-indices", timeout=10)
#             return session
#         except Exception as e:
#             print(f"Cookie setup failed, retrying... Error: {str(e)}")
#             time.sleep(2)
#     return None

# def download_cm_index_data():
#     yesterday_date = get_yesterday_date()
#     api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={yesterday_date}&type=indices&mode=single"

#     session = create_nse_session()
#     if not session:
#         print("Failed to establish NSE session")
#         return False

#     try:
#         response = session.get(api_url, timeout=15)
#         if response.status_code == 200:
#             file_name = f"cm_index_{yesterday_date}.csv"
#             with open(file_name, "wb") as f:
#                 f.write(response.content)
#             print(f"Successfully downloaded: {file_name}")
#             return True
#         else:
#             print(f"API Error {response.status_code}: {response.text[:200]}")
#             return False
#     except Exception as e:
#         print(f"Download failed: {str(e)}")
#         return False
#     finally:
#         session.close()

# if __name__ == "__main__":
#     # Try up to 3 times with delays
#     for attempt in range(1, 4):
#         print(f"\nAttempt {attempt}/3")
#         if download_cm_index_data():
#             break
#         time.sleep(5)  # Wait before retry


# import os
# import time
# import random
# import requests
# import pandas as pd
# import mysql.connector
# from datetime import datetime, timedelta
# from sqlalchemy import text
# from db import get_db
# from main_old import NSE
# from models.last_updated_date import LastUpdatedDate
# from mysql.connector import Error

# # ========================= Get Yesterday's Business Day ========================= #
# def get_yesterday():
#     yesterday = datetime.today() - timedelta(days=1)
#     while yesterday.weekday() in [5, 6]:  # Skip Saturday (5) and Sunday (6)
#         yesterday -= timedelta(days=1)
#     return yesterday.strftime('%d-%b-%Y'), yesterday.strftime('%Y-%m-%d')

# # ========================= MySQL Connection ========================= #
# def create_connection():
#     try:
#         connection = mysql.connector.connect(
#             host='localhost',
#             database='updated_testdb',
#             user='root',
#             password='root',
#             connect_timeout=30
#         )
#         if connection.is_connected():
#             print("Connected to MySQL database")
#         return connection
#     except Error as e:
#         print(f"MySQL Connection Error: {e}")
#         return None

# # ========================= Clean DataFrame ========================= #
# def clean_dataframe(df):
#     # Replace string 'nan' with actual NaN
#     df = df.replace('nan', pd.NA)
    
#     # Convert numeric columns
#     numeric_cols = ['open_index_value', 'high_index_value', 'low_index_value',
#                    'closing_index_value', 'points_change', 'percentage_change',
#                    'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield']
    
#     for col in numeric_cols:
#         if col in df.columns:
#             df[col] = pd.to_numeric(df[col], errors='coerce')
    
#     return df

# # ========================= Verify Database Schema ========================= #
# def verify_db_schema(connection):
#     try:
#         cursor = connection.cursor()
#         cursor.execute("DESCRIBE cm_index_data")
#         columns = [col[0] for col in cursor.fetchall()]
#         required_columns = [
#             'index_name', 'index_date', 'open_index_value', 'high_index_value',
#             'low_index_value', 'closing_index_value', 'points_change',
#             'percentage_change', 'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield'
#         ]
        
#         missing = set(required_columns) - set(columns)
#         if missing:
#             print(f"Missing columns in database: {missing}")
#             return False
#         return True
#     except Error as e:
#         print(f"Schema verification failed: {e}")
#         return False
#     finally:
#         cursor.close()

# # ========================= Insert Data into MySQL ========================= #
# def insert_data_to_db(df, connection):
#     try:
#         cursor = connection.cursor()
#         insert_query = """
#         INSERT INTO cm_index_data (index_name, index_date, open_index_value, high_index_value, 
#                                  low_index_value, closing_index_value, points_change, 
#                                  percentage_change, volume, turnover_in_crores, p_e, p_b, div_yield)
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
#         """
        
#         # Convert DataFrame to list of tuples with proper NULL handling
#         data = []
#         for row in df.itertuples(index=False):
#             processed_row = []
#             for value in row:
#                 if pd.isna(value) or str(value).lower() == 'nan':
#                     processed_row.append(None)
#                 else:
#                     processed_row.append(value)
#             data.append(tuple(processed_row))

#         # Execute batch insert
#         cursor.executemany(insert_query, data)
#         connection.commit()
#         print(f"{cursor.rowcount} rows inserted into MySQL database.")
#     except Error as e:
#         print(f"MySQL Insert Error: {e}")
#         if 'data' in locals() and data:
#             print("Sample problematic row:", data[0])
#     finally:
#         if cursor:
#             cursor.close()

# # ========================= NSE Session with Cookie Handling ========================= #
# def create_nse_session():
#     session = requests.Session()
#     session.headers.update({
#         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
#         "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
#         "Accept-Language": "en-US,en;q=0.5",
#         "Referer": "https://www.nseindia.com",
#         "Connection": "keep-alive",
#     })
    
#     # First request to set cookies
#     try:
#         session.get("https://www.nseindia.com", timeout=10)
#         time.sleep(1)
#         session.get("https://www.nseindia.com/market-data/live-market-indices", timeout=10)
#         return session
#     except Exception as e:
#         print(f"Failed to initialize NSE session: {e}")
#         return None

# # ========================= Download NSE Index Data with Retry ========================= #
# def download_nse_csv(max_retries=3):
#     yesterday_str, _ = get_yesterday()
#     api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={yesterday_str}&type=indices&mode=single"

#     for attempt in range(1, max_retries + 1):
#         session = create_nse_session()
#         if not session:
#             continue
            
#         try:
#             # print(f"Attempt {attempt}/{max_retries} to download data")
#             response = session.get(api_url, timeout=15)
            
#             if response.status_code == 200:
#                 file_name = f"ind_close_all-{yesterday_str}.csv"
#                 save_path = os.path.join(os.getcwd(), file_name)
                
#                 with open(save_path, "wb") as file:
#                     file.write(response.content)
                
#                 print(f"cm_index_data Report downloaded successfully: {save_path}")
#                 return save_path
#             else:
#                 print(f"API Error {response.status_code}: {response.text[:200]}")
                
#         except Exception as e:
#             print(f"Download attempt {attempt} failed: {e}")
#         finally:
#             session.close()
            
#         if attempt < max_retries:
#             wait_time = random.uniform(2, 5)
#             print(f"Waiting {wait_time:.1f} seconds before retry...")
#             time.sleep(wait_time)
    
#     print("Failed to download data after maximum retries")
#     return None

# # ========================= Process & Insert CSV into MySQL ========================= #
# def insert_csv_to_db(csv_file_path):
#     try:
#         # Read and clean CSV
#         df = pd.read_csv(csv_file_path)
#         df.columns = df.columns.str.strip()
        
#         # Column renaming
#         column_map = {
#             'Index Name': 'index_name',
#             'Index Date': 'index_date',
#             'Open Index Value': 'open_index_value',
#             'High Index Value': 'high_index_value',
#             'Low Index Value': 'low_index_value',
#             'Closing Index Value': 'closing_index_value',
#             'Points Change': 'points_change',
#             'Change(%)': 'percentage_change',
#             'Volume': 'volume',
#             'Turnover (Rs. Cr.)': 'turnover_in_crores',
#             'P/E': 'p_e',
#             'P/B': 'p_b',
#             'Div Yield': 'div_yield'
#         }
#         df.rename(columns=column_map, inplace=True)
        
#         # Date conversion
#         df['index_date'] = pd.to_datetime(df['index_date'], format='%d-%m-%Y').dt.strftime('%Y-%m-%d')
        
#         # Data cleaning
#         df = clean_dataframe(df)
        
#         # Connect to DB
#         connection = create_connection()
#         if not connection:
#             return
            
#         # Verify schema and insert
#         if verify_db_schema(connection):
#             insert_data_to_db(df, connection)
        
#         # Clean up
#         connection.close()
#         os.remove(csv_file_path)
#         print(f"CSV file deleted: {csv_file_path}")

#     except Exception as e:
#         print(f"Error processing CSV file: {e}")
#         if 'connection' in locals() and connection.is_connected():
#             connection.close()

# # ========================= Add Historical Data with Retry ========================= #
# def add_historical_data_of_a_date(data_date: datetime, max_retries=3):
#     for attempt in range(1, max_retries + 1):
#         try:
#             # print(f"\nAttempt {attempt}/{max_retries} for historical data")
#             x = NSE()
            
#             # Process CM data
#             cm_data = x.equity_cm_bhavcopy_final(data_date)
#             x.add_equity_udiff_bhavcopy_to_db(cm_data, verify_in_db=False)
#             print("Processed Equity CM data")
            
#             # Process FO data
#             fo_data = x.equity_fo_bhavcopy_final(data_date)
#             x.add_fo_udiff_bhavcopy_to_db(fo_data, verify_in_db=False)
#             print("Processed Equity FO data")
            
#             # Process Securities data
#             sec_data = x.securities_bhavdata(data_date)
#             x.add_securities_bhavdata_to_db(sec_data, verify_in_db=False)
#             print("Processed Securities data")
            
#             return  # Success - exit retry loop
            
#         except RuntimeError as e:
#             print(f"Attempt {attempt} failed: {e}")
#             if attempt < max_retries:
#                 wait_time = random.uniform(5, 10)
#                 print(f"Waiting {wait_time:.1f} seconds before retry...")
#                 time.sleep(wait_time)
#             else:
#                 print("Max retries reached for historical data")

# # ========================= Main Execution ========================= #
# def main():
#     print(f"Starting NSE Data Processing - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

#     # Step 1: Download and Insert NSE Index Data for Yesterday
#     downloaded_csv = download_nse_csv()
#     if downloaded_csv:
#         insert_csv_to_db(downloaded_csv)

#     # Step 2: Process Historical Data for Yesterday (Business Days Only)
#     _, yesterday_sql = get_yesterday()
#     add_historical_data_of_a_date(datetime.strptime(yesterday_sql, '%Y-%m-%d'))

#     # Step 3: Update Last Trade Date in Database
#     with next(get_db()) as db_session:
#         latest_trade_date = db_session.execute(
#             text('SELECT MAX(trade_date) FROM fo_udiff_bhavdata')
#         ).scalar()
        
#         if latest_trade_date:
#             last_updated = db_session.query(LastUpdatedDate).first()
#             if last_updated:
#                 last_updated.trade_date = latest_trade_date
#                 db_session.commit()
#                 print(f"Updated last trade date: {latest_trade_date}")
#             else:
#                 print("No LastUpdatedDate record found")
#         else:
#             print("No trade dates found in fo_udiff_bhavdata")

#     print(f"Processing completed - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

# if __name__ == "__main__":
#     try:
#         main()
#     except KeyboardInterrupt:
#         print("\n Script interrupted by user")
#     except Exception as e:
#         print(f"\n Unhandled exception: {e}")





















import pandas as pd
import mysql.connector
from mysql.connector import Error

def create_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',  
            database='updated_testdb',  
            user='root',  
            password='root' 
        )
        if connection.is_connected():
            print("Connected to the database")
        return connection
    except Error as e:
        print(f"Error: {e}")
        return None

def insert_data_to_db(df, connection):
    try:
        cursor = connection.cursor()

        insert_query = """
        INSERT INTO cm_index_data (index_name, index_date, open_index_value, high_index_value, low_index_value, closing_index_value, points_change, percentage_change, volume, turnover_in_crores, p_e, p_b, div_yield)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        for row in df.itertuples(index=False):
            row = [None if pd.isna(value) else value for value in row]
            cursor.execute(insert_query, row)

        connection.commit()
        print(f"{cursor.rowcount} rows inserted.")
    except Error as e:
        print(f"Error while inserting data into MySQL: {e}")
    finally:
        cursor.close()

def insert_csv_to_db(csv_file_path):
    try:
        df = pd.read_csv(csv_file_path)

        df.columns = df.columns.str.strip()

        df.rename(columns={
            'Index Name': 'index_name',
            'Index Date': 'index_date',
            'Open Index Value': 'open_index_value',
            'High Index Value': 'high_index_value',
            'Low Index Value': 'low_index_value',
            'Closing Index Value': 'closing_index_value',
            'Points Change': 'points_change',
            'Change(%)': 'percentage_change',
            'Volume': 'volume',
            'Turnover (Rs. Cr.)': 'turnover_in_crores',
            'P/E': 'p_e',
            'P/B': 'p_b',
            'Div Yield': 'div_yield'
        }, inplace=True)

        if 'index_date' not in df.columns:
            raise KeyError("The 'index_date' column is missing from the CSV.")

        print("Before conversion:")
        print(df.head())

        df['index_date'] = pd.to_datetime(df['index_date'], format='%d-%m-%Y').dt.strftime('%Y-%m-%d')

        numeric_columns = ['open_index_value', 'high_index_value', 'low_index_value', 'closing_index_value', 'points_change', 'percentage_change', 'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield']
        for col in numeric_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')  

        df = df.where(pd.notnull(df), None)

        print("After conversion:")
        print(df.head())

        connection = create_connection()

        if connection:
            insert_data_to_db(df, connection)

            connection.close()

    except KeyError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

csv_file_path = r'C:\quantlab_numbers\trading.tar 1\trading\nse-scraper\temp\ind_close_all_07042025.csv'  # Replace with the path to your CSV file

insert_csv_to_db(csv_file_path)
