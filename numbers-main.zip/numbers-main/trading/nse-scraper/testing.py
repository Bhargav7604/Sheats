
import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime
import os

# Database connection - replace with your actual credentials
DATABASE_URL = "mysql+pymysql://root:root@localhost/updated_testdb"
engine = create_engine(DATABASE_URL)

# CSV file path - update this to your actual file path
CSV_FILE = os.path.join("C:\\quantlab_numbers_cloud\\BhavCopy_NSE_FO_0_0_0_20250703_F_0000.csv")

# Column mapping from CSV to Database
COLUMN_MAPPING = {
    'TradDt': 'trade_date',
    'BizDt': 'biz_date',
    'Sgmt': 'sgmt',
    'Src': 'src',
    'FinInstrmTp': 'fin_instrm_tp',
    'FinInstrmId': 'fin_instrm_id',
    'ISIN': 'isin',
    'TckrSymb': 'tckr_symb',
    'SctySrs': 'scty_srs',
    'XpryDt': 'xpry_date',
    'FininstrmActlXpryDt': 'fininstrm_actl_xpry_date',
    'StrkPric': 'strk_price',
    'OptnTp': 'optn_tp',
    'FinInstrmNm': 'fin_instrm_nm',
    'OpnPric': 'open_price',
    'HghPric': 'high_price',
    'LwPric': 'low_price',
    'ClsPric': 'close_price',
    'LastPric': 'last_price',
    'PrvsClsgPric': 'prev_closing_price',
    'UndrlygPric': 'undrlyg_price',
    'SttlmPric': 'sttlm_price',
    'OpnIntrst': 'opn_intrst',
    'ChngInOpnIntrst': 'chng_in_opn_intrst',
    'TtlTradgVol': 'total_trade_volume',
    'TtlTrfVal': 'ttl_trf_val',
    'TtlNbOfTxsExctd': 'ttl_nb_of_txs_exctd',
    'SsnId': 'ssn_id',
    'NewBrdLotQty': 'new_brd_lot_qty',
    'Rmks': 'rmks',
    'Rsvd1': 'rsvd_01',
    'Rsvd2': 'rsvd_02',
    'Rsvd3': 'rsvd_03',
    'Rsvd4': 'rsvd_04'
}

def import_csv_to_db():
    try:
        print(f"Attempting to read CSV file: {CSV_FILE}")
        
        # Verify file exists
        if not os.path.exists(CSV_FILE):
            raise FileNotFoundError(f"CSV file not found at: {CSV_FILE}")
        
        # Read CSV file
        df = pd.read_csv(
            CSV_FILE,
            parse_dates=['TradDt', 'BizDt', 'XpryDt', 'FininstrmActlXpryDt'],
            dayfirst=True  # Important for dates in DD/MM/YYYY format
        )
        
        print(f"Successfully read CSV file with {len(df)} rows")
        
        # Rename columns to match database
        df.rename(columns=COLUMN_MAPPING, inplace=True)
        
        # Add start_date column (modify this logic as needed)
        df['start_date'] = df['trade_date']
        
        # Convert date columns to date objects (not datetimes)
        date_columns = ['trade_date', 'biz_date', 'xpry_date', 'fininstrm_actl_xpry_date', 'start_date']
        for col in date_columns:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors='coerce').dt.date
        
        # Handle numeric columns
        numeric_cols = ['strk_price', 'open_price', 'high_price', 'low_price', 
                       'close_price', 'last_price', 'prev_closing_price',
                       'undrlyg_price', 'sttlm_price', 'opn_intrst',
                       'chng_in_opn_intrst', 'ttl_trf_val']
        
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Insert data with transaction management
        print("Starting database import...")
        with engine.begin() as connection:
            df.to_sql(
                name='fo_udiff_bhavdata',
                con=connection,
                if_exists='append',
                index=False,
                chunksize=500,  # Reduced chunk size for better reliability
                method='multi'
            )
        
        print(f"Successfully imported {len(df)} records to database")
        
    except Exception as e:
        print(f"Error occurred during import: {str(e)}")
        # Additional error details for debugging
        if hasattr(e, 'sql'):
            print(f"SQL: {e.sql}")
        if hasattr(e, 'params'):
            print(f"Params: {e.params}")
        raise

if __name__ == "__main__":
    import_csv_to_db()