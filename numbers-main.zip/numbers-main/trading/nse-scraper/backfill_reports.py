"""
Generate `all_data_csv_report` for every trading day that is missing it,
between max(all_data_csv_report.date)+1 (or an explicit start) and today.

Reuses analyze_trade_quantity_with_rs.main(date), which reads the DB and
inserts the report rows. Dates with no securities data are skipped by main()
itself (it returns early), so this is safe to run repeatedly.

Usage:
    python backfill_reports.py                      # pending dates .. today
    python backfill_reports.py 2026-05-27 2026-06-19
"""
import sys
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import text

from db import get_db, engine
import analyze_trade_quantity_with_rs as rep


def _holidays():
    q = """
        SELECT DATE_FORMAT(tradingDate, '%Y-%m-%d') AS trading_date
        FROM `holidays`
        WHERE tradingDate > DATE_SUB(CURDATE(), INTERVAL 3 YEAR);
    """
    return pd.read_sql(text(q), engine, parse_dates=['trading_date'])['trading_date']


def _pending_dates(start=None, end=None):
    if start is None:
        with next(get_db()) as s:
            last = s.execute(text("SELECT MAX(`date`) FROM all_data_csv_report")).scalar()
        start = (last + timedelta(days=1)).strftime('%Y-%m-%d') if last else '2026-01-01'
    if end is None:
        end = datetime.now().strftime('%Y-%m-%d')
    dates = pd.date_range(start=start, end=end, freq='B')
    dates = dates[~dates.isin(_holidays())]

    with next(get_db()) as s:
        have = {r[0].strftime('%Y-%m-%d')
                for r in s.execute(text("SELECT DISTINCT `date` FROM all_data_csv_report")).all()}
    return [d for d in dates if d.strftime('%Y-%m-%d') not in have]


def run(start=None, end=None):
    todo = _pending_dates(start, end)
    print(f"Report dates to generate: {len(todo)}")
    ok, failed = [], []
    for d in todo:
        ds = d.strftime('%Y-%m-%d')
        try:
            rep.main(d)
            print(f"OK   {ds}")
            ok.append(ds)
        except Exception as e:
            print(f"FAIL {ds}: {e}")
            failed.append(ds)
    print("\n========== REPORT BACKFILL SUMMARY ==========")
    print(f"Generated: {len(ok)}")
    print(f"Failed   : {len(failed)}")
    if failed:
        for ds in failed:
            print(f"  {ds}")


if __name__ == "__main__":
    start = sys.argv[1] if len(sys.argv) > 1 else None
    end = sys.argv[2] if len(sys.argv) > 2 else None
    run(start, end)
