import json
from datetime import datetime
import numpy as np
import pandas as pd
from flask import Flask, make_response, request, jsonify
from flask_cors import CORS
from config import settings
from sqlalchemy import func, text
from flask_sqlalchemy import SQLAlchemy
import talib
import mysql.connector
from db import engine, get_db
from models.fo_stock_intstruments_report_1 import FOStockInstrumentsReport1
from models.equity_block import EquityBlock
from models.equity_bulk import EquityBulk
from models.fo_stock_intstruments_report_1 import FOStockInstrumentsReport1
from models.last_updated_date import LastUpdatedDate
from models.securities_bhavdata import SecurityiesBhavData
from models.cm_udiff_bhavdata import CMUDIFFBhavData
from models.fo_udiff_bhavdata import FOUDIFFBhavData
from models.start_date_lookup import StartDateLookup
from models.last_updated_date import LastUpdatedDate
from models.cm_market_data_indexes import CMMarketDataIndexes
from models.fo_combine_oi_delta_equivalent import FOCombineOIDeltaEquivalent
from models.holidays import Holidays
import mysql.connector
from constants import TABLES, mst_table_mapping, INDEX_FOR_ADOPTIVE_EMA_CALCULATION

app = Flask(__name__)

@app.route('/get_report', methods=['GET'])
def get_report_route():
    return get_report2()

DATABASE_URL = "mysql+pymysql://root:root@localhost:3306/updated_testdb"

tracker_symbols_query = """SELECT  distinct tckr_symb
FROM fo_udiff_bhavdata;
"""

tracker_symbols = pd.read_sql(tracker_symbols_query, engine)

def get_holidays_dates():
    holidays_query = """
    SELECT DATE_FORMAT(tradingDate, '%Y-%m-%d') as trading_date FROM holidays WHERE tradingDate > DATE_SUB(CURDATE(),INTERVAL 1 YEAR);
    """
    holidays_data = pd.read_sql(text(holidays_query), engine)
    return holidays_data.trading_date.to_list()

def get_instruments_expiry_dates():
    financial_instrument_end_dates_query = """SELECT
    DATE_FORMAT(end_date, '%Y-%m-%d') as expiry_date
    FROM start_date_lookup
    order by end_date desc limit 6;
    """
    financial_instrument_end_date = pd.read_sql(text(financial_instrument_end_dates_query), engine)
    return financial_instrument_end_date.expiry_date.to_list()

def get_instruments_dates():
    data = request.get_json()
    if "secrete" not in data:
        return make_response(jsonify({"message": "Invalid Request"}), 400)
    if data["secrete"] != settings.SECRET_KEY:
        return make_response(jsonify({"message": "Invalid Request"}), 400)
    financial_instrument_dates_query = """SELECT
    DATE_FORMAT(end_date, '%Y-%m-%d') as expiry_date,
    DATE_FORMAT(start_date, '%Y-%m-%d') as start_date
    FROM start_date_lookup;
    """
    financial_instrument_dates = pd.read_sql(text(financial_instrument_dates_query), engine)

def get_ticker_symbols():
    financial_instrument_names_query = """SELECT distinct
    ticker_symbol
    FROM fo_stock_intstruments_report_1
    order by ticker_symbol;
    """
    financial_instrument_names = pd.read_sql(financial_instrument_names_query, engine)
    return financial_instrument_names.ticker_symbol.to_list()

list_of_holidays = [
    '22-Jan-2024', '26-Jan-2024', '08-Mar-2024',
    '25-Mar-2024', '29-Mar-2024', '11-Apr-2024',
    '14-Apr-2024', '17-Apr-2024', '21-Apr-2024',
    '01-May-2024', '20-May-2024', '17-Jun-2024',
    '17-Jul-2024', '15-Aug-2024', '07-Sep-2024',
    '02-Oct-2024', '12-Oct-2024', '01-Nov-2024',
    '02-Nov-2024', '15-Nov-2024', '25-Dec-2024',
    '26-Jan-2025', '17-Mar-2025', '11-Apr-2025',  
    '14-Apr-2025', '01-May-2025', '15-Aug-2025',  
    '02-Oct-2025', '21-Oct-2025', '31-Oct-2025',  
    '25-Dec-2025'
]

def get_last_updated_date_from_db():
    try:
        # Database configuration
        db_config = {
            'host': 'localhost',
            'user': 'root',
            'password': 'root',
            'database': 'updated_testdb'
        }

        # Connect to the database
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Execute the query to get the last updated date
        cursor.execute("SELECT last_updated_date FROM last_updated_date ORDER BY last_updated_date DESC LIMIT 1;")
        result = cursor.fetchone()

        if result:
            last_updated_date = result[0]
            return last_updated_date
        else:
            print("No last_updated_date found in the database.")
            return None

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

    finally:
        # Close the database connection
        if conn.is_connected():
            cursor.close()
            conn.close()

def get_instruments_data():
    input_data = request.get_json()
    ticker_symbol = input_data.get('ticker_symbol')
    fin_instr_tp = input_data.get('instrument_type')
    instrns_end_date = input_data.get('expiry_date')
    percent_active = input_data.get('percentage_active')
    params = {}
    where_clause = ""
    if ticker_symbol:
        if not isinstance(ticker_symbol, list):
            ticker_symbol = [ticker_symbol]
        place_holders = ", ".join([f":ticker_symbol_{idx}" for idx, _ in enumerate(ticker_symbol)])
        params.update({f"ticker_symbol_{idx}": val for idx, val in enumerate(ticker_symbol)})
        where_clause = f" ticker_symbol IN ({place_holders})"
    if fin_instr_tp:
        if not isinstance(fin_instr_tp, list):
            fin_instr_tp = [fin_instr_tp]
    else:
        fin_instr_tp = ['STO', 'STF']
    place_holders = ", ".join([f":fin_instr_tp_{idx}" for idx, _ in enumerate(fin_instr_tp)])
    params.update({f"fin_instr_tp_{idx}": val for idx, val in enumerate(fin_instr_tp)})
    if where_clause:
        where_clause = " and ".join([where_clause, f" type IN ({place_holders})"])
    else:
        where_clause = f" type IN ({place_holders})"
    if instrns_end_date:
        if not isinstance(instrns_end_date, list):
            instrns_end_date = [instrns_end_date]
        place_holders = ", ".join([f":instrns_end_date_{idx}" for idx, _ in enumerate(instrns_end_date)])
        params.update({f"instrns_end_date_{idx}": val for idx, val in enumerate(instrns_end_date)})
        if where_clause:
            where_clause = " and ".join([where_clause, f" expiry_date IN ({place_holders})"])
        else:
            where_clause = f" expiry_date IN ({place_holders})"
    else:
        with next(get_db()) as db_session:
            end_date = db_session.execute(text("""SELECT
    DATE_FORMAT(end_date, '%Y-%m-%d') as expiry_date
    FROM start_date_lookup
    order by end_date desc limit 5,1;
    """)).scalar()
        place_holders = ", ".join([f":instrns_end_date_{idx}" for idx, _ in enumerate([end_date])])
        params.update({f"instrns_end_date_{idx}": val for idx, val in enumerate([end_date])})
        if where_clause:
            where_clause = " and ".join([where_clause, f" expiry_date >= ({place_holders})"])
        else:
            where_clause = f" expiry_date >= ({place_holders})"
    if percent_active:
        params.update({"percentage_active": percent_active})
        if where_clause:
            where_clause = " and ".join([where_clause, f" percentage_active >= {percent_active}"])
        else:
            where_clause = f" percentage_active >= {percent_active}"
    fo_stock_intstruments_report_1_query = f"""
    select
        name,
        type,
        ticker_symbol,
        DATE_FORMAT(start_date, '%Y-%m-%d') as start_date,
        DATE_FORMAT(expiry_date, '%Y-%m-%d') as expiry_date,
        DATE_FORMAT(current_date, '%Y-%m-%d') as current_date,
        DATE_FORMAT(first_trade_date, '%Y-%m-%d') as first_trade_date,
        days_elapsed_since_birth,
        days_active,
        percentage_active,
        first_trade_underlying_price,
        first_trade_close_price,
        latest_close_price,
        latest_opn_intrst_lot,
        latest_chng_opn_intrst_lot
        from fo_stock_intstruments_report_1 {'where' if where_clause else ''} {where_clause} order by name;
    """
    fo_stock_intstruments_report_1_data = pd.read_sql(text(fo_stock_intstruments_report_1_query), engine, params=params)
    def get_option_type(row):
        if row['type'] == 'STO':
            return row['name'][-2:]
        elif row['type'] == 'STF':
            return row['name'][-3:]
        else:
            return pd.NA
    def get_strike_price(row):
        if row['type'] == 'STO':
            return row['name'].replace(row['ticker_symbol'], '')[5:-2]
        else:
            return pd.NA
    fo_stock_intstruments_report_1_data['option_type'] = fo_stock_intstruments_report_1_data.apply(get_option_type, axis=1)
    fo_stock_intstruments_report_1_data['strike_price'] = fo_stock_intstruments_report_1_data.apply(get_strike_price, axis=1)

def update_db():
    data = request.get_json()
    if "secrete" not in data:
        return make_response(jsonify({"message": "Invalid Request"}), 400)
    if data["secrete"] != settings.SECRET_KEY:
        return make_response(jsonify({"message": "Invalid Request"}), 400)
    if data['table_name'] not in mst_table_mapping:
        return make_response(jsonify({"message": "Invalid Request"}), 400)
    table_name = data['table_name']
    new_data = data['new_data']
    if table_name == 'last_updated_date':
        with next(get_db()) as db_session:
            latest_trade_date = db_session.execute(text('select max(trade_date) from fo_udiff_bhavdata')).scalar()
            last_updated = db_session.query(LastUpdatedDate).first()
            if last_updated:
                last_updated.last_updated_date = latest_trade_date
                db_session.add(last_updated)
            else:
                db_session.add(LastUpdatedDate(last_updated_date=latest_trade_date))
            db_session.commit()

def get_report2():
    with next(get_db()) as db_session:
        _date = request.args.get('date', '')
        if _date:
            try:
                x = datetime.strptime(_date, '%Y-%m-%d')
            except:
                return make_response(jsonify({"message": "Invalid Request"}), 400)
            last_updated = _date
        else:
            last_updated = db_session.execute(text("select DATE_FORMAT(max(last_updated_date), '%Y-%m-%d') as last_updated_date from last_updated_date")).scalar()
            if not last_updated:
                last_updated = db_session.execute(text("select DATE_FORMAT(max(date), '%Y-%m-%d') as last_updated_date from securities_bhavdata")).scalar()

        # Process data (same as before)
        js = db_session.query(FOUDIFFBhavData).filter(FOUDIFFBhavData.trade_date == last_updated).order_by(FOUDIFFBhavData.tckr_symb).all()
        sf_data = db_session.query(SecurityiesBhavData).filter(SecurityiesBhavData.date == last_updated).all()
        sf_data_dict = {}
        for row in sf_data:
            if row.series.strip() == "EQ":
                if row.symbol not in sf_data_dict:
                    sf_data_dict[row.symbol] = {'VWAP': 0, 'CHANGE_IN_PRICE': 0}
                try:
                    sf_data_dict[row.symbol]['VWAP'] = float(row.avg_price)
                except:
                    sf_data_dict[row.symbol]['VWAP'] = 0
                try:
                    sf_data_dict[row.symbol]['CLOSE_PRICE'] = float(row.close_price)
                except:
                    sf_data_dict[row.symbol]['CLOSE_PRICE'] = 0
                try:
                    sf_data_dict[row.symbol]['DELIVERY_PERCENTAGE'] = float(row.delivery_percentage)
                except:
                    sf_data_dict[row.symbol]['DELIVERY_PERCENTAGE'] = 0
                try:
                    sf_data_dict[row.symbol]['TOTAL_OPEN_TRADES'] = float(row.number_of_trades)
                except:
                    sf_data_dict[row.symbol]['TOTAL_OPEN_TRADES'] = 0
                try:
                    sf_data_dict[row.symbol]['CHANGE_IN_PRICE'] = ((float(row.close_price) - float(row.prev_close)) / float(row.prev_close))
                except:
                    sf_data_dict[row.symbol]['CHANGE_IN_PRICE'] = 0
                try:
                    sf_data_dict[row.symbol]['CHANGE_IN_PRICE_LOW'] = ((float(row.close_price) - float(row.low_price)) / float(row.low_price))
                except:
                    sf_data_dict[row.symbol]['CHANGE_IN_PRICE_LOW'] = 0
                try:
                    sf_data_dict[row.symbol]['CHANGE_IN_PRICE_HIGH'] = ((float(row.high_price) - float(row.close_price)) / float(row.high_price))
                except:
                    sf_data_dict[row.symbol]['CHANGE_IN_PRICE_HIGH'] = 0

        processed_bhavcopy_json = {}
        lot_sizes_dict = {}
        for row in js:
            lot_sizes_dict[row.tckr_symb] = row.new_brd_lot_qty
            if row.tckr_symb not in processed_bhavcopy_json:
                processed_bhavcopy_json[row.tckr_symb] = {
                    'Future_OI': 0,
                    'Change_in_Future_OI': 0,
                    "Symbol": row.tckr_symb,
                    'Options_PE_OI': 0,
                    'Change_in_Options_PE_OI': 0,
                    'Options_CE_OI': 0,
                    'Change_in_Options_CE_OI': 0
                }
                processed_bhavcopy_json[row.tckr_symb]['Total_OI'] = int(row.opn_intrst)
                if row.fin_instrm_tp == 'STF':
                    processed_bhavcopy_json[row.tckr_symb]['Future_OI'] = int(row.opn_intrst)
                    processed_bhavcopy_json[row.tckr_symb]['Change_in_Future_OI'] = int(row.chng_in_opn_intrst)
                if row.fin_instrm_tp == 'STO':
                    if row.optn_tp == 'PE':
                        processed_bhavcopy_json[row.tckr_symb]['Options_PE_OI'] = int(row.opn_intrst)
                        processed_bhavcopy_json[row.tckr_symb]['Change_in_Options_PE_OI'] = int(row.chng_in_opn_intrst)
                    elif row.optn_tp == 'CE':
                        processed_bhavcopy_json[row.tckr_symb]['Options_CE_OI'] = int(row.opn_intrst)
                        processed_bhavcopy_json[row.tckr_symb]['Change_in_Options_CE_OI'] = int(row.chng_in_opn_intrst)
            else:
                processed_bhavcopy_json[row.tckr_symb]['Total_OI'] += int(row.opn_intrst)
                if row.fin_instrm_tp == 'STF':
                    processed_bhavcopy_json[row.tckr_symb]['Future_OI'] += int(row.opn_intrst)
                    processed_bhavcopy_json[row.tckr_symb]['Change_in_Future_OI'] += int(row.chng_in_opn_intrst)
                if row.fin_instrm_tp == 'STO':
                    if row.optn_tp == 'PE':
                        processed_bhavcopy_json[row.tckr_symb]['Options_PE_OI'] += int(row.opn_intrst)
                        processed_bhavcopy_json[row.tckr_symb]['Change_in_Options_PE_OI'] += int(row.chng_in_opn_intrst)
                    elif row.optn_tp == 'CE':
                        processed_bhavcopy_json[row.tckr_symb]['Options_CE_OI'] += int(row.opn_intrst)
                        processed_bhavcopy_json[row.tckr_symb]['Change_in_Options_CE_OI'] += int(row.chng_in_opn_intrst)

        # Call the CSV generator function
        synthetic_generator_data_report(last_updated, processed_bhavcopy_json)

        # Return JSON response
        write_first = ["BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "NIFTY", "NIFTYNXT50"]
        sorted_dict_list = sorted(
            list(processed_bhavcopy_json.values()),
            key=lambda d: (0, write_first.index(d.get('Symbol', ''))) if d.get('Symbol', '') in write_first else (1, d.get('name', ''))
        )
        resp = json.dumps({'data': [{
            "Symbol": values['Symbol'],
            "Lot Size": values['lotsize'],
            "Future OI": values['Future_OI'],
            "Change (Future OI)": values['Change_in_Future_OI'],
            "# of lots change (Future OI)": values['Future_lots_Change_OI'],
            "% Change in Future_OI": round(values['Change_percentage_in_Future_OI'], 6),
            "PE OI": values['Options_PE_OI'],
            "Change (PE OI)": values['Change_in_Options_PE_OI'],
            "# of lots change (PE OI)": values['Change_lots_in_PE_OI'],
            "% Change (PE OI)": round(values['Change_percentage_in_PE_OI'], 6),
            "CE OI": values['Options_CE_OI'],
            "Change (CE OI)": values['Change_in_Options_CE_OI'],
            "# of lots change (CE OI)": values['Change_lots_in_CE_OI'],
            "% Change (CE OI)": round(values['Change_percentage_in_CE_OI'], 6),
            "VWAP": values['vwap'],
            "CLOSE PRICE": values['close_price'],
            "Change CE / PE Ratio (OI)": round(values['change_ce_pe_oi_ratio'], 6),
            "Delivery %": round(values['delivery_percentage'], 6),
            "% Change in Price": round(values['change_percentage_in_price'], 6),
            "% Change in Price From Low": round(values['change_percentage_in_price_from_low'], 6),
            "% Change in Price From High": round(values['change_percentage_in_price_from_high'], 6),
            "Decision (Based on Futures": values['decision_based_on_future'],
            "Decision (Based on Options": values['decision_based_on_options'],
            "Decision (Based on Price": values['decision_based_on_price']
        } for values in sorted_dict_list], 'date': last_updated})

        return make_response(resp, 200)


from datetime import datetime
from pathlib import Path
import requests
import csv

def synthetic_generator_data_report(data_date=None, upload_to_remote_server=False):
    """
    Fetches data from the trading API and generates a CSV report.
    """
    try:
        # Define directory path
        directory_path = Path('./Output').resolve()
        if not directory_path.exists():
            directory_path.mkdir(parents=True)
            print(f"Directory '{directory_path}' created.")

        # Define API details
        API_URL = "http://127.0.0.1:9009"
        report_url = f"{API_URL}/get-report2"
        print(f"Fetching data from API: {report_url}")

        # Make API request
        resp = requests.get(report_url)
        if resp.status_code != 200:
            print(f"Error: Failed to fetch data. HTTP Status Code: {resp.status_code}")
            return

        response = resp.json()
        print("API Response received.")

        # Extract data and date from response
        data = response.get('data', [])
        data_date = response.get('date')
        if not data or not data_date:
            print("Error: No data or date in the API response.")
            return

        data_date = datetime.strptime(data_date, '%Y-%m-%d')
        file_name = f"recommendations-{data_date.strftime('%d%b%Y').upper()}.csv"
        file_path = directory_path / file_name
        print(f"Data will be saved to: {file_path}")

        # Write data to CSV
        with open(file_path, "w", newline='') as f:
            f_csv = csv.writer(f)
            f_csv.writerow([
                "Symbol", "Lot Size", "Future OI", "Change (Future OI)", "# of lots change (Future OI)",
                "% Change in Future_OI", "PE OI", "Change (PE OI)", "# of lots change (PE OI)",
                "% Change (PE OI)", "CE OI", "Change (CE OI)", "# of lots change (CE OI)",
                "% Change (CE OI)", "VWAP", "CLOSE PRICE", "Change CE / PE Ratio (OI)",
                "Delivery %", "% Change in Price", "% Change in Price From Low",
                "% Change in Price From High", "Decision (Based on Options",
                "Decision (Based on Futures", "Decision (Based on Price"
            ])

            for x in data:
                f_csv.writerow([
                    x.get('Symbol', ''),
                    x.get('Lot Size', ''),
                    x.get("Future OI", ''),
                    x.get("Change (Future OI)", ''),
                    x.get("# of lots change (Future OI)", ''),
                    x.get("% Change in Future_OI", ''),
                    x.get("PE OI", ''),
                    x.get("Change (PE OI)", ''),
                    x.get("# of lots change (PE OI)", ''),
                    x.get("% Change (PE OI)", ''),
                    x.get("CE OI", ''),
                    x.get("Change (CE OI)", ''),
                    x.get("# of lots change (CE OI)", ''),
                    x.get("% Change (CE OI)", ''),
                    x.get("VWAP", ''),
                    x.get("CLOSE PRICE", ''),
                    x.get("Change CE / PE Ratio (OI)", ''),
                    x.get("Delivery %", ''),
                    x.get("% Change in Price", ''),
                    x.get("% Change in Price From Low", ''),
                    x.get("% Change in Price From High", ''),
                    x.get("Decision (Based on Options", ''),
                    x.get("Decision (Based on Futures", ''),
                    x.get("Decision (Based on Price", '')
                ])
        print(f"Data successfully written to {file_path}")
    
    except Exception as e:
        print(f"An error occurred: {e}")

# Call the function for testing
if __name__ == "__main__":
    synthetic_generator_data_report()
