"""
Raw backfill for fo_udiff_bhavdata (RAW ROWS ONLY).

Unlike main.NSE.add_fo_udiff_bhavcopy_to_db, this does NOT run the stateful
FOStockInstrumentsReport1 update loop -- reprocessing old dates through that
loop would overwrite the "latest" fields with stale data. Reports that read
raw OI (get-report3, get-report6) only need the rows in fo_udiff_bhavdata.

Idempotent: skips trade_dates already present; validates the file's TradDt
matches the requested date (NSE serves a neighbouring day for non-trading days).
`start_date` is left NULL for backfilled rows (not needed by these reports).

Usage:
    python backfill_fo.py 2026-05-29 2026-03-27      # explicit dates
    python backfill_fo.py 2026-03-01 2026-06-19      # a range
"""
import sys
import time
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import text

from db import get_db, engine
from main_old import NSE

# NSE rate-limits/bot-blocks rapid F&O zip downloads (returns an HTML page).
# Throttle between dates and retry blocked dates with a longer backoff.
INTER_DATE_SLEEP = 4      # seconds between successful downloads
DATE_RETRIES = 4
RETRY_BACKOFF = 15        # seconds, multiplied by attempt number

# fo bhavcopy -> fo_udiff_bhavdata column mapping (post-2025 file layout).
_FO_RENAME = {
    'TradDt': 'trade_date', 'BizDt': 'biz_date', 'Sgmt': 'sgmt', 'Src': 'src',
    'FinInstrmTp': 'fin_instrm_tp', 'FinInstrmId': 'fin_instrm_id', 'ISIN': 'isin',
    'TckrSymb': 'tckr_symb', 'SctySrs': 'scty_srs', 'XpryDt': 'xpry_date',
    'FininstrmActlXpryDt': 'fininstrm_actl_xpry_date', 'StrkPric': 'strk_price',
    'OptnTp': 'optn_tp', 'FinInstrmNm': 'fin_instrm_nm', 'OpnPric': 'open_price',
    'HghPric': 'high_price', 'LwPric': 'low_price', 'ClsPric': 'close_price',
    'LastPric': 'last_price', 'PrvsClsgPric': 'prev_closing_price',
    'UndrlygPric': 'undrlyg_price', 'SttlmPric': 'sttlm_price',
    'OpnIntrst': 'opn_intrst', 'ChngInOpnIntrst': 'chng_in_opn_intrst',
    'TtlTradgVol': 'total_trade_volume', 'TtlTrfVal': 'ttl_trf_val',
    'TtlNbOfTxsExctd': 'ttl_nb_of_txs_exctd', 'SsnId': 'ssn_id',
    'NewBrdLotQty': 'new_brd_lot_qty', 'Rmks': 'rmks',
    'Rsvd1': 'rsvd_01', 'Rsvd2': 'rsvd_02', 'Rsvd3': 'rsvd_03', 'Rsvd4': 'rsvd_04',
}
_USECOLS = list(_FO_RENAME.keys())


def _existing_dates():
    with next(get_db()) as s:
        rows = s.execute(text("SELECT DISTINCT trade_date FROM fo_udiff_bhavdata")).all()
    return {r[0].strftime('%Y-%m-%d') for r in rows}


def _trading_days(start, end):
    """Real trading days = dates present in securities_bhavdata (well-filled).
    Avoids wasting retries on market holidays that have no NSE file."""
    with next(get_db()) as s:
        rows = s.execute(text(
            "SELECT DISTINCT `date` FROM securities_bhavdata "
            "WHERE `date` BETWEEN :a AND :b"),
            {"a": start, "b": end}).all()
    return {r[0].strftime('%Y-%m-%d') for r in rows}


def _expand(start, end):
    if end is None:
        end = start
    if start == end:
        return [pd.Timestamp(start)]
    return list(pd.date_range(start=start, end=end, freq='B'))


def _insert_raw(file, d):
    df = pd.read_csv(file, parse_dates=["TradDt", "BizDt", "XpryDt", "FininstrmActlXpryDt"],
                     usecols=_USECOLS)
    got = pd.to_datetime(df['TradDt']).dt.strftime('%Y-%m-%d').dropna().unique()
    if list(got) != [d.strftime('%Y-%m-%d')]:
        file.unlink()
        raise ValueError(f"file TradDt={list(got)} != requested {d:%Y-%m-%d} (non-trading day)")
    df.rename(columns=_FO_RENAME, inplace=True)
    df['start_date'] = pd.NaT  # not computed here; reports don't use it
    df = df.replace({np.nan: None})
    df.to_sql('fo_udiff_bhavdata', engine, if_exists='append', index=False)
    file.unlink()
    return len(df)


def backfill(dates):
    have = _existing_dates()
    trading = _trading_days(dates[0].strftime('%Y-%m-%d'), dates[-1].strftime('%Y-%m-%d'))
    # Only attempt real trading days (in securities) that fo is missing.
    todo = [d for d in dates
            if d.strftime('%Y-%m-%d') in trading
            and d.strftime('%Y-%m-%d') not in have]
    print(f"fo dates requested: {len(dates)} | already present: "
          f"{len([d for d in dates if d.strftime('%Y-%m-%d') in have])} | "
          f"to load (trading-day gaps): {len(todo)}")
    ok, failed = [], []
    for d in todo:
        ds = d.strftime('%Y-%m-%d')
        done = False
        for attempt in range(1, DATE_RETRIES + 1):
            try:
                x = NSE()
                f = x.equity_fo_bhavcopy_final(d)
                n = _insert_raw(f, d)
                print(f"OK   {ds}  ({n} rows)")
                ok.append(ds)
                done = True
                time.sleep(INTER_DATE_SLEEP)
                break
            except ValueError as e:
                # TradDt mismatch -> genuine non-trading day; do not retry.
                print(f"SKIP {ds}: {e}")
                done = True
                break
            except Exception as e:
                # RuntimeError 'unavailable' -> likely rate-limited; back off.
                wait = RETRY_BACKOFF * attempt
                print(f"WARN {ds} attempt {attempt}/{DATE_RETRIES}: {e} (waiting {wait}s)")
                time.sleep(wait)
        if not done:
            failed.append(ds)
    print("\n========== FO RAW BACKFILL SUMMARY ==========")
    print(f"Loaded: {len(ok)}  Failed/skipped: {len(failed)}")
    if failed:
        print("Not loaded:", ", ".join(failed))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python backfill_fo.py <start|date> [end]")
        sys.exit(1)
    dts = _expand(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
    backfill(dts)
