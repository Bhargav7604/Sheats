# import json
# from datetime import datetime
# import numpy as np
# import pandas as pd

# from flask import Flask, make_response, request, jsonify
# from flask_cors import CORS


# from config import settings

# from sqlalchemy import func, text



# HOST = "0.0.0.0"
# PORT = 5000

# app = Flask(__name__)


# CORS(app)


# @app.route('/login', methods=['POST'])
# def login():
#     data = request.get_json()
#     if "email" not in data or "password" not in data:
#         return make_response(jsonify({"message": "Invalid Request"}), 400)
#     if data["email"].lower() not in settings.USERS:
#         return make_response(jsonify({"message": "User not found"}), 404)
#     if data['password'] != settings.USERS.get(data["email"].lower()):
#         return make_response(jsonify({"message": "Invalid Password"}), 401)

#     return make_response(jsonify({
#         "data": {
#             "id": 1,
#             "accessToken": "fsdfjdsgvnoasdnvdsovsdjvbajkBDIUFcnhsabiVsdv"},
#         "message": "Login successful"

#     }), 200)
    
    

# if __name__ == '__main__':
#     app.run(host=HOST, port=PORT, debug=True)



# LOGIN #
####################################################################################

# import json
# from datetime import datetime
# import numpy as np
# import pandas as pd

# from flask import Flask, make_response, request, jsonify
# from flask_cors import CORS
# from flask_sqlalchemy import SQLAlchemy 


# HOST = "0.0.0.0"
# PORT = 5000

# app = Flask(__name__)


# CORS(app)

# # Configure the database (MySQL in this example)
# app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost/users_db'  # Update with your MySQL credentials
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# # Initialize SQLAlchemy
# db = SQLAlchemy(app)

# # Enable CORS
# CORS(app)

# # Define the User model
# class User(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     email = db.Column(db.String(120), unique=True, nullable=False)
#     password = db.Column(db.String(120), nullable=False)

#     def __repr__(self):
#         return f'<User {self.email}>'

# # Create the database tables (only needed once)
# with app.app_context():
#     db.create_all()

# # Login endpoint
# @app.route('/login', methods=['POST'])
# def login():
#     data = request.get_json()

#     # Validate request
#     if "email" not in data or "password" not in data:
#         return make_response(jsonify({"message": "Invalid Request"}), 400)

#     # Query the database for the user
#     user = User.query.filter_by(email=data["email"].lower()).first()

#     # Check if the user exists
#     if not user:
#         return make_response(jsonify({"message": "User not found"}), 404)

#     # Check if the password is correct
#     if data['password'] != user.password:
#         return make_response(jsonify({"message": "Invalid Password"}), 401)

#     # Return success response
#     return make_response(jsonify({
#         "data": {
#             "id": user.id,
#             "accessToken": "fsdfjdsgvnoasdnvdsovsdjvbajkBDIUFcnhsabiVsdv"
#         },
#         "message": "Login successful"
#     }), 200)

# # Run the Flask app
# if __name__ == '__main__':
#     app.run(host="0.0.0.0", port=5000, debug=True)




# import json
# from datetime import datetime
# import numpy as np
# import pandas as pd

# from flask import Flask, make_response, request, jsonify
# from flask_cors import CORS
# from flask_sqlalchemy import SQLAlchemy 


# HOST = "0.0.0.0"
# PORT = 5000

# app = Flask(__name__)

# CORS(app)

# # Configure the database (MySQL in this example)
# app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:root@localhost/users_db'  # Update with your MySQL credentials
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# # Initialize SQLAlchemy
# db = SQLAlchemy(app)

# # Enable CORS
# CORS(app)

# # Define the User model
# class User(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     email = db.Column(db.String(120), unique=True, nullable=False)
#     password = db.Column(db.String(120), nullable=False)
#     is_superuser = db.Column(db.Boolean, default=False)

#     def __repr__(self):
#         return f'<User {self.email}>'

# # Create the database tables (only needed once)
# with app.app_context():
#     db.create_all()

# # Registration endpoint
# @app.route('/register', methods=['POST'])
# def register():
#     data = request.get_json()

#     # Validate request
#     if "email" not in data or "password" not in data:
#         return make_response(jsonify({"message": "Invalid Request"}), 400)

#     # Check if the user already exists
#     if User.query.filter_by(email=data["email"].lower()).first():
#         return make_response(jsonify({"message": "User already exists"}), 409)

#     # Check if a super user already exists
#     is_superuser = data.get("is_superuser", False)
#     if is_superuser and User.query.filter_by(is_superuser=True).first():
#         return make_response(jsonify({"message": "A super user already exists"}), 403)

#     # Create a new user
#     new_user = User(
#         email=data["email"].lower(),
#         password=data["password"],
#         is_superuser=is_superuser
#     )

#     # Add the user to the database
#     db.session.add(new_user)
#     db.session.commit()

#     # Return success response
#     return make_response(jsonify({"message": "User registered successfully"}), 201)

# # Login endpoint
# @app.route('/login', methods=['POST'])
# def login():
#     data = request.get_json()

#     # Validate request
#     if "email" not in data or "password" not in data:
#         return make_response(jsonify({"message": "Invalid Request"}), 400)

#     # Query the database for the user
#     user = User.query.filter_by(email=data["email"].lower()).first()

#     # Check if the user exists
#     if not user:
#         return make_response(jsonify({"message": "User not found"}), 404)

#     # Check if the password is correct
#     if data['password'] != user.password:
#         return make_response(jsonify({"message": "Invalid Password"}), 401)

#     # Return success response
#     return make_response(jsonify({
#         "data": {
#             "id": user.id,
#             "accessToken": "fsdfjdsgvnoasdnvdsovsdjvbajkBDIUFcnhsabiVsdv"
#         },
#         "message": "Login successful"
#     }), 200)

# # Run the Flask app
# if __name__ == '__main__':
#     app.run(host=HOST, port=PORT, debug=True)




# import re
# import random
# import time
# import os
# import bcrypt
# import mysql.connector
# from dotenv import load_dotenv
# from flask import Flask, request, jsonify, session
# from flask_cors import CORS
# from flask_mail import Mail, Message

# # Load environment variables
# load_dotenv()

# # Initialize Flask app
# app = Flask(__name__)

# # Secret Key for Session Management
# app.secret_key = os.getenv("SECRET_KEY", "your_default_secret_key")

# # Enable CORS for React Frontend
# CORS(app, supports_credentials=True)

# # MySQL Database Configuration
# db_config = {
#     'user': 'root',
#     'password': 'root',
#     'host': 'localhost',
#     'database': 'users_db'
# }

# # Temporary store for OTPs
# otp_storage = {}
# OTP_EXPIRY_TIME = 300  # 5 minutes

# # ---------------------- Database Connection Function ---------------------- #
# def get_db_connection():
#     """Establish a connection to the MySQL database."""
#     try:
#         conn = mysql.connector.connect(**db_config)
#         return conn
#     except mysql.connector.Error as e:
#         print(f"Database connection error: {e}")
#         return None


# # ---------------------- Email Validation Function ---------------------- #
# def is_valid_gmail(email):
#     """Validate if the email is a proper Gmail address."""
#     if email is None:
#         return False
#     return bool(re.match(r"^[a-zA-Z0-9._%+-]+@gmail\.com$", email))


# # ---------------------- Check If User Exists ---------------------- #
# def user_exists(email):
#     """Check if a user already exists in the database."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor()
#         cursor.execute("SELECT * FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         return user is not None
#     return False


# # ---------------------- Register User ---------------------- #
# def register_user(email, password):
#     """Register a new user with a hashed password."""
#     hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor()
#         cursor.execute("INSERT INTO user (email, password) VALUES (%s, %s)", (email, hashed_password))
#         conn.commit()
#         cursor.close()
#         conn.close()


# # ---------------------- Check Login Credentials ---------------------- #
# def check_login(email, password):
#     """Check user login credentials."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT id, email, password FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
#             return user  # Valid user
#     return None  # Invalid credentials


# # ---------------------- Send OTP via Email ---------------------- #
# def send_otp(email):
#     """Send a structured OTP email to the user."""
#     otp = str(random.randint(100000, 999999))  # Generate 6-digit OTP
#     otp_storage[email] = otp  # Store OTP temporarily

#     subject = "Your OTP for Password Reset"
#     body = f"""
#     <html>
#     <body>
#         <h2 style="color: #333;">Hello,</h2>
#         <p style="font-size: 16px;">We received a request to reset your password.</p>
#         <p style="font-size: 18px; font-weight: bold;">Your OTP is: <span style="color: #d9534f;">{otp}</span></p>
#         <p style="font-size: 14px;">This OTP is valid for <b>10 minutes</b>. Please do not share it with anyone.</p>
#         <hr>
#         <p style="font-size: 12px; color: #555;">If you didn't request this, please ignore this email or contact support.</p>
#         <p style="font-size: 12px; color: #555;">Best regards, <br> <b>Your App Team</b></p>
#     </body>
#     </html>
#     """

#     msg = Message(subject, sender=app.config['MAIL_USERNAME'], recipients=[email])
#     msg.html = body  # Use HTML content for better formatting

#     try:
#         mail.send(msg)
#         return True
#     except Exception as e:
#         print("Error sending email:", e)
#         return False
    
# def is_valid_password(password):
#     """Validate password strength."""
#     return bool(re.match(r"^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$", password))


# # ---------------------- User Registration Route ---------------------- #
# @app.route('/register', methods=['POST'])
# def register():
#     """Handle user registration."""
#     data = request.json
#     email = data.get('email')
#     password = data.get('password')

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Please enter a valid Gmail address."}), 400

#     if user_exists(email):
#         return jsonify({"error": "This email is already registered. Please log in."}), 400

#     register_user(email, password)
#     return jsonify({"message": "✅ Registration successful!"}), 201


# # ---------------------- User Login Route ---------------------- #
# @app.route('/login', methods=['POST'])
# def login():
#     """Handle user login."""
#     data = request.get_json()
#     email = data.get('email')
#     password = data.get('password')

#     if not email or not password:
#         return jsonify({"error": "❌ Username and password are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     user = check_login(email, password)
#     if user:
#         session['user_id'] = user['id']
#         session['email'] = user['email']
#         return jsonify({"message": "✅ Login successful!", "email": user['email']}), 200
#     else:
#         return jsonify({"error": "❌ Invalid email or password."}), 401


# # ---------------------- Forgot Password (Send OTP) ---------------------- #
# @app.route('/forgot-password', methods=['POST'])
# def forgot_password():
#     """Handle forgotten password - Send OTP."""
#     data = request.json
#     email = data.get('email')

#     if not email or not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     if not user_exists(email):
#         return jsonify({"error": "❌ Email is not registered."}), 400

#     if send_otp(email):
#         return jsonify({"message": "✅ OTP sent to your email. Please check your inbox."}), 200
#     else:
#         return jsonify({"error": "❌ Failed to send OTP. Try again later."}), 500
    
# # -------- Routes -------- #
# @app.route('/reset-password', methods=['POST'])
# def reset_password():
#     """Reset user password and send OTP."""
#     data = request.json
#     email = data.get('email')
#     new_password = data.get('new_password')
#     confirm_password = data.get('confirm_password')

#     if not email or not new_password or not confirm_password:
#         return jsonify({"error": "All fields are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Invalid Gmail address."}), 400

#     if new_password != confirm_password:
#         return jsonify({"error": "Passwords do not match."}), 400

#     if not is_valid_password(new_password):
#         return jsonify({"error": "Password must be at least 8 characters long, include an uppercase letter, a number, and a special character."}), 400

#     existing_user = user_exists(email)
#     if not existing_user:
#         return jsonify({"error": "Email not registered."}), 400

#     # Prevent setting the same password
#     hashed_new_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     existing_hashed_password = existing_user[0]
#     if bcrypt.checkpw(new_password.encode('utf-8'), existing_hashed_password.encode('utf-8')):
#         return jsonify({"error": "New password cannot be the same as the old password."}), 400

#     # Update password in database
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("UPDATE user SET password = %s WHERE email = %s", (hashed_new_password, email))
#     conn.commit()
#     cursor.close()
#     conn.close()

#     # Send OTP after updating password
#     if send_otp(email):
#         return jsonify({"message": "Password reset successful! An OTP has been sent to confirm your reset."}), 200
#     else:
#         return jsonify({"error": "Password updated, but OTP failed to send. Try again."}), 500

# @app.route('/verify-otp', methods=['POST'])
# def verify_otp():
#     """Verify OTP after password reset."""
#     data = request.json
#     email = data.get('email')
#     otp = data.get('otp')

#     if not email or not otp:
#         return jsonify({"error": "Email and OTP are required."}), 400

#     stored_data = otp_storage.get(email)
#     if not stored_data:
#         return jsonify({"error": "OTP expired or not found."}), 400

#     # Check OTP expiration (5 minutes)
#     if time.time() - stored_data["timestamp"] > OTP_EXPIRY_TIME:
#         del otp_storage[email]
#         return jsonify({"error": "OTP has expired. Please request a new one."}), 400

#     if stored_data["otp"] == otp:
#         del otp_storage[email]  # Remove OTP after successful verification
#         return jsonify({"message": "OTP verified! You may now reset your password."}), 200
#     else:
#         return jsonify({"error": "Invalid OTP. Try again."}), 400

# # ---------------------- Logout ---------------------- #
# @app.route('/logout', methods=['POST'])
# def logout():
#     """Logout user."""
#     session.clear()
#     return jsonify({"message": "✅ Logout successful!"}), 200


# # ---------------------- Run Flask App ---------------------- #
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)





# import re
# import random
# import time
# import os
# import bcrypt
# import mysql.connector
# from dotenv import load_dotenv
# from flask import Flask, request, jsonify, session
# from flask_cors import CORS
# from flask_mail import Mail, Message

# # Load environment variables
# load_dotenv()

# # Initialize Flask app
# app = Flask(__name__)

# # Secret Key for Session Management
# app.secret_key = os.getenv("SECRET_KEY", "your_default_secret_key")

# # Enable CORS for React Frontend
# CORS(app, supports_credentials=True)


# # MySQL Database Configuration
# db_config = {
#     'user': 'root',
#     'password': 'root',
#     'host': 'localhost',
#     'database': 'users_db'
# }

# # Temporary store for OTPs
# otp_storage = {}
# OTP_EXPIRY_TIME = 300  # 5 minutes

# # ---------------------- Database Connection Function ---------------------- #
# def get_db_connection():
#     """Establish a connection to the MySQL database."""
#     try:
#         conn = mysql.connector.connect(**db_config)
#         return conn
#     except mysql.connector.Error as e:
#         print(f"Database connection error: {e}")
#         return None


# # ---------------------- Email Validation Function ---------------------- #
# def is_valid_gmail(email):
#     """Validate if the email is a proper Gmail address."""
#     if email is None:
#         return False
#     return bool(re.match(r"^[a-zA-Z0-9._%+-]+@gmail\.com$", email))


# # ---------------------- Check If User Exists ---------------------- #
# def user_exists(email):
#     """Check if a user already exists in the database."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT * FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         return user  # Return the user data
#     return None


# # ---------------------- Register User ---------------------- #
# def register_user(email, password):
#     """Register a new user with a hashed password."""
#     hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor()
#         cursor.execute("INSERT INTO user (email, password) VALUES (%s, %s)", (email, hashed_password))
#         conn.commit()
#         cursor.close()
#         conn.close()


# # ---------------------- Check Login Credentials ---------------------- #
# def check_login(email, password):
#     """Check user login credentials."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT id, email, password FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
#             return user  # Valid user
#     return None  # Invalid credentials


# # ---------------------- Send OTP via Email ---------------------- #
# def send_otp(email):
#     """Send a structured OTP email to the user."""
#     otp = str(random.randint(100000, 999999))  # Generate 6-digit OTP
#     otp_storage[email] = {"otp": otp, "timestamp": time.time()}  # Store OTP and timestamp

#     subject = "Your OTP for Password Reset"
#     body = f"""
#     <html>
#     <body>
#         <h2 style="color: #333;">Hello,</h2>
#         <p style="font-size: 16px;">We received a request to reset your password.</p>
#         <p style="font-size: 18px; font-weight: bold;">Your OTP is: <span style="color: #d9534f;">{otp}</span></p>
#         <p style="font-size: 14px;">This OTP is valid for <b>10 minutes</b>. Please do not share it with anyone.</p>
#         <hr>
#         <p style="font-size: 12px; color: #555;">If you didn't request this, please ignore this email or contact support.</p>
#         <p style="font-size: 12px; color: #555;">Best regards, <br> <b>Your App Team</b></p>
#     </body>
#     </html>
#     """

#     msg = Message(subject, sender=app.config['MAIL_USERNAME'], recipients=[email])
#     msg.html = body  # Use HTML content for better formatting

#     try:
#         mail.send(msg)
#         return True
#     except Exception as e:
#         print("Error sending email:", e)
#         return False


# # ---------------------- User Registration Route ---------------------- #
# @app.route('/register', methods=['POST'])
# def register():
#     """Handle user registration."""
#     data = request.json
#     email = data.get('email')
#     password = data.get('password')

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Please enter a valid Gmail address."}), 400

#     if user_exists(email):
#         return jsonify({"error": "This email is already registered. Please log in."}), 400

#     register_user(email, password)
#     return jsonify({"message": "✅ Registration successful!"}), 201


# # ---------------------- User Login Route ---------------------- #
# @app.route('/login', methods=['POST'])
# def login():
#     """Handle user login."""
#     data = request.get_json()
#     email = data.get('email')
#     password = data.get('password')

#     if not email or not password:
#         return jsonify({"error": "❌ Username and password are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     user = check_login(email, password)
#     if user:
#         session['user_id'] = user['id']
#         session['email'] = user['email']
#         return jsonify({"message": "✅ Login successful!", "email": user['email']}), 200
#     else:
#         return jsonify({"error": "❌ Invalid email or password."}), 401


# # ---------------------- Forgot Password (Send OTP) ---------------------- #
# @app.route('/forgot-password', methods=['POST'])
# def forgot_password():
#     """Handle forgotten password - Send OTP."""
#     data = request.json
#     email = data.get('email')

#     if not email or not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     if not user_exists(email):
#         return jsonify({"error": "❌ Email is not registered."}), 400

#     if send_otp(email):
#         return jsonify({"message": "✅ OTP sent to your email. Please check your inbox."}), 200
#     else:
#         return jsonify({"error": "❌ Failed to send OTP. Try again later."}), 500


# # ---------------------- Reset Password ---------------------- #
# @app.route('/reset-password', methods=['POST'])
# def reset_password():
#     """Reset user password and send OTP."""
#     data = request.json
#     email = data.get('email')
#     new_password = data.get('new_password')
#     confirm_password = data.get('confirm_password')

#     if not email or not new_password or not confirm_password:
#         return jsonify({"error": "All fields are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Invalid Gmail address."}), 400

#     if new_password != confirm_password:
#         return jsonify({"error": "Passwords do not match."}), 400

#     if not is_valid_password(new_password):
#         return jsonify({"error": "Password must be at least 8 characters long, include an uppercase letter, a number, and a special character."}), 400

#     existing_user = user_exists(email)
#     if not existing_user:
#         return jsonify({"error": "Email not registered."}), 400

#     # Prevent setting the same password
#     if bcrypt.checkpw(new_password.encode('utf-8'), existing_user['password'].encode('utf-8')):
#         return jsonify({"error": "New password cannot be the same as the old password."}), 400

#     # Update password in database
#     hashed_new_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("UPDATE user SET password = %s WHERE email = %s", (hashed_new_password, email))
#     conn.commit()
#     cursor.close()
#     conn.close()

#     # Send OTP after updating password
#     if send_otp(email):
#         return jsonify({"message": "Password reset successful! An OTP has been sent to confirm your reset."}), 200
#     else:
#         return jsonify({"error": "Password updated, but OTP failed to send. Try again."}), 500


# # ---------------------- Verify OTP ---------------------- #
# @app.route('/verify-otp', methods=['POST'])
# def verify_otp():
#     """Verify OTP after password reset."""
#     data = request.json
#     email = data.get('email')
#     otp = data.get('otp')

#     if not email or not otp:
#         return jsonify({"error": "Email and OTP are required."}), 400

#     stored_data = otp_storage.get(email)
#     if not stored_data:
#         return jsonify({"error": "OTP expired or not found."}), 400

#     # Check OTP expiration (5 minutes)
#     if time.time() - stored_data["timestamp"] > OTP_EXPIRY_TIME:
#         del otp_storage[email]
#         return jsonify({"error": "OTP has expired. Please request a new one."}), 400

#     if stored_data["otp"] == otp:
#         del otp_storage[email]  # Remove OTP after successful verification
#         return jsonify({"message": "OTP verified! You may now reset your password."}), 200
#     else:
#         return jsonify({"error": "Invalid OTP. Try again."}), 400


# # ---------------------- Logout ---------------------- #
# @app.route('/logout', methods=['POST'])
# def logout():
#     """Logout user."""
#     session.clear()
#     return jsonify({"message": "✅ Logout successful!"}), 200


# # ---------------------- Run Flask App ---------------------- #
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)




# import re
# import random
# import time
# import os
# import bcrypt
# import mysql.connector
# import smtplib
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
# from dotenv import load_dotenv
# from flask import Flask, request, jsonify, session
# from flask_cors import CORS

# # Load environment variables
# load_dotenv()

# # Initialize Flask app
# app = Flask(__name__)

# # Secret Key for Session Management
# app.secret_key = os.getenv("SECRET_KEY", "your_default_secret_key")

# # Enable CORS for React Frontend
# CORS(app, supports_credentials=True)

# # MySQL Database Configuration
# db_config = {
#     'user': 'root',
#     'password': 'root',
#     'host': 'localhost',
#     'database': 'users_db'
# }

# # Temporary store for OTPs
# otp_storage = {}
# OTP_EXPIRY_TIME = 300  # 5 minutes

# # ---------------------- Database Connection Function ---------------------- #
# def get_db_connection():
#     """Establish a connection to the MySQL database."""
#     try:
#         conn = mysql.connector.connect(**db_config)
#         return conn
#     except mysql.connector.Error as e:
#         print(f"Database connection error: {e}")
#         return None


# # ---------------------- Email Validation Function ---------------------- #
# def is_valid_gmail(email):
#     """Validate if the email is a proper Gmail address."""
#     if email is None:
#         return False
#     return bool(re.match(r"^[a-zA-Z0-9._%+-]+@gmail\.com$", email))


# # ---------------------- Check If User Exists ---------------------- #
# def user_exists(email):
#     """Check if a user already exists in the database."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT * FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         return user  # Return the user data
#     return None


# # ---------------------- Register User ---------------------- #
# def register_user(email, password):
#     """Register a new user with a hashed password."""
#     hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor()
#         cursor.execute("INSERT INTO user (email, password) VALUES (%s, %s)", (email, hashed_password))
#         conn.commit()
#         cursor.close()
#         conn.close()


# # ---------------------- Check Login Credentials ---------------------- #
# def check_login(email, password):
#     """Check user login credentials."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT id, email, password FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
#             return user  # Valid user
#     return None  # Invalid credentials


# # ---------------------- Send OTP via Email ---------------------- #
# def send_otp(email):
#     """Send a structured OTP email to the user using smtplib."""
#     otp = str(random.randint(100000, 999999))  # Generate 6-digit OTP
#     otp_storage[email] = {"otp": otp, "timestamp": time.time()}  # Store OTP and timestamp

#     # Create the email
#     subject = "Your OTP for Password Reset"
#     body = f"""
#     <html>
#     <body>
#         <h2 style="color: #333;">Hello,</h2>
#         <p style="font-size: 16px;">We received a request to reset your password.</p>
#         <p style="font-size: 18px; font-weight: bold;">Your OTP is: <span style="color: #d9534f;">{otp}</span></p>
#         <p style="font-size: 14px;">This OTP is valid for <b>10 minutes</b>. Please do not share it with anyone.</p>
#         <hr>
#         <p style="font-size: 12px; color: #555;">If you didn't request this, please ignore this email or contact support.</p>
#         <p style="font-size: 12px; color: #555;">Best regards, <br> <b>Your App Team</b></p>
#     </body>
#     </html>
#     """

#     # Create the MIME message
#     msg = MIMEMultipart()
#     msg["From"] = sender_email
#     msg["To"] = email
#     msg["Subject"] = subject
#     msg.attach(MIMEText(body, "html"))

#     try:
#         # Connect to the SMTP server
#         with smtplib.SMTP(smtp_server, smtp_port) as server:
#             server.starttls()  # Secure the connection
#             server.login(sender_email, sender_password)
#             server.sendmail(sender_email, email, msg.as_string())
#         print(f"OTP sent successfully to {email}")
#         return True
#     except Exception as e:
#         print(f"Failed to send OTP: {e}")
#         return False


# # ---------------------- User Registration Route ---------------------- #
# @app.route('/register', methods=['POST'])
# def register():
#     """Handle user registration."""
#     data = request.json
#     email = data.get('email')
#     password = data.get('password')

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Please enter a valid Gmail address."}), 400

#     if user_exists(email):
#         return jsonify({"error": "This email is already registered. Please log in."}), 400

#     register_user(email, password)
#     return jsonify({"message": "✅ Registration successful!"}), 201


# # ---------------------- User Login Route ---------------------- #
# @app.route('/login', methods=['POST'])
# def login():
#     """Handle user login."""
#     data = request.get_json()
#     email = data.get('email')
#     password = data.get('password')

#     if not email or not password:
#         return jsonify({"error": "❌ Username and password are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     user = check_login(email, password)
#     if user:
#         session['user_id'] = user['id']
#         session['email'] = user['email']
#         return jsonify({"message": "✅ Login successful!", "email": user['email']}), 200
#     else:
#         return jsonify({"error": "❌ Invalid email or password."}), 401


# # ---------------------- Forgot Password (Send OTP) ---------------------- #
# @app.route('/forgot-password', methods=['POST'])
# def forgot_password():
#     """Handle forgotten password - Send OTP."""
#     data = request.json
#     email = data.get('email')

#     if not email or not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     if not user_exists(email):
#         return jsonify({"error": "❌ Email is not registered."}), 400

#     if send_otp(email):
#         return jsonify({"message": "✅ OTP sent to your email. Please check your inbox."}), 200
#     else:
#         return jsonify({"error": "❌ Failed to send OTP. Try again later."}), 500


# # ---------------------- Reset Password ---------------------- #
# @app.route('/reset-password', methods=['POST'])
# def reset_password():
#     """Reset user password and send OTP."""
#     data = request.json
#     email = data.get('email')
#     new_password = data.get('new_password')
#     confirm_password = data.get('confirm_password')

#     if not email or not new_password or not confirm_password:
#         return jsonify({"error": "All fields are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Invalid Gmail address."}), 400

#     if new_password != confirm_password:
#         return jsonify({"error": "Passwords do not match."}), 400

#     existing_user = user_exists(email)
#     if not existing_user:
#         return jsonify({"error": "Email not registered."}), 400

#     # Prevent setting the same password
#     if bcrypt.checkpw(new_password.encode('utf-8'), existing_user['password'].encode('utf-8')):
#         return jsonify({"error": "New password cannot be the same as the old password."}), 400

#     # Update password in database
#     hashed_new_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     conn = get_db_connection()
#     cursor = conn.cursor()
#     cursor.execute("UPDATE user SET password = %s WHERE email = %s", (hashed_new_password, email))
#     conn.commit()
#     cursor.close()
#     conn.close()

#     # Send OTP after updating password
#     if send_otp(email):
#         return jsonify({"message": "Password reset successful! An OTP has been sent to confirm your reset."}), 200
#     else:
#         return jsonify({"error": "Password updated, but OTP failed to send. Try again."}), 500


# # ---------------------- Verify OTP ---------------------- #
# @app.route('/verify-otp', methods=['POST'])
# def verify_otp():
#     """Verify OTP after password reset."""
#     data = request.json
#     email = data.get('email')
#     otp = data.get('otp')

#     if not email or not otp:
#         return jsonify({"error": "Email and OTP are required."}), 400

#     stored_data = otp_storage.get(email)
#     if not stored_data:
#         return jsonify({"error": "OTP expired or not found."}), 400

#     # Check OTP expiration (5 minutes)
#     if time.time() - stored_data["timestamp"] > OTP_EXPIRY_TIME:
#         del otp_storage[email]
#         return jsonify({"error": "OTP has expired. Please request a new one."}), 400

#     if stored_data["otp"] == otp:
#         del otp_storage[email]  # Remove OTP after successful verification
#         return jsonify({"message": "OTP verified! You may now reset your password."}), 200
#     else:
#         return jsonify({"error": "Invalid OTP. Try again."}), 400


# # ---------------------- Logout ---------------------- #
# @app.route('/logout', methods=['POST'])
# def logout():
#     """Logout user."""
#     session.clear()
#     return jsonify({"message": "✅ Logout successful!"}), 200


# # ---------------------- Run Flask App ---------------------- #
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)







#working

# import re
# import random
# import time
# import os
# import bcrypt
# import mysql.connector
# import smtplib
# from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
# from dotenv import load_dotenv
# from flask import Flask, request, jsonify, session
# from flask_cors import CORS

# # Load environment variables
# load_dotenv()

# # Initialize Flask app
# app = Flask(__name__)

# # Secret Key for Session Management
# app.secret_key = os.getenv("SECRET_KEY", "your_default_secret_key")

# # Enable CORS for React Frontend
# CORS(app, supports_credentials=True)

# # MySQL Database Configuration
# db_config = {
#     'user': 'root',
#     'password': 'root',
#     'host': 'localhost',
#     'database': 'users_db'
# }

# # Temporary store for OTPs
# otp_storage = {}
# OTP_EXPIRY_TIME = 300  # 5 minutes

# # ---------------------- Database Connection Function ---------------------- #
# def get_db_connection():
#     """Establish a connection to the MySQL database."""
#     try:
#         conn = mysql.connector.connect(**db_config)
#         return conn
#     except mysql.connector.Error as e:
#         print(f"Database connection error: {e}")
#         return None


# # ---------------------- Email Validation Function ---------------------- #
# def is_valid_gmail(email):
#     """Validate if the email is a proper Gmail address."""
#     if email is None:
#         return False
#     return bool(re.match(r"^[a-zA-Z0-9._%+-]+@gmail\.com$", email))


# # ---------------------- Check If User Exists ---------------------- #
# def user_exists(email):
#     """Check if a user already exists in the database."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT * FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         return user  # Return the user data
#     return None


# # ---------------------- Register User ---------------------- #
# def register_user(email, password):
#     """Register a new user with a hashed password."""
#     hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor()
#         cursor.execute("INSERT INTO user (email, password) VALUES (%s, %s)", (email, hashed_password))
#         conn.commit()
#         cursor.close()
#         conn.close()


# # ---------------------- Check Login Credentials ---------------------- #
# def check_login(email, password):
#     """Check user login credentials."""
#     conn = get_db_connection()
#     if conn:
#         cursor = conn.cursor(dictionary=True)
#         cursor.execute("SELECT id, email, password FROM user WHERE email = %s", (email,))
#         user = cursor.fetchone()
#         cursor.close()
#         conn.close()
#         if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
#             return user  # Valid user
#     return None  # Invalid credentials


#     # Create the email
#     subject = "Your One-Time Password (OTP)"
#     body = f"Your OTP is: {otp}. Do not share this with anyone."

#     message = MIMEMultipart()
#     message["From"] = sender_email
#     message["To"] = receiver_email
#     message["Subject"] = subject
#     message.attach(MIMEText(body, "plain"))

#     try:
#         # Connect to the SMTP server
#         with smtplib.SMTP(smtp_server, smtp_port) as server:
#             server.starttls()  # Secure the connection
#             server.login(sender_email, sender_password)
#             server.sendmail(sender_email, receiver_email, message.as_string())
#         print(f"OTP sent successfully to {receiver_email}")
#         return True
#     except Exception as e:
#         print(f"Failed to send OTP: {e}")
#         return False


# # ---------------------- User Registration Route ---------------------- #
# @app.route('/register', methods=['POST'])
# def register():
#     """Handle user registration."""
#     data = request.json
#     email = data.get('email')
#     password = data.get('password')

#     if not is_valid_gmail(email):
#         return jsonify({"error": "Please enter a valid Gmail address."}), 400

#     if user_exists(email):
#         return jsonify({"error": "This email is already registered. Please log in."}), 400

#     register_user(email, password)
#     return jsonify({"message": "✅ Registration successful!"}), 201


# # ---------------------- User Login Route ---------------------- #
# @app.route('/login', methods=['POST'])
# def login():
#     """Handle user login."""
#     data = request.get_json()
#     email = data.get('email')
#     password = data.get('password')

#     if not email or not password:
#         return jsonify({"error": "❌ Username and password are required."}), 400

#     if not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     user = check_login(email, password)
#     if user:
#         session['user_id'] = user['id']
#         session['email'] = user['email']
#         return jsonify({"message": "✅ Login successful!", "email": user['email']}), 200
#     else:
#         return jsonify({"error": "❌ Invalid email or password."}), 401


# # ---------------------- Forgot Password (Send OTP) ---------------------- #
# @app.route('/forgot-password', methods=['POST'])
# def forgot_password():
#     """Handle forgotten password - Send OTP."""
#     data = request.json
#     email = data.get('email')

#     if not email or not is_valid_gmail(email):
#         return jsonify({"error": "❌ Please enter a valid Gmail address."}), 400

#     if not user_exists(email):
#         return jsonify({"error": "❌ Email is not registered."}), 400

#     # Generate OTP
#     otp = str(random.randint(100000, 999999))  # Generate 6-digit OTP
#     otp_storage[email] = {"otp": otp, "timestamp": time.time()}  # Store OTP and timestamp

#     # Send OTP via email
#     if send_otp_email(email, otp):
#         return jsonify({"message": "✅ OTP sent to your email. Please check your inbox."}), 200
#     else:
#         return jsonify({"error": "❌ Failed to send OTP. Try again later."}), 500


# # ---------------------- Verify OTP ---------------------- #
# @app.route('/verify-otp', methods=['POST'])
# def verify_otp():
#     """Verify OTP after password reset."""
#     data = request.json
#     email = data.get('email')
#     otp = data.get('otp')

#     if not email or not otp:
#         return jsonify({"error": "Email and OTP are required."}), 400

#     stored_data = otp_storage.get(email)
#     if not stored_data:
#         return jsonify({"error": "OTP expired or not found."}), 400

#     # Check OTP expiration (5 minutes)
#     if time.time() - stored_data["timestamp"] > OTP_EXPIRY_TIME:
#         del otp_storage[email]
#         return jsonify({"error": "OTP has expired. Please request a new one."}), 400

#     if stored_data["otp"] == otp:
#         del otp_storage[email]  # Remove OTP after successful verification
#         return jsonify({"message": "OTP verified! You may now reset your password."}), 200
#     else:
#         return jsonify({"error": "Invalid OTP. Try again."}), 400


# # ---------------------- Logout ---------------------- #
# @app.route('/logout', methods=['POST'])
# def logout():
#     """Logout user."""
#     session.clear()
#     return jsonify({"message": "✅ Logout successful!"}), 200


# # ---------------------- Run Flask App ---------------------- #
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)




import re
import random
import time
import os
import bcrypt
import mysql.connector
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv
from flask import Flask, request, jsonify, session
from flask_cors import CORS

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Secret Key for Session Management
app.secret_key = os.getenv("SECRET_KEY", "your_default_secret_key")

# Enable CORS for React Frontend
CORS(app, supports_credentials=True)

# MySQL Database Configuration
db_config = {
    'user': 'root',
    'password': 'root',
    'host': 'localhost',
    'database': 'users_db'
}

# Temporary store for OTPs
otp_storage = {}
OTP_EXPIRY_TIME = 300  # 5 minutes

# ---------------------- Database Connection Function ---------------------- #
def get_db_connection():
    """Establish a connection to the MySQL database."""
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except mysql.connector.Error as e:
        print(f"Database connection error: {e}")
        return None


# ---------------------- Email Validation Function ---------------------- #
def is_valid_gmail(email):
    """Validate if the email is a proper Gmail address."""
    if email is None:
        return False
    return bool(re.match(r"^[a-zA-Z0-9._%+-]+@gmail\.com$", email))


# ---------------------- Check If User Exists ---------------------- #
def user_exists(email):
    """Check if a user already exists in the database."""
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM user WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user  # Return the user data
    return None


# ---------------------- Register User ---------------------- #
def register_user(email, password):
    """Register a new user with a hashed password."""
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO user (email, password) VALUES (%s, %s)", (email, hashed_password))
        conn.commit()
        cursor.close()
        conn.close()


# ---------------------- Check Login Credentials ---------------------- #
def check_login(email, password):
    """Check user login credentials."""
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, email, password FROM user WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        if user and bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
            return user  # Valid user
    return None  # Invalid credentials


# ---------------------- Send OTP via Email ---------------------- #
def send_otp_email(receiver_email, otp):
    """Send a structured OTP email to the user."""
    # Email configuration
    sender_email = "example@gmail.com"  # Replace with your email
    sender_password = "password"  # Replace with your email password
    smtp_server = "smtp.gmail.com"
    smtp_port = 587

    # Create the email
    subject = "Your One-Time Password (OTP)"
    body = f"Your OTP is: {otp}. Do not share this with anyone."

    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = subject
    message.attach(MIMEText(body, "plain"))

    try:
        # Connect to the SMTP server
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()  # Secure the connection
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, message.as_string())
        print(f"OTP sent successfully to {receiver_email}")
        return True
    except Exception as e:
        print(f"Failed to send OTP: {e}")
        return False


# ---------------------- User Registration Route ---------------------- #
@app.route('/register', methods=['POST'])
def register():
    """Handle user registration."""
    data = request.json
    email = data.get('email')
    password = data.get('password')

    if not is_valid_gmail(email):
        return jsonify({"error": "Please enter a valid Gmail address."}), 400

    if user_exists(email):
        return jsonify({"error": "This email is already registered. Please log in."}), 400

    register_user(email, password)
    return jsonify({"message": "Registration successful!"}), 201


# ---------------------- User Login Route ---------------------- #
@app.route('/login', methods=['POST'])
def login():
    """Handle user login."""
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({"error": "Username and password are required."}), 400

    if not is_valid_gmail(email):
        return jsonify({"error": "Please enter a valid Gmail address."}), 400

    user = check_login(email, password)
    if user:
        session['user_id'] = user['id']
        session['email'] = user['email']
        return jsonify({"message": "Login successful!", "email": user['email']}), 200
    else:
        return jsonify({"error": "Invalid email or password."}), 401


# ---------------------- Forgot Password (Send OTP) ---------------------- #
@app.route('/forgot-password', methods=['POST'])
def forgot_password():
    """Handle forgotten password - Send OTP."""
    data = request.json
    email = data.get('email')

    if not email or not is_valid_gmail(email):
        return jsonify({"error": "Please enter a valid Gmail address."}), 400

    if not user_exists(email):
        return jsonify({"error": "Email is not registered."}), 400

    # Generate OTP
    otp = str(random.randint(100000, 999999))  # Generate 6-digit OTP
    otp_storage[email] = {"otp": otp, "timestamp": time.time()}  # Store OTP and timestamp

    # Send OTP via email
    if send_otp_email(email, otp):
        return jsonify({"message": "✅ OTP sent to your email. Please check your inbox."}), 200
    else:
        return jsonify({"error": "Failed to send OTP. Try again later."}), 500


# ---------------------- Verify OTP ---------------------- #
@app.route('/verify-otp', methods=['POST'])
def verify_otp():
    """Verify OTP after password reset."""
    data = request.json
    email = data.get('email')
    otp = data.get('otp')

    if not email or not otp:
        return jsonify({"error": "Email and OTP are required."}), 400

    stored_data = otp_storage.get(email)
    if not stored_data:
        return jsonify({"error": "OTP expired or not found."}), 400

    # Check OTP expiration (5 minutes)
    if time.time() - stored_data["timestamp"] > OTP_EXPIRY_TIME:
        del otp_storage[email]
        return jsonify({"error": "OTP has expired. Please request a new one."}), 400

    if stored_data["otp"] == otp:
        del otp_storage[email]  # Remove OTP after successful verification
        return jsonify({"message": "OTP verified! You may now reset your password."}), 200
    else:
        return jsonify({"error": "Invalid OTP. Try again."}), 400


# ---------------------- Reset Password ---------------------- #
@app.route('/reset-password', methods=['POST'])
def reset_password():
    """Reset user password."""
    data = request.json
    email = data.get('email')
    new_password = data.get('new_password')
    confirm_password = data.get('confirm_password')

    if not email or not new_password or not confirm_password:
        return jsonify({"error": "All fields are required."}), 400

    if not is_valid_gmail(email):
        return jsonify({"error": "Invalid Gmail address."}), 400

    if new_password != confirm_password:
        return jsonify({"error": "Passwords do not match."}), 400

    # Check if the user exists
    user = user_exists(email)
    if not user:
        return jsonify({"error": "Email is not registered."}), 400

    # Hash the new password
    hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    # Update the password in the database
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE user SET password = %s WHERE email = %s", (hashed_password, email))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({"message": "Password reset successful!"}), 200
    else:
        return jsonify({"error": "Database connection error. Try again later."}), 500


# ---------------------- Logout ---------------------- #
@app.route('/logout', methods=['POST'])
def logout():
    """Logout user."""
    session.clear()
    return jsonify({"message": "Logout successful!"}), 200


# ---------------------- Run Flask App ---------------------- #
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)