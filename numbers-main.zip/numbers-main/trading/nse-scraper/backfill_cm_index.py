"""
Backfill `cm_index_data` from NSE's daily-snapshot indices API.

`load_hystorical_data.download_nse_csv()` only fetches *yesterday*, so any day
the daily run was skipped/failed leaves a gap. The report's RS calc
(get_rs -> get_nifty_index_data) needs `Nifty 50` for the report date and 7/14
days back, so gaps here make report generation fail with
"Could not fetch index data for the required dates".

This fills every missing trading day in the window. Already-present dates are
skipped, and the downloaded file's Index Date is validated against the
requested date (NSE serves a neighbouring day's file for non-trading days).

Usage:
    python backfill_cm_index.py                      # earliest gap window .. today
    python backfill_cm_index.py 2026-05-27 2026-06-19
"""
import os
import sys
import time
from datetime import datetime, timedelta

import pandas as pd
from sqlalchemy import text

from db import get_db, engine
from load_hystorical_data import create_nse_session, insert_csv_to_db

AUTO_LOOKBACK_DAYS = 120
DATE_RETRIES = 3
RETRY_SLEEP = 5

_API = ("https://www.nseindia.com/api/reports?archives="
        "%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C"
        "%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D"
        "&date={date}&type=indices&mode=single")


def _holidays():
    q = """
        SELECT DATE_FORMAT(tradingDate, '%Y-%m-%d') AS trading_date
        FROM `holidays`
        WHERE tradingDate > DATE_SUB(CURDATE(), INTERVAL 3 YEAR);
    """
    return pd.read_sql(text(q), engine, parse_dates=['trading_date'])['trading_date']


def _existing_dates():
    with next(get_db()) as s:
        rows = s.execute(text("SELECT DISTINCT index_date FROM cm_index_data")).all()
    return {r[0].strftime('%Y-%m-%d') for r in rows}


def _target_dates(start=None, end=None):
    if start is None:
        start = (datetime.now() - timedelta(days=AUTO_LOOKBACK_DAYS)).strftime('%Y-%m-%d')
    if end is None:
        end = datetime.now().strftime('%Y-%m-%d')
    dates = pd.date_range(start=start, end=end, freq='B')
    dates = dates[~dates.isin(_holidays())]
    return list(dates)


def _download(d):
    """Download the daily-snapshot CSV for date d; return temp path or None."""
    url = _API.format(date=d.strftime('%d-%b-%Y'))
    session = create_nse_session()
    if not session:
        return None
    try:
        r = session.get(url, timeout=20)
        ct = r.headers.get('content-type', '')
        if r.status_code != 200 or 'csv' not in ct:
            return None
        path = os.path.join(os.getcwd(), f"ind_close_all-{d.strftime('%Y%m%d')}.csv")
        with open(path, 'wb') as f:
            f.write(r.content)
        return path
    finally:
        session.close()


def _file_matches_date(path, d):
    """True if the file's Index Date column is exactly the requested date."""
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    file_dates = pd.to_datetime(df['Index Date'], format='%d-%m-%Y', errors='coerce')
    got = file_dates.dropna().dt.strftime('%Y-%m-%d').unique()
    return list(got) == [d.strftime('%Y-%m-%d')]


def backfill(start=None, end=None):
    target = _target_dates(start, end)
    have = _existing_dates()
    todo = [d for d in target if d.strftime('%Y-%m-%d') not in have]
    print(f"Trading days in range: {len(target)} | already present: "
          f"{len(target) - len(todo)} | to download: {len(todo)}")

    ok, failed, skipped = [], [], []
    for d in todo:
        ds = d.strftime('%Y-%m-%d')
        done = False
        for attempt in range(1, DATE_RETRIES + 1):
            path = _download(d)
            if not path:
                print(f"WARN {ds} attempt {attempt}/{DATE_RETRIES}: download failed/unavailable")
                time.sleep(RETRY_SLEEP)
                continue
            if not _file_matches_date(path, d):
                os.remove(path)
                print(f"SKIP {ds}: file Index Date != requested (non-trading day)")
                skipped.append(ds)
                done = True
                break
            insert_csv_to_db(path)  # inserts all indices for the date, removes file
            print(f"OK   {ds}")
            ok.append(ds)
            done = True
            break
        if not done:
            failed.append(ds)

    print("\n========== CM_INDEX BACKFILL SUMMARY ==========")
    print(f"Loaded  : {len(ok)}")
    print(f"Skipped : {len(skipped)} (non-trading days)")
    print(f"Failed  : {len(failed)}")
    if failed:
        print("Failed dates:", ", ".join(failed))


if __name__ == "__main__":
    start = sys.argv[1] if len(sys.argv) > 1 else None
    end = sys.argv[2] if len(sys.argv) > 2 else None
    backfill(start, end)
