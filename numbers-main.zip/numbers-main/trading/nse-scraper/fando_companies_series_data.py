# import pandas as pd
# from sqlalchemy import create_engine
# import os
# from openpyxl import Workbook

# # Database connection
# engine = create_engine('mysql+pymysql://root:root@localhost:3306/updated_testdb')

# # List of companies to process
# companies = [
#     'RELIANCE', 'HDFCBANK', 'TCS', 'ICICIBANK', 'SBIN', 
#     'INFY', 'BAJFINANCE', 'HINDUNILVR', 'LT', 'HCLTECH', 'PATANJALI'
# ]

#     # {'name': 'April_Series', 'start_date': '2025-01-31', 'xpry_date': '2025-04-24'},
#     # {'name': 'May_Series', 'start_date': '2025-02-28', 'xpry_date': '2025-05-29'},
#     # {'name': 'June_Series', 'start_date': '2025-03-28', 'xpry_date': '2025-06-26'},

# # Date combinations with folder names
# series_data = [
#     {'name': 'October_Series', 'start_date': '2025-08-01', 'xpry_date': '2025-10-28'}
# ]

# # Create base output directory if it doesn't exist
# base_output_dir = 'options_data'
# os.makedirs(base_output_dir, exist_ok=True)

# for series in series_data:
#     # Create folder for each series
#     series_dir = os.path.join(base_output_dir, series['name'])
#     os.makedirs(series_dir, exist_ok=True)
    
#     for company in companies:
#         # Execute query for this company and series
#         query = f"""
#         SELECT * FROM updated_testdb.fo_udiff_bhavdata
#         WHERE tckr_symb = '{company}' 
#         AND start_date = '{series['start_date']}' 
#         AND xpry_date = '{series['xpry_date']}'
#         """
        
#         df = pd.read_sql(query, engine)
        
#         if not df.empty:
#             # Create Excel file path
#             excel_file_path = os.path.join(series_dir, f'{company}_{series["name"]}.xlsx')
            
#             # Write to Excel with formatting
#             with pd.ExcelWriter(excel_file_path, engine='openpyxl') as writer:
#                 df.to_excel(writer, index=False, sheet_name=company)
                
#                 # Get worksheet for formatting
#                 worksheet = writer.sheets[company]
                
#                 # Set column widths (adjust as needed)
#                 for col in worksheet.columns:
#                     column = col[0].column_letter  # Get the column letter
#                     worksheet.column_dimensions[column].width = 15
                
#                 # Add a header with company name and series
#                 worksheet.cell(row=1, column=1, value=f"{company} - {series['name']}")
            
#             print(f"Saved {company} data to {excel_file_path}")
#         else:
#             print(f"No data found for {company} in {series['name']}")

# print("All files generated successfully!")



# import pandas as pd
# from sqlalchemy import create_engine

# # Connect to your database
# engine = create_engine('mysql://root:root@localhost/updated_testdb')

# # Query data for both expiry dates
# query1 = """
# SELECT * FROM fo_udiff_bhavdata
# WHERE tckr_symb = 'NIFTY' AND xpry_date = '2025-11-04'
# """
# query2 = """
# SELECT * FROM fo_udiff_bhavdata
# WHERE tckr_symb = 'NIFTY' AND xpry_date = '2025-10-28'
# """

# df1 = pd.read_sql(query1, engine)
# df2 = pd.read_sql(query2, engine)

# # Export to Excel with two sheets
# with pd.ExcelWriter('nifty_expiry_data.xlsx') as writer:
#     df2.to_excel(writer, sheet_name='2025-10-28', index=False)
#     df1.to_excel(writer, sheet_name='2025-11-04', index=False)



import pandas as pd
from sqlalchemy import create_engine

# Connect to your database
engine = create_engine('mysql://root:root@localhost/updated_testdb')

# Query data for both expiry dates
query1 = """
SELECT * FROM fo_udiff_bhavdata
WHERE tckr_symb = 'NIFTY' AND trade_date between '2025-09-01' AND '2025-10-31'
"""


df1 = pd.read_sql(query1, engine)


# Export to Excel with two sheets
with pd.ExcelWriter('F&O_nifty_data_2025-09-01 to 2025-10-31.xlsx') as writer:
    df1.to_excel(writer, sheet_name='F&O_Nifty_Data', index=False)
