# import requests
# import os
# from datetime import datetime, timedelta
# from pathlib import Path

# class NSE:
#     def __init__(self, base_dir):
#         self.base_dir = Path(base_dir)  # Base directory for saving files
#         self.temp_dir = self.base_dir / "temp"  # Temp directory

#         # Ensure temp directory exists
#         self.temp_dir.mkdir(parents=True, exist_ok=True)

#     def __download(self, url: str, folder: Path, fname: str) -> Path:
#         """Helper function to download files from a given URL."""
#         headers = {
#             "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
#             "Referer": "https://www.nseindia.com",
#             "Accept-Language": "en-US,en;q=0.9",
#             "Connection": "keep-alive",
#         }

#         session = requests.Session()
#         session.headers.update(headers)

#         homepage_url = "https://www.nseindia.com"
#         session.get(homepage_url)  # Set cookies

#         response = session.get(url)

#         if response.status_code != 200:
#             print(f"❌ Failed to fetch API data. Status Code: {response.status_code}")
#             print("Response Text:", response.text[:500])
#             return None  # Return None if the request fails

#         file_path = folder / fname
#         with open(file_path, "wb") as file:
#             file.write(response.content)

#         print(f"✅ cm_index Report downloaded successfully: {file_path}")
#         return file_path

#     def cm_index_data(self) -> Path:
#         yesterday_date = (datetime.today() - timedelta(days=1)).strftime('%d-%b-%Y')
#         fname = f"cm_index_{yesterday_date}.csv"
        
#         # Save file inside temp directory
#         save_path = self.temp_dir / fname  

#         api_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={yesterday_date}&type=indices&mode=single"

#         file = self.__download(api_url, self.temp_dir, fname)

#         if not file or not file.is_file():
#             raise FileNotFoundError(f"Failed to download file: {fname}")

#         return file


import random
import time
import base64
import requests
from datetime import datetime
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import pandas as pd
from config import Settings  # Import the config
DATABASE_URL = "mysql+pymysql://root:root@localhost:3306/updated_testdb"
# Create a database connection using the Settings class
engine = create_engine(Settings.DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

# Function to save files into the database
def save_file_to_db(file_data, file_name, file_type="csv"):
    """Function to save downloaded file content into the database as BLOB or text."""
    try:
        # Convert file data into base64 encoded text
        file_content = base64.b64encode(file_data).decode('utf-8')  # encoding to text for storage
        
        # SQL to insert into the database table (make sure the 'files' table exists)
        insert_sql = text("""
            INSERT INTO files (file_name, file_type, file_content)
            VALUES (:file_name, :file_type, :file_content)
        """)
        session.execute(insert_sql, {
            'file_name': file_name,
            'file_type': file_type,
            'file_content': file_content
        })
        session.commit()
        print(f"File '{file_name}' saved successfully to database.")
    except Exception as e:
        print(f"Failed to save file to DB: {e}")
        session.rollback()

# Function to fetch historical data (your existing function)
def add_historical_data_of_a_date(data_date: datetime): 
    # Replace with the actual logic to fetch historical data
    try:
        # Fetch and process historical data (this part should be as per your existing logic)
        print(f"Fetching historical data for: {data_date}")
        # Example - Replace with actual fetching logic from your data source
        historical_data = f"Historical data for {data_date}"
        save_file_to_db(historical_data.encode('utf-8'), f"historical_data_{data_date}.csv")
    except Exception as e:
        print(f"Error fetching historical data: {e}")

# Function to fetch CM index data
def fetch_cm_index_data(date_str: str):
    file_url = f"https://www.nseindia.com/api/reports?archives=%5B%7B%22name%22%3A%22Daily%20Snapshot%22%2C%22type%22%3A%22archives%22%2C%22category%22%3A%22capital-market%22%2C%22section%22%3A%22indices%22%7D%5D&date={date_str}&type=indices&mode=single"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Referer": "https://www.nseindia.com/reports/daily-reports-archive",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
    }

    try:
        response = requests.get(file_url, headers=headers)
        response.raise_for_status()  # Ensure successful request
        print(f"Successfully fetched CM index data for {date_str}")
        
        # Save CM index data to DB (you can process it before saving)
        save_file_to_db(response.content, f"cm_index_data_{date_str}.csv")
    except requests.exceptions.RequestException as e:
        print(f"Error fetching CM index data: {e}")

# Function to handle the daily process
def process_daily_data():
    # Get today's date and format it for historical and CM index data
    today_date = datetime.today().strftime('%d-%m-%Y')
    print(f"Processing data for: {today_date}")
    
    # Add historical data for the day
    add_historical_data_of_a_date(datetime.today())
    
    # Fetch CM index data
    fetch_cm_index_data(today_date)

# Run the combined function
if __name__ == "__main__":
    process_daily_data()

    
    
    
    
    
    
    
    
    
    
    
# import os
# import time
# import random
# import requests
# import pandas as pd
# import mysql.connector
# from datetime import datetime, timedelta
# from sqlalchemy import text
# from db import get_db
# from main_old import NSE
# from models.last_updated_date import LastUpdatedDate
# from mysql.connector import Error

# # ========================= MySQL Connection ========================= #
# def create_connection():
#     try:
#         connection = mysql.connector.connect(
#             host='localhost',  
#             database='updated_testdb',  
#             user='root',  
#             password='root'  
#         )
#         if connection.is_connected():
#             print("Connected to MySQL")
#         return connection
#     except Error as e:
#         print(f"MySQL Connection Error: {e}")
#         return None

# # ========================= Insert Data into MySQL ========================= #
# def insert_data_to_db(df, connection):
#     try:
#         cursor = connection.cursor()
#         insert_query = """
#         INSERT INTO cm_index_data (index_name, index_date, open_index_value, high_index_value, 
#                                    low_index_value, closing_index_value, points_change, 
#                                    percentage_change, volume, turnover_in_crores, p_e, p_b, div_yield)
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
#         """
#         for row in df.itertuples(index=False):
#             row = [None if pd.isna(value) else value for value in row]
#             cursor.execute(insert_query, row)

#         connection.commit()
#         print(f"{cursor.rowcount} rows inserted into MySQL.")
#     except Error as e:
#         print(f"MySQL Insert Error: {e}")
#     finally:
#         cursor.close()

# # ========================= Download NSE Index Data ========================= #
# def download_nse_csv():
#     yesterday = datetime.today() - timedelta(days=1)
#     date_str = yesterday.strftime("%d-%b-%Y")
#     api_url = f"https://www.nseindia.com/api/reports?date={date_str}&type=indices&mode=single"

#     headers = {
#         "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
#         "Referer": "https://www.nseindia.com",
#         "Accept-Language": "en-US,en;q=0.9",
#         "Connection": "keep-alive",
#     }

#     session = requests.Session()
#     session.headers.update(headers)
#     session.get("https://www.nseindia.com")  # Set necessary cookies

#     response = session.get(api_url)
#     if response.status_code != 200:
#         print(f"API Fetch Error. Status Code: {response.status_code}")
#         return None

#     file_name = f"indices_close_all-{date_str}.csv"
#     save_path = os.path.join(os.getcwd(), file_name)

#     with open(save_path, "wb") as file:
#         file.write(response.content)

#     print(f"CSV Downloaded: {save_path}")
#     return save_path

# # ========================= Process & Insert CSV into MySQL ========================= #
# def insert_csv_to_db(csv_file_path):
#     try:
#         df = pd.read_csv(csv_file_path)
#         df.columns = df.columns.str.strip()

#         df.rename(columns={
#             'Index Name': 'index_name',
#             'Index Date': 'index_date',
#             'Open Index Value': 'open_index_value',
#             'High Index Value': 'high_index_value',
#             'Low Index Value': 'low_index_value',
#             'Closing Index Value': 'closing_index_value',
#             'Points Change': 'points_change',
#             'Change(%)': 'percentage_change',
#             'Volume': 'volume',
#             'Turnover (Rs. Cr.)': 'turnover_in_crores',
#             'P/E': 'p_e',
#             'P/B': 'p_b',
#             'Div Yield': 'div_yield'
#         }, inplace=True)

#         df['index_date'] = pd.to_datetime(df['index_date'], format='%d-%m-%Y').dt.strftime('%Y-%m-%d')
#         numeric_columns = ['open_index_value', 'high_index_value', 'low_index_value', 
#                            'closing_index_value', 'points_change', 'percentage_change', 
#                            'volume', 'turnover_in_crores', 'p_e', 'p_b', 'div_yield']
        
#         for col in numeric_columns:
#             df[col] = pd.to_numeric(df[col], errors='coerce')

#         df = df.where(pd.notnull(df), None)

#         connection = create_connection()
#         if connection:
#             insert_data_to_db(df, connection)
#             connection.close()
#     except Exception as e:
#         print(f"Error Processing CSV: {e}")

# # ========================= Add Historical Data ========================= #
# def add_historical_data_of_a_date(data_date: datetime):
#     x = NSE()
#     # try:
#     #     data = x.equity_cm_bhavcopy_final(data_date)
#     #     print("Equity CM Bhavcopy:", data)
#     #     x.add_equity_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     # except RuntimeError as e:
#     #     print(e)
#     # try:
#     #     data = x.equity_fo_bhavcopy_final(data_date)
#     #     print("Equity FO Bhavcopy:", data)
#     #     x.add_fo_udiff_bhavcopy_to_db(data, verify_in_db=False)
#     # except RuntimeError as e:
#     #     print(e)
#     # try:
#     #     data = x.securities_bhavdata(data_date)
#     #     print("Securities Bhavdata:", data)
#     #     x.add_securities_bhavdata_to_db(data, verify_in_db=False)
#     # except RuntimeError as e:
#     #     print(e)

# # ========================= Main Execution ========================= #
# def main():
#     # Step 1: Download and Insert NSE Index Data
#     downloaded_csv = download_nse_csv()
#     if downloaded_csv:
#         insert_csv_to_db(downloaded_csv)

#     # Step 2: Process Historical Data (Only for Yesterday)
#     yesterday_str = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
#     dates = pd.date_range(start=yesterday_str, end=yesterday_str, freq='B')

#     count = 0
#     for date in dates:
#         add_historical_data_of_a_date(date)

#         if count % 4 == 0:
#             time.sleep(random.randint(1, 2))  # Prevent Overloading API

#         count += 1

#     # Step 3: Update Last Trade Date in Database
#     with next(get_db()) as db_session:
#         latest_trade_date = db_session.execute(text('SELECT MAX(trade_date) FROM fo_udiff_bhavdata')).scalar()
#         last_updated = db_session.query(LastUpdatedDate).first()
#         if last_updated:
#             last_updated.trade_date = latest_trade_date
#             db_session.commit()
#             print(f"Last Trade Date Updated: {latest_trade_date}")

# # ========================= Run Script ========================= #
# if __name__ == "__main__":
#     main()





import random
from pathlib import Path

import pandas as pd
from datetime import datetime

from sqlalchemy import text
from db import get_db
from main_old import NSE
import time

from models.last_updated_date import LastUpdatedDate


def add_historical_data_of_a_date(data_date: datetime):
    x = NSE()
    try:
        data = x.equity_cm_bhavcopy_final(data_date)
        print("equity_cm_bhavcopy_final:", data)
        x.add_equity_udiff_bhavcopy_to_db(data, verify_in_db=False)
    except RuntimeError as e:
        print(e)
    try:
        data = x.equity_fo_bhavcopy_final(data_date)
        print("equity_fo_bhavcopy_final:", data)
        x.add_fo_udiff_bhavcopy_to_db(data, verify_in_db=False)
    except RuntimeError as e:
        print(e)
    try:
        data = x.securities_bhavdata(data_date)
        print("securities_bhavdata:", data)
        x.add_securities_bhavdata_to_db(data, verify_in_db=False)
    except RuntimeError as e:
        print(e)
    # try:
    #     data = x.cm_index_data(data_date)
    #     print('cm_index_data', data)
    #     x.add_cm_index_data_to_db(data, verify_in_db=False)
    #     print(e)
    # except RuntimeError as e:
    #     print(e)
    # try: 
    #     data = x.equity_block(data_date)
    #     print("equity_block:", data)
    #     x.add_equity_block_to_db(data, verify_in_db=False)
    # except RuntimeError as e:
    #     print(e)
    # try:
    #     data = x.equity_bulk(data_date)
    #     print("equity_bulk:", data)
    #     x.add_equity_bulk_to_db(data, verify_in_db=False)
    # except RuntimeError as e:
    #     print(e)


if __name__ == "__main__":
    # Generate business days only
    dates = pd.date_range(start="2025-02-11", 
                          end=datetime.now().strftime('%Y-%m-%d'), 
                          freq='B')  # freq='B' ensures no Sat/Sun

    count = 0
    for date in dates:
        # Increment through business days
        add_historical_data_of_a_date(date)
        
        # Add sleep for every 4 iterations
        if count % 4 == 0:
            time.sleep(random.randint(1, 2))  # Slight delay to avoid overwhelming the system
        
        count += 1

    with next(get_db()) as db_session:
        latest_trade_date = db_session.execute(
            text('select max(trade_date) from fo_udiff_bhavdata')).scalar()
        last_updated = db_session.query(LastUpdatedDate).first()
        if last_updated:
            last_updated.last_updated_date = latest_trade_date
            db_session.add(last_updated)
        else:
            db_session.add(LastUpdatedDate(
                last_updated_date=latest_trade_date))
        db_session.commit()