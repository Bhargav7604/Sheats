from datetime import datetime
import pandas as pd
from sqlalchemy import text
from db import engine
import openpyxl

# Define your specific dates
specific_start_date = '2025-02-28'
specific_expiry_date = '2025-05-29'

# Process each ticker separately
def process_ticker_data(ticker):
    print(f"Processing {ticker} with start date {specific_start_date} and expiry date {specific_expiry_date}")
    
    financial_instrument_data_query = f"""
    WITH 
    FirstTradeData AS (
        SELECT
            fin_instrm_nm,
            MIN(trade_date) AS first_trade_date
        FROM
            fo_udiff_bhavdata
        WHERE
            chng_in_opn_intrst > 0
            and tckr_symb = "{ticker}"
            and start_date = '{specific_start_date}'
            and xpry_date = '{specific_expiry_date}'
        GROUP BY
            fin_instrm_nm
    ),
    PriceData AS (
        SELECT 
            fin_instrm_nm,
            trade_date,
            undrlyg_price,
            close_price,
            (opn_intrst/new_brd_lot_qty) AS opn_intrst_lot,
            (chng_in_opn_intrst/new_brd_lot_qty) AS chng_opn_intrst_lot,
            xpry_date
        FROM 
            fo_udiff_bhavdata
        WHERE 
            tckr_symb = "{ticker}"
            and start_date = '{specific_start_date}'
            and xpry_date = '{specific_expiry_date}'
    ),
    ActiveInstruments AS (
        SELECT DISTINCT fin_instrm_nm 
        FROM fo_udiff_bhavdata 
        WHERE tckr_symb = '{ticker}'
        and start_date = '{specific_start_date}'
        and xpry_date = '{specific_expiry_date}'
    )
    SELECT
        id.fin_instrm_nm as name,
        id.tckr_symb as ticker_symbol,
        id.fin_instrm_tp as type,
        id.instrm_start_date as start_date,
        id.trade_date as 'current_date',
        id.xpry_date as expiry_date,
        DATEDIFF(id.trade_date, id.instrm_start_date) AS days_elapsed_since_birth,
        ift.first_trade_date,
        DATEDIFF(id.trade_date, ift.first_trade_date) AS days_active,
        (DATEDIFF(id.trade_date, ift.first_trade_date)*100/
            NULLIF(DATEDIFF(id.trade_date, id.instrm_start_date), 0)) AS percentage_active,    
        p1.undrlyg_price AS first_trade_underlying_price,
        p1.close_price AS first_trade_close_price,
        p2.close_price AS latest_close_price,
        p2.opn_intrst_lot AS latest_opn_intrst_lot,
        p2.chng_opn_intrst_lot AS latest_chng_opn_intrst_lot
    FROM
        (
        SELECT
            fin_instrm_nm,
            fin_instrm_tp,
            tckr_symb,
            start_date AS instrm_start_date,
            trade_date,
            xpry_date
        FROM
            fo_udiff_bhavdata
        WHERE 
            tckr_symb = "{ticker}"
            and start_date = '{specific_start_date}'
            and xpry_date = '{specific_expiry_date}'
        ) id
    JOIN
        ActiveInstruments ai ON id.fin_instrm_nm = ai.fin_instrm_nm
    LEFT JOIN
        FirstTradeData ift ON id.fin_instrm_nm = ift.fin_instrm_nm
    LEFT JOIN
        PriceData p1 ON id.fin_instrm_nm = p1.fin_instrm_nm AND 
        ift.first_trade_date = p1.trade_date
    LEFT JOIN
        PriceData p2 ON id.fin_instrm_nm = p2.fin_instrm_nm AND 
        id.trade_date = p2.trade_date
    ORDER BY
        id.trade_date, id.fin_instrm_nm
    """

    try:
        financial_instrument_data = pd.read_sql(
            text(financial_instrument_data_query),
            engine,
            parse_dates=[
                "start_date", "current_date", "expiry_date", "first_trade_date"])

        if not financial_instrument_data.empty:
            # Clean up data for Excel export
            financial_instrument_data.sort_values(by=['current_date', 'name'], inplace=True)
            
            # Format date columns
            date_columns = ['start_date', 'current_date', 'expiry_date', 'first_trade_date']
            for col in date_columns:
                if col in financial_instrument_data.columns:
                    financial_instrument_data[col] = pd.to_datetime(financial_instrument_data[col]).dt.strftime('%Y-%m-%d')
            
            # Save to Excel with a descriptive filename
            output_file = f"{ticker}_{specific_start_date}_to_{specific_expiry_date}_data.xlsx"
            
            # Create Excel file
            financial_instrument_data.to_excel(output_file, index=False, engine='openpyxl')
            
            print(f"Data for {ticker} successfully saved to {output_file}")
            return True
        else:
            print(f"No data found for {ticker} with the specified dates")
            return False
            
    except Exception as e:
        print(f"Error processing {ticker}: {str(e)}")
        return False

if __name__ == "__main__":
    
    process_ticker_data('RELIANCE')

    process_ticker_data('HDFCBANK')
    
    process_ticker_data('TCS')
    
    process_ticker_data('ICICIBANK')
    
    process_ticker_data('SBIN')
    
    process_ticker_data('INFY')
    
    process_ticker_data('BAJFINANCE')
    
    process_ticker_data('HINDUNILVR')
    
    process_ticker_data('LT')
    
    process_ticker_data('HCLTECH')
    
