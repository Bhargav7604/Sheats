import pandas as pd
import requests
from io import StringIO
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import pymysql  # Ensure pymysql is installed

# Database Configuration
DATABASE_URL = "mysql+pymysql://root:root@localhost:3306/nse_indices_data"
engine = create_engine(DATABASE_URL, echo=True)

# Create a session
Session = sessionmaker(bind=engine)
session = Session()

# URLs for downloading data
NIFTY_INDEXES = {
    "nifty_50": "https://nsearchives.nseindia.com/content/indices/ind_nifty50list.csv",
    "nifty_500": "https://nsearchives.nseindia.com/content/indices/ind_nifty500list.csv",
    "nifty_next_50": "https://nsearchives.nseindia.com/content/indices/ind_niftynext50list.csv",
    "bank_nifty": "https://nsearchives.nseindia.com/content/indices/ind_niftybanklist.csv",
    "fin_nifty": "https://nsearchives.nseindia.com/content/indices/ind_niftyfinancelist.csv",
    "midcap_nifty": "https://nsearchives.nseindia.com/content/indices/ind_niftymidcapselect_list.csv",
}

# Mapping of Python dictionary keys to MySQL table names (fixed names)
TABLE_NAME_MAPPING = {
    "nifty_50": "nifty_50",
    "nifty_next_50": "nifty_next_50",
    "nifty_500": "nifty_500",
    "bank_nifty": "nifty_bank",
    "fin_nifty": "nifty_financial_services",
    "midcap_nifty": "nifty_midcap_select",
    "Nifty_FNO_List": "nifty_fno_list"
}

# Function to fetch and store data
def fetch_and_store_data(table_key, url):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code != 200:
            print(f"Failed to fetch {table_key}. HTTP Status: {response.status_code}")
            return

        df = pd.read_csv(StringIO(response.text))
        print(f"Downloaded data from {url} for table {table_key}")

        if df.empty:
            print(f"No data found for {table_key}. Skipping insertion.")
            return  # Prevent inserting empty data

        print(f"Columns before renaming ({table_key}): {df.columns.tolist()}")  # Debugging
        
        # Renaming columns
        if table_key in ["nifty_50", "nifty_500", "nifty_next_50", "bank_nifty", "fin_nifty", "midcap_nifty"]:
            df = df.rename(columns={
                "Company Name": "company_name",
                "Industry": "industry",
                "Symbol": "symbol",
                "Series": "series",
                "ISIN Code": "isin_code"
            })
            df = df[["company_name", "industry", "symbol", "series", "isin_code"]]

        table_name = TABLE_NAME_MAPPING[table_key]

        print(f"Inserting data into {table_name}...")  # Debugging
        
        df.to_sql(table_name, con=engine, if_exists="append", index=False)
        print(f"Data appended successfully into {table_name}")

    except Exception as e:
        print(f"Error processing {table_key}: {e}")

# Process each table
for table_key, url in NIFTY_INDEXES.items():
    fetch_and_store_data(table_key, url)

print("All data inserted successfully!")