from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

# Database Configuration
DATABASE_URL = "mysql+pymysql://root:root@localhost:3306/nse_indices_data"  # Update DB name if needed

# Create Database Engine
engine = create_engine(DATABASE_URL, echo=True)

# Base class for SQLAlchemy models
Base = declarative_base()

# Fixed: Table names updated (No spaces)
class Nifty50(Base):
    """
    SQLAlchemy model for the 'Nifty 50' table.
    """
    __tablename__ = "nifty_50"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(255), nullable=False)
    industry = Column(String(255), nullable=False)
    symbol = Column(String(50), unique=True, nullable=False)
    series = Column(String(10), nullable=False)
    isin_code = Column(String(20), unique=True, nullable=False)


class NiftyNext50(Base):
    """
    SQLAlchemy model for the 'Nifty Next 50' table.
    """
    __tablename__ = "nifty_next_50"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(255), nullable=False)
    industry = Column(String(255), nullable=False)
    symbol = Column(String(50), unique=True, nullable=False)
    series = Column(String(10), nullable=False)
    isin_code = Column(String(20), unique=True, nullable=False)


class Nifty500(Base):
    """
    SQLAlchemy model for the 'Nifty 500' table.
    """
    __tablename__ = "nifty_500"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(255), nullable=False)
    industry = Column(String(255), nullable=False)
    symbol = Column(String(50), unique=True, nullable=False)
    series = Column(String(10), nullable=False)
    isin_code = Column(String(20), unique=True, nullable=False)


class FinNifty(Base):
    """
    SQLAlchemy model for the 'Nifty Financial Services' table.
    """
    __tablename__ = "nifty_financial_services"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(255), nullable=False)
    industry = Column(String(255), nullable=False)
    symbol = Column(String(50), unique=True, nullable=False)
    series = Column(String(10), nullable=False)
    isin_code = Column(String(20), unique=True, nullable=False)


class BankNifty(Base):
    """
    SQLAlchemy model for the 'Nifty Bank' table.
    """
    __tablename__ = "nifty_bank"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(255), nullable=False)
    industry = Column(String(255), nullable=False)
    symbol = Column(String(50), unique=True, nullable=False)
    series = Column(String(10), nullable=False)
    isin_code = Column(String(20), unique=True, nullable=False)


class MidcapNifty(Base):
    """
    SQLAlchemy model for the 'Nifty Midcap Select' table.
    """
    __tablename__ = "nifty_midcap_select"

    id = Column(Integer, primary_key=True, autoincrement=True)
    company_name = Column(String(255), nullable=False)
    industry = Column(String(255), nullable=False)
    symbol = Column(String(50), unique=True, nullable=False)
    series = Column(String(10), nullable=False)
    isin_code = Column(String(20), unique=True, nullable=False)


class FutureAndOption(Base):
    """
    SQLAlchemy model for the 'Nifty F&O List' table.
    """
    __tablename__ = "nifty_fno_list"

    id = Column(Integer, primary_key=True, autoincrement=True)
    symbol = Column(String(50), nullable=False)
    month_type = Column(String(50), nullable=False)
    symbol_type = Column(String(50), nullable=False)
    step_value = Column(Integer, nullable=False)
    strikes_provided_itm = Column(Integer, nullable=False)
    strikes_provided_atm = Column(Integer, nullable=False)
    strikes_provided_otm = Column(Integer, nullable=False)
    total_strikes_reserve_itm = Column(Integer, nullable=False)
    total_strikes_reserve_atm = Column(Integer, nullable=False)
    total_strikes_reserve_otm = Column(Integer, nullable=False)


# Create tables in the database
Base.metadata.create_all(engine)

# Create a session
Session = sessionmaker(bind=engine)
session = Session()

print("Database and Tables Created Successfully!")
