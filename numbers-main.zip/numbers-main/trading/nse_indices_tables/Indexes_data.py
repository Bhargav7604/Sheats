# import pandas as pd
# from sqlalchemy import create_engine

# # Database connection details
# db_username = 'root'
# db_password = 'root'
# db_host = 'localhost'
# db_name = 'updated_testdb'

# # Create a connection to the database
# connection_string = f"mysql+pymysql://{db_username}:{db_password}@{db_host}/{db_name}"
# engine = create_engine(connection_string)

# # Query to filter IDF and STF
# query = """
# SELECT *
# FROM fo_udiff_bhavdata
# WHERE fin_instrm_tp IN ('IDF', 'STF');
# """

# # Load data into a pandas DataFrame
# df = pd.read_sql(query, engine)

# # Save the filtered data to an Excel file
# output_file = 'Filtered_FNO_Data.xlsx'
# df.to_excel(output_file, index=False)

# print(f"Filtered data saved to {output_file}")


# import pandas as pd
# from sqlalchemy import create_engine
# from datetime import datetime
# import smtplib
# from email.message import EmailMessage
 

# # Database connection details
# db_username = 'root'
# db_password = 'root'
# db_host = 'localhost'
# db_name = 'updated_testdb'

# # Create a connection to the database
# connection_string = f"mysql+pymysql://{db_username}:{db_password}@{db_host}/{db_name}"
# engine = create_engine(connection_string)

# # Query to filter IDF and STF
# query = """
# SELECT *
# FROM fo_udiff_bhavdata
# WHERE fin_instrm_tp = "IDF";
# """

# try:
#     # Load data into a pandas DataFrame
#     df = pd.read_sql(query, engine)

#     # Debug: Check if data is retrieved
#     print(f"Number of records retrieved: {len(df)}")
#     print(df.tail())  # Display last few rows for verification

#     # Check if data is available before saving
#     if not df.empty:
#         output_file = 'Filtered_IDF_Data.xlsx'
#         df.to_excel(output_file, index=False)
#         print(f"Filtered data saved to {output_file}")
#     else:
#         print("No data found matching the filter criteria.")

# except Exception as e:
#     print(f"Error: {e}")

# finally:
#     engine.dispose()  # Close the database connection

#     sender_email = "kpdasari@gmail.com"
#     receiver_email = ["kpdasari@gmail.com","rsriwastava@gmail.com"]
#     subject = f"Automated Final Report - {today}"
#     body = "Latest all reports data."

#     msg = EmailMessage()
#     msg["From"] = sender_email
#     msg["To"] = receiver_email
#     msg["Subject"] = subject
#     msg.set_content(body)

#     with open(output_excel_file, "rb") as file:
#         msg.add_attachment(file.read(), maintype="application",
#                            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
#                            filename=output_excel_file)

#     smtp_server = "smtp.gmail.com"
#     smtp_port = 587
#     # email_password = "pxvm ggis dtlq rfhk"
#     email_password = "wmhe pquz curh rugz"

#     try:
#         with smtplib.SMTP(smtp_server, smtp_port) as server:
#             server.starttls()
#             server.login(sender_email, email_password)
#             server.send_message(msg)
#         print(f"Email sent successfully to {receiver_email}")

#         # Delete all files in the directory after successful email send
#         clear_directory()

#     except Exception as e:
#         print(f"Failed to send email: {e}")
#         with open("error_log.txt", "a") as f:
#             f.write(f"{datetime.now()} - Email failed: {e}\n")



import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime
import smtplib
from email.message import EmailMessage
import os

# Database connection details
db_username = 'root'
db_password = 'root'
db_host = 'localhost'
db_name = 'updated_testdb'

# Create a connection to the database
connection_string = f"mysql+pymysql://{db_username}:{db_password}@{db_host}/{db_name}"
engine = create_engine(connection_string)

# Query to filter IDF and STF
query = """
SELECT *
FROM fo_udiff_bhavdata
WHERE fin_instrm_tp = "IDF";
"""

# Define the output file name
output_file = 'Filtered_IDF_Data.xlsx'

try:
    # Load data into a pandas DataFrame
    df = pd.read_sql(query, engine)

    # Debug: Check if data is retrieved
    print(f"Number of records retrieved: {len(df)}")
    print(df.tail())  # Display last few rows for verification

    # Check if data is available before saving
    if not df.empty:
        df.to_excel(output_file, index=False)
        print(f"Filtered data saved to {output_file}")
    else:
        print("No data found matching the filter criteria.")
        # Exit the script if no data is found
        exit()

except Exception as e:
    print(f"Error: {e}")
    exit()

finally:
    engine.dispose()  # Close the database connection

# Email configuration
sender_email = "dharanigvlacksolutions@gmail.com"
receiver_email = "kpdasari@gmail.com"
today = datetime.today().strftime('%Y-%m-%d')  # Define 'today' variable
subject = f"IDF Data - {today}"
body = "IDF Data."

msg = EmailMessage()
msg["From"] = sender_email
msg["To"] = receiver_email
msg["Subject"] = subject
msg.set_content(body)

# Attach the Excel file
try:
    with open(output_file, "rb") as file:
        msg.add_attachment(file.read(), maintype="application",
                           subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           filename=output_file)
except Exception as e:
    print(f"Error attaching file: {e}")
    exit()

# SMTP configuration
smtp_server = "smtp.gmail.com"
smtp_port = 587
# email_password = "wmhe pquz curh rugz"  # Replace with your actual app password
email_password = "qcnb mcgh gdjj vchx"

try:
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(sender_email, email_password)
        server.send_message(msg)
    print(f"Email sent successfully to {receiver_email}")

    # Optionally, delete the file after sending the email
    if os.path.exists(output_file):
        os.remove(output_file)
        print(f"File {output_file} deleted.")

except Exception as e:
    print(f"Failed to send email: {e}")
    with open("error_log.txt", "a") as f:
        f.write(f"{datetime.now()} - Email failed: {e}\n")