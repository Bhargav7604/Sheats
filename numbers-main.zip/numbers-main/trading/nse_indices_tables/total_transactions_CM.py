# import pandas as pd
# from sqlalchemy import create_engine

# db_username = 'root'  
# db_password = 'root'  
# db_host = 'localhost'          
# db_name = 'updated_testdb' 

# connection_string = f"mysql+pymysql://{db_username}:{db_password}@{db_host}/{db_name}"
# engine = create_engine(connection_string)

# query = """
# SELECT 
#     trade_date AS date,  
#     SUM(ttl_nb_of_txs_exctd) AS sum_of_transactions  
# FROM 
#     fo_udiff_bhavdata  
# GROUP BY 
#     trade_date
# ORDER BY 
#     trade_date;
# """

# df = pd.read_sql(query, engine)

# # Save the DataFrame to an Excel file
# output_file = "sum_of_FO_transactions.xlsx"
# df.to_excel(output_file, index=False, sheet_name="Sum_of_FO_transactions")

# print(f"Data has been saved to {output_file}")



# import pandas as pd
# # import os

# # Paths to your Excel files
# file1 = r"C:\Page_Projects\trading.tar 1\trading.tar 1\trading\nse_indices_tables\sum_of_CM_transactions.xlsx"  # Replace with the path to your first Excel file
# file2 = r"C:\Page_Projects\trading.tar 1\trading.tar 1\trading\nse_indices_tables\sum_of_FO_transactions.xlsx"  # Replace with the path to your second Excel file

# # Output file name
# output_file = "CM_FO Transactions.xlsx"

# # Read the Excel files into DataFrames
# df1 = pd.read_excel(file1)
# df2 = pd.read_excel(file2)

# # Write the DataFrames to a single Excel file with two sheets
# with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
#     df1.to_excel(writer, sheet_name="CM_Transactions_Sum", index=False)
#     df2.to_excel(writer, sheet_name="FO_Transactions_Sum", index=False)

# print(f"Combined Excel file saved as {output_file}")

import pandas as pd
import os

# Paths to your Excel files
file1 = r"C:\Page_Projects\trading.tar 1\trading.tar 1\trading\nse_indices_tables\Filtered_IDF_Data.xlsx"  # Replace with the correct path to your first Excel file
file2 = r"C:\Page_Projects\trading.tar 1\trading.tar 1\trading\nse_indices_tables\Filtered_STF_Data.xlsx"  # Replace with the correct path to your second Excel file

# Output file name
output_file = r"C:\Users\vlack\Documents\STF and IDF data.xlsx"

# Check if the input files exist
if not os.path.exists(file1):
    print(f"Error: File not found - {file1}")
    exit()
if not os.path.exists(file2):
    print(f"Error: File not found - {file2}")
    exit()

# Read the Excel files into DataFrames
try:
    df1 = pd.read_excel(file1)
    df2 = pd.read_excel(file2)
except Exception as e:
    print(f"Error reading Excel files: {e}")
    exit()

# Function to remove time from datetime columns
def remove_time(df):
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):  # Check if the column is datetime
            df[col] = df[col].dt.date  # Extract only the date part
    return df

# Remove time from datetime columns in both DataFrames
df1 = remove_time(df1)
df2 = remove_time(df2)

# Write the DataFrames to a single Excel file with two sheets
try:
    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        df1.to_excel(writer, sheet_name="Filtered_IDF_Data", index=False)
        df2.to_excel(writer, sheet_name="Filtered_STF_Data", index=False)
    print(f"Combined Excel file saved as {output_file}")
except Exception as e:
    print(f"Error writing to Excel file: {e}")